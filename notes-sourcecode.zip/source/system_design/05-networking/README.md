# Networking Basics

## The OSI Model

Understanding networking requires understanding the 7-layer OSI model:

```
Layer 7: Application      (HTTP, HTTPS, DNS, SMTP)
Layer 6: Presentation     (SSL/TLS encryption)
Layer 5: Session          (Session management)
Layer 4: Transport        (TCP, UDP)
Layer 3: Network          (IP routing)
Layer 2: Data Link        (MAC addresses, switches)
Layer 1: Physical         (Cables, signals)

Simplified TCP/IP Model:
─────────────────────────
Application Layer    (HTTP, DNS, SSH)
Transport Layer      (TCP, UDP)
Internet Layer       (IP)
Link Layer           (Ethernet)
```

## TCP vs UDP

### TCP (Transmission Control Protocol)

**Connection-oriented, reliable**

```
Characteristics:
─────────────────
✅ Reliable: All packets arrive
✅ Ordered: Packets arrive in order
✅ Connection-oriented: 3-way handshake
✅ Flow control: Sender waits for receiver

❌ Slower: Overhead of reliability
❌ Heavier: More data for headers
❌ Not suitable for real-time

Use Cases:
───────────
- Web browsing (HTTP/HTTPS)
- Email (SMTP)
- File transfers (FTP)
- Database connections
- SSH/Telnet
- Anything requiring reliability
```

**TCP Connection:**

```mermaid
sequenceDiagram
    participant C as Client
    participant S as Server

    C->>S: SYN (Hello, I want to connect)
    S->>C: SYN-ACK (OK, I'm listening)
    C->>S: ACK (Great, let's talk)
    Note over C,S: Connection established — data transfer begins
```

### UDP (User Datagram Protocol)

**Connectionless, unreliable, fast**

```
Characteristics:
─────────────────
✅ Fast: Minimal overhead
✅ Low latency: No handshake
✅ Lightweight: Small headers
✅ Multicast/Broadcast capable

❌ Unreliable: Packets may be lost
❌ Unordered: Packets may arrive out of order
❌ No flow control: May overwhelm receiver

Use Cases:
───────────
- Live video/audio streaming
- Online gaming
- VoIP (Skype, Zoom)
- DNS queries
- IoT sensors
- Real-time applications where speed > reliability
```

**UDP Packet:**
```
Client                          Server
  │                              │
  ├─── Send UDP packet ──────────>│
  │                              │
  │<─── Optional response ────────┤
  │                              │
  (No connection, just send data)
```

### Decision Tree

```
                    Is reliability critical?
                           │
                    ┌──────┴──────┐
                   Yes            No
                    │              │
                   TCP           Is low latency critical?
                    │              │
                                  Yes → UDP
                                  │
                                  No → TCP or UDP (context dependent)

Examples:
─────────
Banking transaction → TCP (reliability > latency)
Live stream → UDP (latency > reliability)
Email → TCP (reliability critical)
Online game → UDP (latency critical)
Video call → UDP (latency > perfect reliability)
Database → TCP (consistency critical)
```

## DNS (Domain Name System)

Translates domain names to IP addresses:

```mermaid
sequenceDiagram
    participant B as Browser
    participant R as DNS Recursive Resolver
    participant Root as Root Nameserver
    participant TLD as TLD Nameserver
    participant Auth as Authoritative Nameserver

    B->>R: What's IP for google.com?
    R->>Root: What's IP for google.com?
    Root-->>R: Contact TLD nameserver
    R->>TLD: What's IP for google.com?
    TLD-->>R: Contact authoritative nameserver
    R->>Auth: What's IP for google.com?
    Auth-->>R: IP: 142.251.41.14
    R-->>B: IP: 142.251.41.14
    Note over B: Now connect to 142.251.41.14
```


**DNS Record Types:**
```
A Record          → IPv4 address
AAAA Record       → IPv6 address
CNAME Record      → Alias to another domain
MX Record         → Mail server
TXT Record        → Text data (verification, SPF)
NS Record         → Nameserver
SOA Record        → Zone authority info
```

## HTTP/HTTPS

### HTTP (HyperText Transfer Protocol)

Stateless, request-response protocol:

```
Request Structure:
──────────────────
GET /api/users HTTP/1.1
Host: example.com
User-Agent: Mozilla/5.0
Accept: application/json
Content-Type: application/json

{
  "key": "value"
}

Response Structure:
──────────────────
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 42
Cache-Control: max-age=3600

{
  "id": 1,
  "name": "John Doe"
}
```

### HTTP Versions

```
HTTP/1.0
────────
- One request/response per connection
- Had to create new connection each time
- Very slow for modern websites

HTTP/1.1 (Still widely used)
─────────
- Keep-alive connections
- Pipelining (send multiple requests)
- Better caching
- Host header (multi-domain hosting)
- Issues:
  - Head-of-line blocking
  - Lots of connections needed

HTTP/2
──────
- Multiplexing (multiple streams over one connection)
- Server push
- Header compression
- Binary framing
- Much faster than HTTP/1.1
- Required TLS/SSL

HTTP/3
──────
- Uses QUIC (UDP-based)
- Even faster connection setup
- Better mobile support
- Still newer, less adoption
```

### HTTPS (HTTP Secure)

HTTP with TLS encryption:

```
HTTPS Connection Flow:
──────────────────────
1. Client connects on port 443
2. TLS Handshake:
   - Client and server exchange certificates
   - Agree on encryption algorithm
   - Exchange keys
3. Encrypted communication begins
4. All data encrypted end-to-end

Certificate Chain:
──────────────────
Domain Certificate (example.com)
  │
  ├─ Signed by
  │
Intermediate Certificate
  │
  ├─ Signed by
  │
Root CA Certificate (trusted by browser)
```

**Why HTTPS?**
```
✅ Encryption: Data can't be read in transit
✅ Authentication: Verify you're talking to the right server
✅ Integrity: Data can't be modified in transit
✅ Trust: Browser shows padlock and domain info
```

## IP Addressing

### IPv4

32-bit address, 4 octets:

```
192.168.1.1
│   │   │  │
└───┴───┴──┴─ Each octet: 0-255

Classes (Legacy):
─────────────────
Class A: 1.0.0.1 - 126.255.255.255       (Large networks)
Class B: 128.0.0.1 - 191.255.255.255     (Medium networks)
Class C: 192.0.0.1 - 223.255.255.255     (Small networks)

Private IP Ranges (Not routable on internet):
──────────────────────────────────────────────
10.0.0.0 - 10.255.255.255
172.16.0.0 - 172.31.255.255
192.168.0.0 - 192.168.255.255
127.0.0.1 - localhost
```

### IPv6

128-bit address, much larger:

```
2001:0db8:85a3:0000:0000:8a2e:0370:7334

Simplified:
──────────
2001:db8:85a3::8a2e:370:7334

Advantages:
───────────
✅ 340 undecillion addresses
✅ Larger address space for IoT
✅ Better routing
✅ No NAT needed
❌ Still not widely adopted
```

## Firewalls & NAT

### Firewalls

Control traffic based on rules:

```
External Internet
       │
       ├─ Firewall ─┐
       │            │
       ├─ Port 80   │─> Allow (HTTP)
       ├─ Port 443  │─> Allow (HTTPS)
       ├─ Port 22   │─> Allow (SSH from specific IPs)
       └─ Port 3306 │─> Block (MySQL shouldn't be public)
       │
   Internal Network
```

### NAT (Network Address Translation)

Maps internal IPs to single external IP:

```
Internal Network:     External Network:
─────────────────     ─────────────────
192.168.1.100    ┌──> 203.0.113.45:12345
192.168.1.101    │
192.168.1.102    ├──> 203.0.113.45:12346
                 │
                 └──> 203.0.113.45:12347

Router tracks which internal IP sent
which request and routes responses back
```

**Why NAT?**
```
✅ Limited IPv4 addresses
✅ Security: Internal IPs hidden
✅ One connection per organization
❌ Breaks P2P applications
❌ IPv6 will eliminate need
```

## Load Balancing at Network Layer

### DNS Load Balancing

```
example.com resolves to multiple IPs:
───────────────────────────────────────

example.com → 192.168.1.1
example.com → 192.168.1.2
example.com → 192.168.1.3

DNS round-robin distributes requests
```

### Layer 4 Load Balancing (TCP/UDP)

```
Client Request
      │
      ├─────────────────┐
      │                 │
      ├──> Port 443 ────┼──> Server 1
      │                 │
      ├──> Port 443 ────┼──> Server 2
      │                 │
      └──> Port 443 ────┴──> Server 3

Fast, efficient, connection-level
```

### Layer 7 Load Balancing (Application)

```
Client Request (HTTP)
      │
      ├─────────────────────────────┐
      │                             │
      ├─ GET /api/users        ────────> API Server
      │                             │
      ├─ GET /images/logo.png  ────────> Static Server
      │                             │
      └─ GET /admin/panel      ────────> Admin Server

Smart routing based on URL/headers
```

## Network Latency

### Geographical Latency

```
Distance (approx)  Time for light
─────────────────  ──────────────
1 km               3.3 microseconds
10 km              33 microseconds
100 km             330 microseconds
1000 km (1 ms)     3.3 milliseconds
Earth circumference (40M km): 130 milliseconds

Practical Latencies:
──────────────────
Within same datacenter:   < 1 ms
Across US (coast to coast): 40-80 ms
US to Europe:             100-200 ms
US to Asia:               150-300 ms
```

### Network Path Optimization

```
Problem: Direct route is slow
─────────────────────────────

User (NY) ──[slow]──> Server (Tokyo)
          (300ms)

Solution: Content Delivery Network (CDN)
──────────────────────────────────────

User (NY) ──[fast]──> CDN (NY)
           (10ms)

           CDN (NY) ──[slow]──> Origin (Tokyo)
                      (300ms, but cached)

User gets fast response from nearest edge!
```

## Network Bandwidth

### Throughput vs Latency

```
Analogy: Highway
────────────────
Latency:  Time to drive from start to end
Throughput: Number of cars that can use highway

Highway Upgrade:
─────────────────
Add lanes:     Increases throughput (not latency)
Straighter:    Decreases latency (not throughput)

Network Analogy:
─────────────────
More fiber:    Increases throughput
Shorter path:  Decreases latency (via CDN or peering)
```

### Bandwidth Bottlenecks

```
Database    5,000 req/sec × 1 KB = 5 MB/s
  │
  ├─ Network (10 Gbps = 1,250 MB/s) ✅ Not bottleneck
  │
  └─ Cache    50,000 req/sec × 100 bytes = 5 MB/s
```

## Practical Network Design

### Architecture with Network Considerations

```
┌──────────────┐
│   Clients    │ (Global, 300ms+ latencies)
└───────┬──────┘
        │
        ├─────── CDN ─────────┐ (Edge locations)
        │                     │
        ├──────────────────────├─ Caches static assets
        │                      │
    ┌───▼──────────────────────▼────┐
    │  Load Balancer (30ms latency)  │
    └───┬──────────────────────────┬─┘
        │                          │
        │ TCP Keep-alive           │ Connection pooling
        │ HTTP Keep-alive          │ Multiplexing
        │                          │
    ┌───▼────────────────────────┬─▼──┐
    │   App Servers (3)          │    │ Same datacenter
    │   (< 1ms latency)          │    │ High bandwidth
    └───┬─────────────────────┬──┘    │
        │                     │       │
        │  Database           │ Cache │
        │  Cluster            │       │
```

## Network Monitoring

Key metrics to track:

```
Latency (p50, p95, p99):
────────────────────────
- p50: Median response time
- p95: 95% of requests faster than this
- p99: 99% of requests faster than this

Throughput:
───────────
- Requests/second
- Bytes/second
- Connections/second

Error Rates:
────────────
- Timeouts
- Connection refused
- DNS failures

Packet Loss:
────────────
- Retransmissions
- Drops due to congestion
```

## Practice Exercise

**Network Path Optimization**

You have:
- 1 million users worldwide
- Single origin server in AWS-US-East
- AWS: $0.02 per GB outbound
- CloudFront CDN: $0.085 per GB

Scenario:
- Average content size: 1 MB
- 50% users in US (nearby)
- 50% users in Europe/Asia (far)

Question:
```
1. What's the latency to European user
   from US-East?
2. How much data do you serve per month?
3. What's the cost with/without CDN?
4. Is CDN worth it?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Latency:
─────────
US-East to Europe: ~100-150 ms (too slow for many apps)

2. Data per month:
──────────────────
1M users × 1 MB × 30 days = 30 PB

US users: 30 PB × 0.5 = 15 PB
Intl users: 30 PB × 0.5 = 15 PB

3. Costs:
─────────
Without CDN:
- All 30 PB from origin
- Cost: 30 PB × $0.02/GB = 30 × 10^6 GB × $0.02
       = $600,000/month

With CDN:
- US: 15 PB served from local edge (cheap)
- Intl: 15 PB served from CDN edge + origin fetch
- CDN cost: 30 PB × $0.085/GB = $2.55 million/month
- Origin cost: 15 PB × $0.02/GB = $300,000/month
- Total: ~$2.85 million (MORE expensive!)

Wait, that's too much data!

Real scenario with realistic numbers:
─────────────────────────────────────
1M users × 10 requests/day × 50 KB = 500 TB/month

Without CDN: 500 TB × $0.02 = $10,000
With CDN: 500 TB × $0.085 = $42,500

❌ In this case, CDN costs more but:
✅ Latency improvement
✅ Origin server load reduction
✅ User experience better

For heavily cached content:
Origin fetch only 1% of requests
CDN cost: 500 TB × 0.01 × $0.085 + 500 TB × 0.99 × $0.085 ≈ $42,500

Actually, calculate by hit ratio!
If 80% cache hit rate:
- Egress from CDN edges: 400 TB × $0.085 = $34,000
- Origin egress: 100 TB × $0.02 = $2,000
- Total: $36,000 (reasonable for latency gains)
```

</details>

## Summary Checklist

- [ ] Understand TCP vs UDP (reliability vs speed)
- [ ] Know DNS resolution process
- [ ] HTTP/HTTPS differences (encryption matters)
- [ ] IPv4 private ranges for internal networks
- [ ] Firewall rules prevent unwanted traffic
- [ ] NAT provides security and address conservation
- [ ] Latency varies with geography (use CDN)
- [ ] Bandwidth bottlenecks at different layers
- [ ] Monitor network metrics continuously

## Next Steps

Continue to [Client-Server Architecture](../06-client-server/README.md) to learn the fundamental architecture pattern.

---

**Key Takeaway**: Network latency is irreducible by distance. Design systems knowing the limitations of physics.
