# Microservices Architecture

## Monolith vs Microservices

### The Monolith

```
Traditional monolithic application:
─────────────────────────────────────
One deployable unit containing everything:

┌──────────────────────────────────────┐
│           E-Commerce App              │
│                                       │
│  ┌──────────┐  ┌──────────┐           │
│  │  User    │  │ Product  │           │
│  │ Service  │  │ Catalog  │           │
│  └──────────┘  └──────────┘           │
│  ┌──────────┐  ┌──────────┐           │
│  │  Order   │  │ Payment  │           │
│  │ Service  │  │ Service  │           │
│  └──────────┘  └──────────┘           │
│  ┌──────────┐  ┌──────────┐           │
│  │  Email   │  │ Search   │           │
│  │ Service  │  │ Service  │           │
│  └──────────┘  └──────────┘           │
│                                       │
│         One Database                  │
└──────────────────────────────────────┘
           One Deployment

Pros:
✅ Simple to develop initially
✅ Simple to test (one process)
✅ Simple to deploy (one unit)
✅ No network latency between components
✅ Easy cross-component transactions (same DB)

Cons at scale:
❌ One team's bug breaks everyone
❌ Must deploy entire app to change one feature
❌ Long CI/CD pipelines (full regression each time)
❌ One slow feature slows everything
❌ Can only scale the whole app, not individual bottlenecks
❌ Technology lock-in (everyone uses Java or everyone suffers)
```

### Microservices

```
Microservices: split into small, independently deployable services:
────────────────────────────────────────────────────────────────────
┌──────────┐  ┌──────────┐  ┌──────────┐
│  User    │  │ Product  │  │  Order   │
│ Service  │  │ Service  │  │ Service  │
│          │  │          │  │          │
│  DB      │  │  DB      │  │  DB      │
└──────────┘  └──────────┘  └──────────┘

┌──────────┐  ┌──────────┐  ┌──────────┐
│ Payment  │  │  Email   │  │  Search  │
│ Service  │  │ Service  │  │ Service  │
│          │  │          │  │          │
│  DB      │  │  DB      │  │  DB      │
└──────────┘  └──────────┘  └──────────┘

Each service:
- Its own codebase, its own repo
- Its own database (no sharing)
- Its own deployment pipeline
- Its own team
- Communicates via APIs / events

Pros:
✅ Teams deploy independently (no coordination!)
✅ Scale individual services (only scale Order service if orders are slow)
✅ Technology freedom (User service = Java, Search service = Python)
✅ Fault isolation (Payment service crashes, doesn't take down Users)
✅ Smaller codebases → easier to understand

Cons:
❌ Distributed system complexity
❌ Network latency between services
❌ Distributed tracing is hard
❌ Data consistency is hard (no shared transactions)
❌ Operational overhead (100 services = 100 CI/CD pipelines, 100 deploy processes)
❌ Testing end-to-end flows requires multiple services running
```

### When to Use Each

```
Use a Monolith when:
─────────────────────
✅ Small team (< 10 engineers)
✅ Early stage startup (iterate fast, don't know the domain yet)
✅ Domain boundaries are unclear
✅ Simple deployment requirements

Start with a "modular monolith":
  - Clean module separation inside one codebase
  - Enforced module boundaries
  - Easy to split into services later when needed

Use Microservices when:
────────────────────────
✅ Multiple teams working on same product (need independent deployments)
✅ Different parts have very different scaling needs
✅ Different parts need different tech stacks
✅ You have DevOps maturity to operate many services
✅ Clear domain boundaries (DDD context boundaries)

Warning signs you're NOT ready:
❌ No dedicated DevOps/platform team
❌ Monolith isn't actually painful yet
❌ You don't understand your domain boundaries
```

## Microservice Principles

```
1. Single Responsibility
   ─────────────────────
   Each service does ONE thing well.
   Bad:  "UserAndOrderAndPaymentService"
   Good: "UserService", "OrderService", "PaymentService"

2. Loose Coupling
   ───────────────
   Services should NOT share databases.
   Services should NOT know about each other's internals.
   Changes to one service should NOT require changing another.

3. High Cohesion
   ──────────────
   Related things belong together.
   All user-related logic in one service.
   Don't split "create user" into one service and "update user" into another.

4. Independently Deployable
   ──────────────────────────
   You must be able to deploy one service without deploying any other.
   This requires stable API contracts between services.

5. Own Your Data
   ───────────────
   Each service owns its database exclusively.
   No other service can query it directly — must go through the API.
```

## Service Communication

### Synchronous: REST and gRPC

```mermaid
sequenceDiagram
    participant Client
    participant OrderSvc as Order Service
    participant UserSvc as User Service
    participant PaymentSvc as Payment Service

    Client->>OrderSvc: POST /orders
    OrderSvc->>UserSvc: GET /users/123 (verify user exists)
    UserSvc-->>OrderSvc: 200 OK {user data}
    OrderSvc->>PaymentSvc: POST /payments (charge card)
    PaymentSvc-->>OrderSvc: 200 OK {payment confirmation}
    OrderSvc-->>Client: 201 Created {order details}
```


### Asynchronous: Event-Driven

```
Event-driven approach:
───────────────────────
Order Service doesn't CALL Email Service.
Order Service PUBLISHES an event:
  "OrderPlaced { order_id: 123, user_id: 456, total: $99 }"

Email Service SUBSCRIBES to OrderPlaced events.
Email Service receives event → sends confirmation email.

                ┌─────────────┐
Order Svc ─────►│  Message    │◄──── Email Svc
                │  Broker     │◄──── Inventory Svc
Payment Svc ───►│  (Kafka,    │◄──── Analytics Svc
                │   RabbitMQ) │
                └─────────────┘

Pros:
✅ Services are decoupled (Order Svc doesn't know Email Svc exists)
✅ Easy to add new consumers (just subscribe to the event)
✅ Resilient (if Email Svc is down, events queue up; processes later)
✅ Natural audit log (event history in broker)

Cons:
❌ Eventual consistency (no immediate confirmation email)
❌ Harder to trace flows across services
❌ Event schema changes must be backward-compatible
❌ More operational complexity (need a broker)
```

## Service Discovery

```
Problem: With dynamic services (Kubernetes, cloud), IPs change constantly.
"Where is the Order Service right now?"

Client-Side Discovery:
───────────────────────
Service Registry (e.g., Eureka):
  - Each service registers itself: "Order Service is at 10.0.1.5:8080"
  - Client queries registry: "Where is Order Service?"
  - Client picks one instance, calls it directly

  Client → Registry: "Where is OrderSvc?"
  Registry → Client: "10.0.1.5:8080, 10.0.1.6:8080"
  Client → 10.0.1.5:8080: actual request

  ✅ Client controls load balancing
  ❌ Client needs registry client library
  ❌ Each language needs its own library

Server-Side Discovery:
───────────────────────
Load balancer / API Gateway handles discovery:
  - Client calls a stable address (load balancer)
  - Load balancer queries registry, picks instance, forwards

  Client → Load Balancer: "I want Order Service"
  Load Balancer → Registry: "Where is OrderSvc?"
  Load Balancer → 10.0.1.5:8080: forwards request

  ✅ Client is simple (no library needed)
  ✅ Works with any language
  ❌ Extra hop through load balancer

  Examples: AWS ALB + ECS, Kubernetes Service + kube-proxy
```

## API Gateway Pattern

```mermaid
graph TD
    Mobile["Mobile App"]
    Web["Web Browser"]
    Third["3rd Party"]

    GW["API Gateway\n─────────────\n• Auth/JWT validation\n• Rate limiting\n• SSL termination\n• Request routing\n• Response caching"]

    UserSvc["User\nService"]
    OrderSvc["Order\nService"]
    ProductSvc["Product\nService"]
    PaymentSvc["Payment\nService"]

    Mobile --> GW
    Web --> GW
    Third --> GW

    GW --> UserSvc
    GW --> OrderSvc
    GW --> ProductSvc
    GW --> PaymentSvc

    style GW fill:#7c3aed,stroke:#5b21b6,color:#fff
    style Mobile fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Web fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Third fill:#2563eb,stroke:#1d4ed8,color:#fff
    style UserSvc fill:#374151,stroke:#1f2937,color:#fff
    style OrderSvc fill:#374151,stroke:#1f2937,color:#fff
    style ProductSvc fill:#374151,stroke:#1f2937,color:#fff
    style PaymentSvc fill:#374151,stroke:#1f2937,color:#fff
```


## Data Ownership

```
Rule: Each service owns its database. No exceptions.

Why no shared databases?
──────────────────────────
If two services share a DB table:
  - Change to the schema must coordinate BOTH teams
  - One service's slow query affects the other
  - Can't scale their databases independently
  - Tight coupling through data layer

Pattern: Database per Service
───────────────────────────────
User Service  → PostgreSQL (relational, ACID needed)
Product Svc   → MongoDB (flexible catalog schema)
Search Svc    → Elasticsearch (full-text search)
Session Svc   → Redis (fast key-value)
Analytics Svc → ClickHouse (columnar, OLAP)

Each service picks the right tool for its data!

The hard part: queries that span services
──────────────────────────────────────────
"Get order details including user name and product info"

Option 1: API Composition
  Order Service calls User Service + Product Service,
  assembles the combined response.
  ✅ Simple   ❌ Multiple round trips, latency

Option 2: CQRS + Read Models
  When data changes, publish events.
  Build a denormalized "read model" joining the data.
  Query read model directly.
  ✅ Fast reads   ❌ Eventual consistency, more storage
```

## Distributed Tracing

```
Problem: A request flows through 5 services.
It's slow. Which service is the bottleneck?

Without tracing:
Service A logs: "Processed request in 500ms"
Service B logs: "Processed request in 50ms"
No way to correlate these logs!

With distributed tracing:
──────────────────────────
1. Assign a Trace ID to every incoming request
2. Propagate Trace ID in all downstream calls (via HTTP header)
3. Each service records a "span": start time, end time, Trace ID

Request: Trace ID = abc123

  API Gateway    [████░░░░░░░░░░░░] 500ms total
  └─ User Svc    [██░░] 200ms
  └─ Order Svc   [████████░░░░] 400ms  ← SLOW!
     └─ DB query [████████] 380ms      ← root cause

Tools: Jaeger, Zipkin, Datadog APM, AWS X-Ray
```

## Strangler Fig Pattern — Migration from Monolith

```
Don't rewrite the monolith from scratch (very risky!).
Gradually strangle it by extracting services one at a time.

                    New Services
                   ┌───────────┐
                   │  User Svc │
All Traffic        │  (new)    │
   │               └───────────┘
   ▼                      ▲
┌──────────┐   Routes to  │
│  Proxy / │──────────────┘
│  Gateway │
│          │──────────────┐
└──────────┘   Still      │
               routes to  ▼
                    ┌───────────┐
                    │ Monolith  │
                    │ (legacy)  │
                    └───────────┘

Migration steps:
─────────────────
Phase 1: Add proxy/gateway in front of monolith
Phase 2: Extract one service (e.g., User Service)
Phase 3: Route /api/users traffic to User Service
         All other traffic still goes to monolith
Phase 4: Extract next service
Phase 5: ... repeat until monolith is empty
Phase 6: Retire the monolith

Why it's called "Strangler Fig":
A strangler fig vine wraps around a tree over years.
Eventually the original tree dies, leaving only the fig.
```

## Monolith vs Microservices — Architecture Diagrams

```mermaid
graph TD
    subgraph mono["Monolith"]
        MC["Client"]
        MA["Single App\n─────────────────\nUser Logic\nOrder Logic\nPayment Logic\nEmail Logic\nSearch Logic"]
        MDB["Single Database"]
        MC --> MA
        MA --> MDB
    end

    subgraph micro["Microservices"]
        CC["Client"]
        APIGW["API Gateway"]
        US["User\nService"]
        OS["Order\nService"]
        PS["Payment\nService"]
        ES["Email\nService"]
        SS["Search\nService"]
        UDB["User DB"]
        ODB["Order DB"]
        PDB["Payment DB"]
        MQ["Message\nBroker"]

        CC --> APIGW
        APIGW --> US
        APIGW --> OS
        APIGW --> PS
        OS --> MQ
        MQ --> ES
        MQ --> SS
        US --> UDB
        OS --> ODB
        PS --> PDB
    end

    style MA fill:#7c3aed,stroke:#5b21b6,color:#fff
    style APIGW fill:#7c3aed,stroke:#5b21b6,color:#fff
    style US fill:#2563eb,stroke:#1d4ed8,color:#fff
    style OS fill:#2563eb,stroke:#1d4ed8,color:#fff
    style PS fill:#2563eb,stroke:#1d4ed8,color:#fff
    style ES fill:#059669,stroke:#047857,color:#fff
    style SS fill:#059669,stroke:#047857,color:#fff
    style MQ fill:#f59e0b,stroke:#d97706,color:#fff
    style MDB fill:#374151,stroke:#1f2937,color:#fff
    style UDB fill:#374151,stroke:#1f2937,color:#fff
    style ODB fill:#374151,stroke:#1f2937,color:#fff
    style PDB fill:#374151,stroke:#1f2937,color:#fff
```

## Trade-offs Summary

| Factor | Monolith | Microservices |
|---|---|---|
| Development speed (early) | Fast | Slow (infra setup) |
| Development speed (at scale) | Slow (coordination) | Fast (independent teams) |
| Deployment | Simple (one unit) | Complex (many pipelines) |
| Scaling | Whole app scales together | Scale individual services |
| Data consistency | Easy (one DB) | Hard (distributed) |
| Debugging | Simple (one process) | Hard (distributed traces) |
| Technology flexibility | Low (one stack) | High (polyglot) |
| Fault isolation | None (one crash = all down) | Contained to one service |
| Operational overhead | Low | Very high |

## Interview Tips

```
Common interview questions on microservices:

Q: "How do two microservices share data?"
A:
  ✅ They don't share a database — that's a rule
  ✅ Synchronous: Service A calls Service B's API
  ✅ Asynchronous: Service A publishes event; Service B subscribes
  ✅ Read models: build denormalized views from events (CQRS)

Q: "How do you handle a transaction across multiple services?"
A:
  ✅ Distributed transactions (2PC) are too fragile — avoid
  ✅ Saga pattern: sequence of local transactions with compensating actions
  ✅ Example: Order Saga: CreateOrder → ReserveInventory → ChargePayment
  ✅ If ChargePayment fails: compensate → ReleaseInventory → CancelOrder

Q: "When would you NOT use microservices?"
A:
  ✅ Small teams where coordination overhead > benefit
  ✅ Early startups where domain isn't understood yet
  ✅ Systems requiring complex multi-entity transactions
  ✅ When you don't have DevOps maturity to operate them

Q: "What is a service mesh?"
A:
  ✅ Infrastructure layer that handles service-to-service communication
  ✅ Sidecar proxy (Envoy) injected alongside every service
  ✅ Handles: retries, timeouts, circuit breaking, mTLS, observability
  ✅ Examples: Istio, Linkerd, Consul Connect
  ✅ App code doesn't need to implement these — sidecar does it
```

## Practice Exercise

**Decompose an e-commerce platform into microservices**

```
Monolith features:
- User registration/login
- Product catalog and search
- Shopping cart
- Order placement and tracking
- Payment processing
- Email notifications
- Inventory management

Questions:
1. How would you split this into services?
2. What communication pattern between each pair of services?
3. How would you handle "place an order" as a transaction?
4. What service would you extract first from the monolith?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Service split:
   ──────────────
   User Service     — registration, login, profiles
   Product Service  — catalog, product details
   Search Service   — Elasticsearch-backed search
   Cart Service     — shopping cart (Redis-backed)
   Order Service    — order creation, tracking
   Payment Service  — payment processing
   Notification Svc — email, SMS, push notifications
   Inventory Svc    — stock levels, reservations

2. Communication patterns:
   ─────────────────────────
   Cart → Product: sync (REST) — need product price right now
   Order → Cart: sync (REST) — read cart contents at checkout
   Order → Inventory: sync (REST) — reserve stock immediately
   Order → Payment: sync (gRPC) — need payment result before confirming
   Order → Notification: async (event) — email can be slightly delayed
   Order → Analytics: async (event) — analytics don't need to be instant

3. "Place an order" saga:
   ──────────────────────
   Step 1: CreateOrder (OrderSvc) — creates PENDING order
   Step 2: ReserveInventory (InventorySvc) — reserve items
   Step 3: ProcessPayment (PaymentSvc) — charge card

   Failures:
   Payment fails → compensate: ReleaseInventory → CancelOrder
   Inventory fails → compensate: CancelOrder (nothing to release yet)

4. First service to extract:
   ──────────────────────────
   ✅ Notification Service (Email/SMS)
   Reason:
   - Low risk (failure just means delayed email, not lost order)
   - Clearly separated domain
   - Easy to convert to event-driven (subscribe to events)
   - Good practice run before extracting critical services
```

</details>

## Summary

- **Start with a monolith** — split into services only when coordination costs hurt real teams
- **Microservices enable independent deployment** — the #1 benefit is team autonomy
- **Each service owns its database** — shared databases create hidden coupling
- **Event-driven async** decouples services; synchronous calls are simpler but create tight dependencies
- **Saga pattern** replaces distributed transactions — accept eventual consistency
- **Strangler Fig** is the safe migration path — never do a big-bang rewrite

## Next Steps

Continue to [Message Queues](../18-message-queues/README.md) to learn how async communication with queues works in depth.

---

**Key Takeaway**: Microservices solve a people/organizational problem (team autonomy), not just a technical one. If you're a small team, a well-structured monolith will outperform microservices every time.
