# CDN (Content Delivery Networks)

## Why CDNs Exist

```
Problem: Distance adds latency
────────────────────────────────
Origin server in New York
User in Tokyo

Speed of light: ~200,000 km/s (in fiber)
NY → Tokyo distance: ~10,900 km

Round-trip time (theoretical minimum): ~110ms
With TCP overhead, routing hops: 200–300ms

For a page with 50 assets (JS, CSS, images):
50 × 250ms = 12.5 seconds to load!

Solution: Serve assets from a server near the user
──────────────────────────────────────────────────
Edge server in Tokyo
User in Tokyo

Round-trip: 5–20ms
50 × 10ms = 0.5 seconds  ✅  (25× faster)
```

## What is a CDN?

```
CDN = Content Delivery Network

A globally distributed network of servers ("edge servers" or "PoPs")
that cache and serve content from locations close to end users.

Core idea:
──────────
Instead of all traffic hitting the origin server,
CDN edge servers absorb requests and serve cached responses.

Benefits:
─────────
✅ Reduced latency (serve from nearby edge)
✅ Reduced bandwidth costs (edge absorbs traffic)
✅ DDoS protection (distributed, absorbs attack volume)
✅ High availability (if origin is down, edge may still serve cache)
✅ Improved throughput (edge servers handle load, not your origin)
```

## CDN Architecture

```mermaid
flowchart TB
    subgraph Users["End Users"]
        U1["User: Tokyo"]
        U2["User: London"]
        U3["User: São Paulo"]
    end

    subgraph PoPs["CDN Points of Presence (PoPs)"]
        E1["Edge Server<br/>Tokyo PoP"]
        E2["Edge Server<br/>London PoP"]
        E3["Edge Server<br/>São Paulo PoP"]
    end

    subgraph Origin["Origin Infrastructure"]
        O["Origin Server<br/>(New York)"]
    end

    U1 -->|"request"| E1
    U2 -->|"request"| E2
    U3 -->|"request"| E3

    E1 -->|"cache miss only"| O
    E2 -->|"cache miss only"| O
    E3 -->|"cache miss only"| O

    style U1 fill:#374151,color:#fff
    style U2 fill:#374151,color:#fff
    style U3 fill:#374151,color:#fff
    style E1 fill:#2563eb,color:#fff
    style E2 fill:#2563eb,color:#fff
    style E3 fill:#2563eb,color:#fff
    style O fill:#7c3aed,color:#fff
```

## DNS-Based Routing

**How a user ends up at the nearest edge server**

```mermaid
sequenceDiagram
    participant User as User (Tokyo)
    participant DNS as CDN DNS
    participant Edge as Tokyo Edge
    participant Origin as Origin (NY)

    User->>DNS: Resolve cdn.example.com
    Note over DNS: Detects user is in Tokyo<br/>via anycast or GeoDNS
    DNS-->>User: Returns Tokyo edge IP (1.2.3.4)

    User->>Edge: GET /image.jpg
    alt Cache Hit
        Edge-->>User: 200 OK (from cache, ~10ms)
    else Cache Miss
        Edge->>Origin: GET /image.jpg
        Origin-->>Edge: 200 OK + Cache-Control headers
        Edge->>Edge: Store in local cache
        Edge-->>User: 200 OK (fetched from origin, ~250ms)
    end
```

**Routing methods:**

```
1. GeoDNS:
──────────
DNS resolver returns different IP based on user's location.
User in Tokyo → Tokyo PoP IP
User in London → London PoP IP
Simple, widely used.

2. Anycast:
──────────
Multiple PoPs share the same IP address.
Network routing protocols (BGP) automatically direct
packets to the topologically nearest PoP.
Used by Cloudflare — all PoPs share 1.1.1.1 for their DNS.

3. HTTP Redirect:
─────────────────
Origin detects user location (via IP geolocation),
returns HTTP 302 pointing to nearest edge URL.
Rare, adds an extra round-trip.
```

## Cache Hit / Miss Flow

```mermaid
flowchart TD
    Req["User Request<br/>GET /logo.png"]
    Check{"Cache Check<br/>at Edge"}

    Hit["Cache HIT<br/>File in edge cache<br/>Not expired"]
    Miss["Cache MISS<br/>File not in cache<br/>or expired"]

    Serve["Serve from edge cache<br/>~5-20ms response"]
    Fetch["Fetch from origin server<br/>~200-300ms"]
    Store["Store in edge cache<br/>with TTL"]
    ServeF["Serve to user<br/>~200-350ms total"]

    Req --> Check
    Check -->|"HIT"| Hit
    Check -->|"MISS"| Miss
    Hit --> Serve
    Miss --> Fetch
    Fetch --> Store
    Store --> ServeF

    style Hit fill:#059669,color:#fff
    style Miss fill:#ef4444,color:#fff
    style Serve fill:#059669,color:#fff
    style Fetch fill:#f59e0b,color:#fff
    style Store fill:#2563eb,color:#fff
    style ServeF fill:#374151,color:#fff
```

**Cache status headers:**

```
X-Cache: HIT         (served from edge cache)
X-Cache: MISS        (fetched from origin)
X-Cache: EXPIRED     (cache existed but TTL elapsed)
X-Cache: BYPASS      (request bypassed cache)

Age: 3600            (seconds this response has been in cache)
CF-Cache-Status: HIT (Cloudflare-specific)
```

## TTL and Cache Invalidation

### Setting TTL

```
Cache-Control header controls TTL:
────────────────────────────────────

Cache-Control: max-age=86400, public
  └─ Edge (and browsers) cache for 86400 seconds (1 day)

Cache-Control: max-age=31536000, immutable
  └─ Cache for 1 year. Used for content-addressed assets:
     /app.a3f5b1.js  (hash in filename changes when content changes)

Cache-Control: no-cache
  └─ Must revalidate with origin before each use

Cache-Control: no-store
  └─ Never cache (sensitive data, logged-in content)

Cache-Control: private
  └─ Browser can cache but CDN cannot (personalized content)
```

### Cache Invalidation Strategies

```
1. TTL Expiration (simplest):
──────────────────────────────
Wait for TTL to expire. Cache naturally refreshes.
Pros: Zero complexity, no API calls needed.
Cons: Stale content served until TTL expires.

Best for: Images, fonts, marketing pages (low change rate).

2. Cache Purge (immediate):
────────────────────────────
Manually invalidate a specific URL via CDN API.
CDN providers expose purge endpoints.

Cloudflare:
  POST /zones/{zone_id}/purge_cache
  { "files": ["https://example.com/image.png"] }

AWS CloudFront:
  aws cloudfront create-invalidation \
    --distribution-id E1234 \
    --paths "/image.png" "/*.js"

Pros: Instant propagation (minutes).
Cons: API call required, can be expensive at scale.

3. Cache-Busting (best practice):
───────────────────────────────────
Instead of invalidating, change the URL when content changes.
Content-addressed filenames: /app.a3f5b1.js

Old file: /app.a3f5b1.js (still cached at CDN, still served)
New file: /app.d8c2e7.js (new URL, cold cache, fetches from origin)

Pros: No invalidation needed. Works perfectly with long TTLs.
Cons: Requires build tooling to generate hashed filenames.

Used by: Webpack, Vite, Create React App (out of the box)
```

## Static vs Dynamic Content

```mermaid
flowchart LR
    subgraph Static["Static Assets (CDN Ideal)"]
        S1["Images<br/>TTL: days/weeks"]
        S2["JS / CSS bundles<br/>TTL: 1 year (hashed)"]
        S3["Fonts<br/>TTL: 1 year"]
        S4["Videos / Downloads<br/>TTL: hours/days"]
    end

    subgraph Dynamic["Dynamic Content (Tricky)"]
        D1["HTML pages<br/>TTL: 0-5min or no-cache"]
        D2["API responses<br/>Varies: 0s to 60s"]
        D3["User-specific pages<br/>Cache-Control: private"]
    end

    subgraph Uncacheable["Never Cache"]
        U1["Shopping cart"]
        U2["Auth tokens"]
        U3["Real-time data"]
    end

    style S1 fill:#059669,color:#fff
    style S2 fill:#059669,color:#fff
    style S3 fill:#059669,color:#fff
    style S4 fill:#059669,color:#fff
    style D1 fill:#f59e0b,color:#fff
    style D2 fill:#f59e0b,color:#fff
    style D3 fill:#f59e0b,color:#fff
    style U1 fill:#ef4444,color:#fff
    style U2 fill:#ef4444,color:#fff
    style U3 fill:#ef4444,color:#fff
```

**Edge-side rendering (advanced):**

```
Modern CDNs can run code at the edge:
──────────────────────────────────────
Cloudflare Workers, AWS Lambda@Edge, Vercel Edge Functions

Use cases:
- A/B testing at the edge (no origin round-trip)
- Auth checks (validate JWT without hitting origin)
- Personalization (vary response based on geo/cookie)
- HTML rewriting (inject tracking pixels)

Example: Cloudflare Worker for A/B test
  addEventListener('fetch', event => {
    const variant = Math.random() < 0.5 ? 'A' : 'B';
    // Rewrite URL to /homepage-a or /homepage-b
    // without user knowing
  })
```

## CDN Providers Compared

| Feature | Cloudflare | AWS CloudFront | Fastly |
|---|---|---|---|
| **PoP count** | 300+ | 450+ | 60+ |
| **Pricing model** | Flat rate (generous free tier) | Per GB + per request | Pay as you go |
| **Edge compute** | Workers (V8 isolates) | Lambda@Edge | Compute@Edge (Wasm) |
| **Purge speed** | ~150ms globally | 5–10 minutes | ~150ms |
| **DDoS protection** | Built-in (magic transit) | AWS Shield | Built-in |
| **Best for** | Startups, most use cases | AWS-native apps | Enterprise, real-time |
| **Free tier** | Yes (unlimited bandwidth) | No | No |

```
Cloudflare:
───────────
Most popular. Aggressive pricing. Protects against DDoS.
Anycast network — all PoPs share same IP.
Workers allow powerful edge logic.
Free tier is genuinely useful for startups.

AWS CloudFront:
───────────────
Native integration with S3, EC2, ALB.
Good if already on AWS (single bill, IAM integration).
Slower cache invalidation (minutes vs milliseconds for Cloudflare).

Fastly:
───────
Best-in-class real-time log streaming and instant purge.
Popular with media companies (GitHub uses Fastly).
More expensive but more control.
```

## CDN for Video Streaming

```
Challenge: Large files, many concurrent viewers
────────────────────────────────────────────────

Standard CDN:
─────────────
Cache the video file on edge servers.
Works well for on-demand video (Netflix, YouTube).
Edge serves the bytes directly.

Chunked / Adaptive Bitrate Streaming:
──────────────────────────────────────
Video split into 2-10 second segments.
Multiple quality levels (240p, 480p, 1080p, 4K).
Player fetches the right segment for current bandwidth.

Example (HLS):
  /video/episode1/
    master.m3u8           (playlist, references qualities)
    1080p/segment001.ts   (first 4 seconds in 1080p)
    1080p/segment002.ts
    480p/segment001.ts    (same content, lower quality)

CDN caches each segment individually.
Cache hit rate is very high (same segments watched by millions).
```

## Performance Impact

```
Typical improvements with CDN:
────────────────────────────────

Time to First Byte (TTFB):
Without CDN (NY to Tokyo): 250ms
With CDN (Tokyo edge):      15ms
Improvement: 16× faster

Page Load Time:
Without CDN: 3.2 seconds
With CDN:    1.1 seconds
Improvement: ~3× faster

Bandwidth cost:
Without CDN: 100% traffic hits origin servers
With CDN:    5-15% cache miss (hits origin)
Savings: 85-95% reduction in origin bandwidth

Example real numbers (1M daily users, 100KB page):
Origin bandwidth without CDN: 100GB/day
Origin bandwidth with CDN:    5GB/day (95% cache hit rate)
```

## CDN Security Features

```
WAF (Web Application Firewall):
────────────────────────────────
CDN sits in front of origin, inspects requests.
Block SQL injection, XSS, bot traffic.
Cloudflare's WAF stops millions of attacks daily.

DDoS Mitigation:
─────────────────
CDN's distributed network absorbs volumetric attacks.
Cloudflare regularly absorbs 1+ Tbps attacks.
Traffic filtered at edge, never reaches origin.

SSL Termination:
─────────────────
CDN terminates TLS at the edge.
User-to-edge: HTTPS.
Edge-to-origin: Can be HTTP (private network) or HTTPS.
Reduces TLS handshake overhead for users.
Free SSL certificates via CDN (Let's Encrypt / CDN-issued certs).
```

## Common CDN Pitfalls

```
1. Caching private data:
────────────────────────
❌ Wrong: Serve user-specific pages with public CDN cache.
   User A sees User B's dashboard!
✅ Fix: Cache-Control: private, or vary by auth cookie.

2. Stale content after deploy:
───────────────────────────────
❌ Wrong: Deploy new JS without cache-busting filenames.
   Users get old JS from CDN for days.
✅ Fix: Content-addressed filenames or CDN purge on deploy.

3. Ignoring cache headers:
───────────────────────────
❌ Wrong: Origin sends no Cache-Control headers.
   CDN either won't cache, or uses its own defaults (unpredictable).
✅ Fix: Always set explicit Cache-Control headers.

4. Forgetting CORS:
────────────────────
❌ Wrong: CDN caches response without Vary: Origin header.
   Browser from different origin gets wrong CORS headers.
✅ Fix: Set Vary: Origin on CORS responses so CDN caches per origin.

5. Large cache keys:
─────────────────────
❌ Wrong: Vary on Accept-Encoding, User-Agent, Cookie.
   Every variant is a separate cache entry — low hit rate.
✅ Fix: Normalize cache keys, strip irrelevant headers before caching.
```

## Interview Tips

```
Common interview questions on CDNs:
─────────────────────────────────────

Q: "How does a CDN improve latency?"
A: By serving content from an edge server geographically close to the
   user, instead of from a distant origin server. Physical distance
   is eliminated, reducing round-trip time from 200-300ms to 5-20ms.

Q: "How do you handle cache invalidation in a CDN?"
A: Three strategies: (1) Let TTL expire naturally — simplest, for
   rarely-changing content. (2) Cache-busting — embed content hash
   in filenames so new deploys get new URLs; old URLs stay cached.
   (3) CDN purge API — for urgent invalidation of specific URLs.

Q: "What content should NOT be cached by a CDN?"
A: User-specific data (dashboards, account pages), real-time data
   (stock prices, live scores), authentication tokens, shopping
   carts, and anything with Cache-Control: private or no-store.

Q: "What is a PoP?"
A: Point of Presence — a CDN data center in a specific geographic
   location. Each PoP contains edge servers that cache content and
   serve users in that region.

Q: "How does Cloudflare's anycast work?"
A: All Cloudflare PoPs advertise the same IP addresses via BGP.
   When a user's request arrives at an internet router, BGP routes
   it to the topologically closest PoP automatically.
```

## Practice Exercise

**Design a CDN strategy for a video streaming platform**

```
Requirements:
─────────────
- 10 million daily active users worldwide
- 50,000 video titles, each 1-4GB
- Users in North America, Europe, Asia
- Titles updated rarely (maybe 1% per day)
- Live streaming for 10 events per day

Questions:
1. What TTL for video segments?
2. How to handle cache invalidation for updated videos?
3. How to handle live streaming differently from on-demand?
4. Which CDN provider would you choose?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. TTL for video segments:
   ────────────────────────
   On-demand segments: max-age=2592000 (30 days), immutable
   They never change once encoded (use content-addressed URLs).
   Playlist files (.m3u8): max-age=60 (1 minute) — might change.

2. Cache invalidation for updated videos:
   ─────────────────────────────────────────
   Re-encode the video → new content hashes → new filenames.
   Old segments expire naturally (they're still cached but no
   longer referenced by playlists). No purge needed.
   Only purge the playlist (.m3u8) files when content changes.

3. Live streaming:
   ─────────────────
   Live segments: short TTL (5-10 seconds) — constantly new.
   Use CDN as a live origin shield, not a cache.
   Fastly or Cloudflare Stream are purpose-built for live video.
   HLS/DASH with 2-second segments. Low-latency HLS (LL-HLS) for
   sub-3 second latency.

4. CDN choice:
   ───────────
   Cloudflare Stream or AWS CloudFront with MediaPackage.
   For this scale, a media-specialized CDN is worth the cost.
   Multi-CDN strategy (two providers) ensures no single point of
   failure for video delivery.
```

</details>

## Summary

- **CDNs reduce latency** by serving content from edge servers close to users — turning 250ms round-trips into 15ms
- **DNS routing** (GeoDNS or Anycast) directs users to the nearest PoP automatically
- **Cache hit rate** is the key metric — target 90%+ for static assets
- **TTL + cache-busting** is the best combination: long TTLs for immutable assets, new URLs on content change
- **Static assets** (JS, CSS, images) are perfect for CDN; **dynamic/personal content** requires careful cache-control headers
- **CDNs double as security** — WAF, DDoS protection, and SSL termination at the edge
- **Cloudflare** for most use cases; **CloudFront** for AWS-native; **Fastly** for real-time and media

## Next Steps

Continue to [Databases Deep Dive](../13-databases/README.md) to understand how databases store and retrieve data efficiently.

---

**Key Takeaway**: A CDN is one of the highest-leverage infrastructure investments — it dramatically improves performance, reduces costs, and increases reliability with minimal application changes.
