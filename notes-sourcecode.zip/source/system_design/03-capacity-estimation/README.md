# Capacity Estimation

## Why Estimate Capacity?

Capacity estimation (also called "back-of-the-envelope" calculations) helps you:

- **Choose the right architecture**: Monolith vs microservices?
- **Size infrastructure**: How many servers? What database?
- **Estimate costs**: How much will this cost per month?
- **Identify bottlenecks**: Where will we hit limits?
- **Plan for scale**: When do we need to scale up?

## Key Principle: Be Approximately Right

```
Perfect accuracy: ❌ Not needed
Ballpark accuracy: ✅ Good enough

Examples:
- "About 10,000 requests/second" ✅
- "Between 8,000 and 12,000 requests/second" ✅
- "Exactly 10,247 requests/second" ❌ Over-precise
```

## Essential Numbers Every Engineer Should Know

### Latency Numbers (2025 Estimates)

```
Operation                           Time (nanoseconds)    Time (human scale)
─────────────────────────────────────────────────────────────────────────────
L1 cache reference                  1 ns                 1 second
L2 cache reference                  4 ns                 4 seconds
Main memory reference               100 ns               100 seconds (1.7 min)
SSD random read                     16,000 ns            4.4 hours
Send 1 KB over network              10,000 ns            2.8 hours
Read 1 MB sequentially from SSD     200,000 ns           2.3 days
Disk seek                           2,000,000 ns         23 days
Read 1 MB sequentially from disk    5,000,000 ns         58 days
Send packet US → Europe → US        150,000,000 ns       4.8 years
```

### Key Takeaways

1. **Memory is fast, disk is slow** (10,000x difference)
2. **Network within datacenter is fast** (< 1ms)
3. **Cross-region network is slow** (50-200ms)
4. **SSDs are 100x faster than HDDs**
5. **Sequential reads are faster than random reads**

### Useful Conversion Numbers

```
Powers of 2:
2^10 = 1 KB (thousand)
2^20 = 1 MB (million)
2^30 = 1 GB (billion)
2^40 = 1 TB (trillion)
2^50 = 1 PB (quadrillion)

Time:
1 second = 1,000 milliseconds (ms)
1 ms = 1,000 microseconds (μs)
1 μs = 1,000 nanoseconds (ns)

Time Periods:
1 minute = 60 seconds
1 hour = 3,600 seconds
1 day = 86,400 seconds (~100K)
1 month = 2.5M seconds
1 year = 31.5M seconds (~30M)

Availability:
99% = 3.65 days downtime/year
99.9% (3 nines) = 8.76 hours/year
99.99% (4 nines) = 52.56 minutes/year
99.999% (5 nines) = 5.26 minutes/year
```

## The Estimation Framework

### Step 1: Traffic Estimation

Calculate **Queries Per Second (QPS)**

```
Formula:
QPS = Daily Active Users × Actions per User / 86,400

Example: Twitter
─────────────────────────────────────
DAU: 200 million users
Each user: 20 tweet views per day

Read QPS = 200M × 20 / 86,400
         = 4,000,000,000 / 86,400
         ≈ 46,000 reads/second

Write QPS (assume 1 tweet per user per day):
Write QPS = 200M × 1 / 86,400
          ≈ 2,300 writes/second

Peak Traffic (assume 3x average):
Peak Read QPS = 46,000 × 3 = 138,000
Peak Write QPS = 2,300 × 3 = 6,900
```

### Step 2: Storage Estimation

Calculate **Total Storage Needed**

```
Formula:
Storage = Items × Size per Item × Retention Period

Example: Twitter
─────────────────────────────────────
Tweets per day: 200M × 1 = 200M tweets
Tweet size:
  - Text: 280 chars × 2 bytes = 560 bytes
  - Metadata: 200 bytes
  - Total: ~1 KB per tweet (rounding up)

Daily Storage = 200M tweets × 1 KB
              = 200 GB/day

Yearly Storage = 200 GB × 365
               ≈ 73 TB/year

5-Year Storage = 73 TB × 5
               ≈ 365 TB

With Media (30% tweets have images):
Image size: 200 KB average
Media storage = 200M × 0.3 × 200 KB
              = 12 TB/day
              = 4.4 PB/year
```

### Step 3: Bandwidth Estimation

Calculate **Network Bandwidth Required**

```
Formula:
Bandwidth = Data Size × QPS

Example: Twitter
─────────────────────────────────────
Read Operations:
- Tweet data: 1 KB
- Read QPS: 46,000

Read Bandwidth = 1 KB × 46,000
               = 46 MB/second
               = 368 Mbps

Write Operations:
- Tweet data: 1 KB
- Write QPS: 2,300

Write Bandwidth = 1 KB × 2,300
                = 2.3 MB/second
                = 18.4 Mbps

Total Bandwidth ≈ 400 Mbps (with overhead)
```

### Step 4: Memory (Cache) Estimation

Calculate **Cache Size** using the 80/20 rule

```
Rule: 20% of data generates 80% of traffic

Example: Twitter
─────────────────────────────────────
Daily requests: 46,000 × 86,400 = 4B requests
Each request: 1 KB

Total daily data: 4B × 1 KB = 4 TB

Cache (20% of daily data):
Cache Size = 4 TB × 0.2 = 800 GB

This is manageable with Redis/Memcached!
```

## Complete Example: URL Shortener

Let's design a URL shortener like bit.ly with complete capacity estimation.

### Requirements
```
- 100M new URLs per month
- Read:Write ratio = 100:1
- URLs stored for 10 years
- 7-character short codes
```

### 1. Traffic Estimation

```
Write Operations:
────────────────
New URLs per month: 100M
New URLs per second = 100M / (30 × 86,400)
                    = 100M / 2.6M
                    ≈ 40 writes/second

Read Operations:
────────────────
Read:Write ratio = 100:1
Reads per second = 40 × 100
                 = 4,000 reads/second

Peak Traffic (3x):
────────────────
Peak writes = 40 × 3 = 120/second
Peak reads = 4,000 × 3 = 12,000/second
```

### 2. Storage Estimation

```
Data per URL:
────────────
- Original URL: 500 bytes (average)
- Short code: 7 bytes
- Created date: 8 bytes
- User ID: 8 bytes
- Total: ~500 bytes (rounding)

Total URLs in 10 years:
────────────────────────
100M per month × 12 months × 10 years = 12B URLs

Total Storage:
────────────
12B URLs × 500 bytes = 6 TB

With Indexing (assume 30% overhead):
────────────────────────────────────
6 TB × 1.3 = 7.8 TB ≈ 8 TB
```

### 3. Bandwidth Estimation

```
Write Bandwidth:
────────────────
40 writes/sec × 500 bytes = 20 KB/second

Read Bandwidth:
────────────────
4,000 reads/sec × 500 bytes = 2 MB/second

Total: ~2 MB/second = 16 Mbps (negligible)
```

### 4. Cache Estimation

```
Daily Reads:
────────────
4,000 reads/sec × 86,400 = 345M reads/day

Using 80/20 rule:
────────────────
20% of URLs generate 80% of traffic

Cache Size = 345M × 0.2 × 500 bytes
           = 34.5 GB

Recommendation: 50 GB cache (with buffer)
```

### 5. Database Considerations

```
Number of Short Codes Possible:
────────────────────────────────
7 characters [a-z, A-Z, 0-9]
62^7 = 3.5 trillion combinations

We need: 12 billion
Utilization: 12B / 3.5T = 0.3% ✅ Plenty of space!

Database Choice:
────────────────
- 8 TB storage needed
- 40 writes/second (easy)
- 4,000 reads/second (easy with replicas)

Options:
✅ PostgreSQL: Can handle this easily
✅ MySQL: Can handle this easily
✅ NoSQL (DynamoDB/Cassandra): Overkill but works

Recommendation: PostgreSQL with 2 read replicas
```

### 6. Server Estimation

```
Application Servers:
────────────────────
Assume 1 server handles 1,000 requests/second

Peak: 12,000 reads/sec + 120 writes/sec ≈ 12,120 req/sec
Servers needed: 12,120 / 1,000 = 12.12 ≈ 13 servers

With N+2 redundancy: 15 application servers
```

### Summary Table

```
Metric                  Value
──────────────────────────────────────
Write QPS               40 (120 peak)
Read QPS                4,000 (12,000 peak)
Storage (10 years)      8 TB
Bandwidth               16 Mbps
Cache Size              50 GB
Database                PostgreSQL + 2 replicas
App Servers             15 servers
Estimated Cost          $5,000/month
```

## Estimation Shortcuts

### Quick Rounding Rules

```
When multiplying:
─────────────────
86,400 seconds/day → Use 100,000 (10^5)
30 days/month → Use 2.5M seconds
365 days/year → Use 400 days (easier math)

When dividing:
──────────────
1 million ÷ 100,000 = 10
1 billion ÷ 1 million = 1,000
1 trillion ÷ 1 billion = 1,000

Powers of 10:
─────────────
Thousand = 10^3 = 1K
Million = 10^6 = 1M
Billion = 10^9 = 1B
Trillion = 10^12 = 1T
```

### Common Ratios

```
Read:Write Ratios by System:
────────────────────────────
Social Media Feed: 100:1 (read heavy)
Analytics: 1:100 (write heavy)
E-commerce: 10:1 (read heavy)
Chat: 1:1 (balanced)
Logging: 0:1 (write only)

Peak to Average Traffic:
────────────────────────
E-commerce: 10x (Black Friday)
News sites: 5x (breaking news)
Social media: 3x (evening hours)
Business apps: 2x (work hours)
```

## Cost Estimation

### AWS Pricing Example (2025 approximate)

```
Compute (EC2):
──────────────
- m5.large: $0.10/hour = $75/month
- 15 servers = $1,125/month

Database (RDS PostgreSQL):
──────────────────────────
- db.m5.xlarge: $0.20/hour = $150/month
- 3 instances = $450/month
- Storage: 10 TB × $0.10/GB = $1,000/month

Cache (ElastiCache Redis):
──────────────────────────
- cache.m5.large: $0.15/hour = $112/month
- 50 GB storage: $50/month

Load Balancer:
──────────────
- $20/month + data transfer

Bandwidth:
──────────
- First 10 TB: $0.09/GB = $900/month

Total: ~$3,700/month (without redundancy/backups)
With prod best practices: ~$6,000-8,000/month
```

## Common Estimation Mistakes

### 1. Forgetting Peak Traffic

```
❌ Only calculating average load
✅ Always calculate peak (2-3x average)
```

### 2. Ignoring Replication

```
❌ Storage = 8 TB
✅ Storage = 8 TB × 3 replicas = 24 TB
```

### 3. No Buffer/Headroom

```
❌ Need 10 servers → provision 10
✅ Need 10 servers → provision 12-13 (20% buffer)
```

### 4. Over-Precision

```
❌ "We need 237.6 MB of cache"
✅ "We need about 250 MB of cache"
```

### 5. Forgetting Indexing Overhead

```
❌ Storage = raw data size
✅ Storage = raw data × 1.3 (30% for indexes)
```

## Practice Exercises

### Exercise 1: Design Instagram

```
Requirements:
- 500M users
- 50M photos uploaded/day
- Average photo size: 2 MB
- Users view 20 photos/day
- Read:Write ratio: 100:1

Calculate:
1. Read and write QPS
2. Storage for 5 years
3. Bandwidth requirements
4. Cache size (20% of daily data)
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Traffic:
───────────
Write QPS = 50M / 86,400 ≈ 580 writes/second
Read QPS = 580 × 100 = 58,000 reads/second

2. Storage:
───────────
Daily: 50M × 2 MB = 100 TB/day
Yearly: 100 TB × 365 = 36.5 PB/year
5 Years: 36.5 × 5 = 182.5 PB

3. Bandwidth:
─────────────
Write: 580 × 2 MB = 1.16 GB/second = 9.3 Gbps
Read: 58,000 × 2 MB = 116 GB/second = 928 Gbps

4. Cache:
─────────
Daily reads: 58,000 × 86,400 = 5B reads
Data: 5B × 2 MB = 10 PB
Cache (20%): 2 PB (impractical!)

Solution: Cache thumbnails instead
- Thumbnail: 20 KB
- Cache: 5B × 20 KB × 0.2 = 20 TB (feasible)
```

</details>

### Exercise 2: Design WhatsApp

```
Requirements:
- 2B users
- 60 messages sent per user/day
- Average message: 100 bytes
- Active users: 30% daily
- Store messages for 1 year

Calculate:
1. Write QPS
2. Daily storage
3. Total storage for 1 year
4. Is a single database feasible?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Traffic:
───────────
DAU = 2B × 0.3 = 600M
Messages/day = 600M × 60 = 36B messages
Write QPS = 36B / 86,400 ≈ 417,000 writes/second

2. Daily Storage:
─────────────────
36B × 100 bytes = 3.6 TB/day

3. Yearly Storage:
──────────────────
3.6 TB × 365 = 1.3 PB/year

4. Single Database:
───────────────────
❌ 417K writes/second is too much for single DB
✅ Need sharding (partition by user ID)
✅ 100 database shards = 4,170 writes/sec each (manageable)
```

</details>

## Summary Checklist

When doing capacity estimation, always calculate:

- [ ] **Read QPS** (average and peak)
- [ ] **Write QPS** (average and peak)
- [ ] **Storage** (with retention period)
- [ ] **Bandwidth** (read + write)
- [ ] **Cache size** (80/20 rule)
- [ ] **Database feasibility** (can it handle the load?)
- [ ] **Cost estimate** (ballpark infrastructure cost)
- [ ] **Scalability plan** (when do we need to scale?)

## Next Steps

Continue to [API Design](../04-api-design/README.md) to learn how to design clean, scalable APIs.

---

**Key Takeaway**: Better to be roughly right than precisely wrong. Focus on order of magnitude, not exact numbers.
