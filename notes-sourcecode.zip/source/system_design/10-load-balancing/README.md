# Load Balancing

## Why Load Balancing?

```
Without Load Balancer:
──────────────────────
All requests → Single Server ← Becomes bottleneck
                               └─ 50% requests fail

With Load Balancer:
───────────────────
Requests → Load Balancer
           ├─> Server 1 ← 33% of requests
           ├─> Server 2 ← 33% of requests
           └─> Server 3 ← 34% of requests
                         └─ Can handle 3x more!
```

## Load Balancing Algorithms

### 1. Round Robin

**Distribute requests in sequence**

```
Requests: A, B, C, D, E, F

Servers: [1, 2, 3]

Distribution:
─────────────
A → Server 1
B → Server 2
C → Server 3
D → Server 1
E → Server 2
F → Server 3

Pros:
✅ Simple
✅ Fair distribution

Cons:
❌ Ignores server capacity
❌ Ignores server load
```

### 2. Least Connections

**Send to server with fewest active connections**

```
Server 1: 10 connections
Server 2: 2 connections (Choose this!)
Server 3: 5 connections

New request → Server 2

Pros:
✅ Better than round robin
✅ Adapts to server load

Cons:
❌ Connection count ≠ actual load
❌ Some connections use more resources
```

### 3. Least Response Time

**Send to server with fastest response time**

```
Latencies:
Server 1: 50ms average
Server 2: 200ms average
Server 3: 100ms average

New request → Server 1

Pros:
✅ Best user experience
✅ Adapts to actual server performance

Cons:
❌ Requires monitoring
❌ More complex
```

### 4. Weighted Round Robin

**Distribute based on server capacity**

```
Server 1 (powerful): Weight 3
Server 2 (medium):   Weight 2
Server 3 (weak):     Weight 1

Distribution (out of 6 total weight):
──────────────────────────────────────
Server 1: 3/6 = 50% of requests
Server 2: 2/6 = 33% of requests
Server 3: 1/6 = 17% of requests

Pros:
✅ Accounts for server capacity
✅ Fair for different hardware

Cons:
❌ Manual configuration needed
❌ Weights don't adapt to load
```

### 5. IP Hash

**Same client IP always goes to same server**

```
Client IP: 192.168.1.100
Hash: 12345
12345 % 3 = Server 1

Next request from 192.168.1.100 → Server 1 (always)

Pros:
✅ Session affinity
✅ Useful for session data

Cons:
❌ Uneven distribution (some IPs hash to same server)
❌ Can't remove servers without rehashing
```

## Load Balancer Placement

### Layer 4 Load Balancer (TCP/UDP)

```
Benefits:
─────────
✅ Very fast (no parsing)
✅ Handles any protocol
✅ Low latency

Example: Nginx (stream), HAProxy
─────────────────────────────────
stream {
  upstream backend {
    server server1:3306;
    server server2:3306;
    server server3:3306;
  }

  server {
    listen 3306;
    proxy_pass backend;
  }
}
```

### Layer 7 Load Balancer (Application)

```
Benefits:
─────────
✅ Intelligent routing
✅ URL-based routing
✅ Content-based routing

Example: Route based on request
──────────────────────────────
GET /api/users → API Server
GET /static/* → Static Server
GET /admin/* → Admin Server

Example: Nginx http block
──────────────────────────
upstream backend {
  server server1:8080;
  server server2:8080;
}

server {
  listen 80;

  location /api/ {
    proxy_pass http://backend;
  }

  location /static/ {
    alias /var/www/static/;
  }
}
```

## Load Balancer Architecture

### Single Load Balancer (Not HA)

```mermaid
graph TD
    Users --> LB[Load Balancer<br/>Single Point of Failure!]
    
    LB --> S1[Server 1]
    LB --> S2[Server 2]
    LB --> S3[Server 3]
    
    style LB fill:#ef4444,stroke:#b91c1c,color:#fff
    style S1 fill:#1A1D28,stroke:#F5A623
    style S2 fill:#1A1D28,stroke:#F5A623
    style S3 fill:#1A1D28,stroke:#F5A623
```

If LB fails: All traffic lost!

### Load Balancer High Availability

```mermaid
graph TD
    Users --> VIP((Virtual IP))
    
    VIP --> LB1[Load Balancer 1<br/>Primary]
    VIP -.->|Failover| LB2[Load Balancer 2<br/>Backup]
    
    LB1 <-->|Heartbeat| LB2
    
    LB1 --> Servers[Server Pool]
    LB2 -.-> Servers
    
    style VIP fill:#22c55e,stroke:#16a34a,color:#fff
    style LB1 fill:#F5A623,stroke:#B8520A,color:#fff
    style LB2 fill:#1A1D28,stroke:#F5A623
```
┌──────────────┐
│ Load         │ ← Single point of failure!
│ Balancer     │
└──────┬───────┘
       │
   ┌───┴──────┬─────────┐
   │           │         │
   ▼           ▼         ▼
Server1   Server2   Server3

If LB fails: All traffic lost!
```

### Load Balancer High Availability

```
┌──────────────┐
│ Load         │ (Primary)
│ Balancer 1   │
└──────┬───────┘
       │ Heartbeat
       │ (I'm alive)
       │
┌──────▼───────┐
│ Load         │ (Backup)
│ Balancer 2   │ Watches primary
└──────────────┘

Failover:
─────────
LB1 fails → LB2 detects (no heartbeat)
LB2 takes over (VIP moves to LB2)
Traffic continues!

Virtual IP (VIP): Moves between load balancers
DNS: Points to VIP (doesn't change)
```

## Health Checks

Load balancer monitors server health:

```
┌──────────────┐
│ Load         │
│ Balancer     │
└──────────────┘
       │
   Health Check (every 10 seconds)
       │
   ┌───┼──────┬─────────┐
   │   │      │         │
   ▼   ▼      ▼         ▼
Server1 Server2 Server3 Server4
  ✅ OK ✅ OK  ❌ Down ✅ OK

Result:
───────
Load Balancer routes to: 1, 2, 4 only
Server 3 removed from pool

When Server 3 recovers:
─────────────────────
Server 3 becomes healthy
Load Balancer adds it back
Traffic goes to 1, 2, 3, 4 again
```

## Session Affinity (Sticky Sessions)

```
Without Sticky Sessions:
────────────────────────
Request 1: Client → Server 1 (creates session in memory)
Request 2: Client → Server 2 (no session, error!)
Request 3: Client → Server 3 (no session, error!)

With Sticky Sessions:
─────────────────────
Request 1: Client → Server 1 (creates session)
Request 2: Client → Server 1 (same server, session exists)
Request 3: Client → Server 1 (same server, session exists)

Implementation:
────────────────
Load balancer adds cookie:
Set-Cookie: ServerID=1

Next request:
Cookie: ServerID=1

Load Balancer:
└─ Read ServerID from cookie
└─ Route to Server 1

Pros:
✅ Sessions work without Redis
✅ Lower latency (no Redis)

Cons:
❌ If Server 1 fails, user's session lost
❌ Uneven load distribution
❌ Harder to deploy new versions

Better: Use Redis for sessions (shared across servers)
```

## Common Load Balancer Solutions

### Hardware Load Balancers

```
Expensive ($$$$):
─────────────────
✅ Very fast
✅ High availability built-in
✅ Many features

❌ Expensive to buy
❌ Expensive to maintain
❌ Less flexible

Examples:
─────────
- F5 BIG-IP
- Citrix NetScaler
- Radcom
```

### Software Load Balancers

```
Cheap ($):
──────────
✅ Open source (free)
✅ Flexible
✅ Easy to deploy

❌ More setup required
❌ Need to manage HA yourself

Popular Solutions:
──────────────────
Nginx:
└─ Web server + load balancer
└─ Fast, lightweight
└─ Reverse proxy

HAProxy:
└─ Purpose-built load balancer
└─ Very powerful
└─ Great for TCP/UDP

Linux LVS (Linux Virtual Server):
└─ Kernel-level load balancing
└─ Very fast
└─ For extreme scale
```

### Cloud Load Balancers

```
AWS Elastic Load Balancing (ELB):
─────────────────────────────────
✅ Managed service (no operations)
✅ Auto-scaling support
✅ Easy HA

ALB (Application Load Balancer):
└─ Layer 7 (application aware)
└─ URL-based routing
└─ Best for web apps

NLB (Network Load Balancer):
└─ Layer 4 (super fast)
└─ Millions of requests/sec
└─ Best for extreme throughput

CLB (Classic Load Balancer):
└─ Older, less features
└─ Still used for legacy
```

## Load Balancer Configuration Example

```nginx
# Nginx Load Balancer Configuration

upstream backend {
  # Health check settings
  server server1.com:8080 max_fails=2 fail_timeout=10s;
  server server2.com:8080 max_fails=2 fail_timeout=10s;
  server server3.com:8080 max_fails=2 fail_timeout=10s;

  # Least connections algorithm
  least_conn;

  # Keepalive connections
  keepalive 32;
}

server {
  listen 80;
  server_name api.example.com;

  # Redirect to HTTPS
  return 301 https://$server_name$request_uri;
}

server {
  listen 443 ssl http2;
  server_name api.example.com;

  ssl_certificate /etc/ssl/certs/example.com.crt;
  ssl_certificate_key /etc/ssl/private/example.com.key;

  location / {
    proxy_pass http://backend;
    proxy_http_version 1.1;
    proxy_set_header Connection "";

    # Headers for backend
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;

    # Timeouts
    proxy_connect_timeout 5s;
    proxy_send_timeout 10s;
    proxy_read_timeout 10s;
  }

  # Health check endpoint
  location /health {
    access_log off;
    return 200 "OK";
  }
}
```

## Load Balancer Gotchas

```
❌ Single point of failure
✅ Use 2+ load balancers with failover

❌ Sticky sessions limit scaling
✅ Use Redis for session storage

❌ Health checks too aggressive
✅ Balance between detection speed and false positives

❌ Uneven distribution
✅ Monitor and use least connections algorithm

❌ Lost connections during failover
✅ Acceptable (users retry)

❌ Connection pooling limits
✅ Set appropriate limits for backend connections
```

## Practice Exercise

**Design Load Balancing for a Web Service**

Scenario:
```
- 10,000 requests/second
- 50 app servers
- Users need sessions
- Must support graceful deployments
- Geographic distribution (3 regions)

Questions:
1. How many load balancers needed?
2. What algorithm to use?
3. How to handle sessions?
4. How to handle regional traffic?
5. What about health checks?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Load Balancer Count:
   ────────────────────
   ✅ 2 per region (minimum HA)
   ✅ Total: 6 load balancers
   ├─ US-East: 2 (active-passive)
   ├─ US-West: 2 (active-passive)
   └─ Europe: 2 (active-passive)

2. Algorithm:
   ──────────
   ✅ Least connections
   Reason:
   ├─ Better than round robin
   ├─ Adapts to server load
   ├─ Works well with varying request sizes

3. Session Management:
   ───────────────────
   ✅ Use Redis for session storage
   Reason:
   ├─ Session shared across all servers
   ├─ Load balancer doesn't need stickiness
   ├─ Can remove servers without losing sessions
   ├─ Easier deployments

4. Regional Traffic:
   ─────────────────
   ✅ Use GeoDNS
   Route users to nearest region:
   ├─ 192.0.2.1  → US-East (Americas)
   ├─ 192.0.2.2  → US-West (West Coast)
   └─ 192.0.2.3  → Europe (EMEA)

   Failover:
   └─ If region fails, DNS returns other regions

5. Health Checks:
   ──────────────
   ✅ HTTP GET /health every 10 seconds
   ✅ Mark unhealthy after 2 failures
   ✅ Return to pool after 2 successes
   ✅ Max 2 unhealthy before remove

   Endpoint:
   ├─ Lightweight (no database)
   ├─ Return 200 if healthy
   ├─ Return 500 if unhealthy
```

</details>

## Summary

- **Load balancing distributes traffic**: Essential for horizontal scaling
- **HA for load balancers**: Never have single LB
- **Session management**: Use external store (Redis) not sticky sessions
- **Health checks**: Monitor and automatically remove bad servers
- **Cloud load balancers**: Use managed services when possible

## Next Steps

Continue to [Caching Strategies](../11-caching/README.md) to learn how to cache data.

---

**Key Takeaway**: Load balancers are critical infrastructure. Invest in proper setup with HA and monitoring.
