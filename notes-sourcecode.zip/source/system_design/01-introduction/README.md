# Introduction to System Design

## What is System Design?

System design is the process of defining the architecture, components, modules, interfaces, and data for a system to satisfy specified requirements. It involves making strategic decisions about how different parts of a system work together to achieve business goals.

## Why System Design Matters

### For Engineers
- **Career Growth**: Senior roles require system design skills
- **Better Decision Making**: Understand trade-offs in technical choices
- **Big Picture Thinking**: See beyond individual features
- **Problem Solving**: Tackle complex, ambiguous problems

### For Businesses
- **Scalability**: Handle growth without complete rewrites
- **Reliability**: Minimize downtime and data loss
- **Cost Efficiency**: Optimize infrastructure spending
- **Speed to Market**: Make informed decisions faster

## Key Characteristics of Good System Design

### 1. Scalability
The ability to handle increased load by adding resources.

**Example**: Instagram scaled from thousands to billions of photos by:
- Using horizontal scaling (adding more servers)
- Implementing CDNs for image delivery
- Sharding databases by user ID

### 2. Reliability
The system continues to work correctly even when things fail.

**Example**: Netflix remains available during AWS outages by:
- Running in multiple availability zones
- Using chaos engineering to test failures
- Implementing graceful degradation

### 3. Availability
The percentage of time a system is operational and accessible.

**Example**: Amazon aims for 99.99% availability (4 nines):
- 52.56 minutes of downtime per year
- Redundant systems across regions
- Automated failover mechanisms

### 4. Efficiency
Optimal use of resources (CPU, memory, network, storage).

**Example**: Google Search optimizes for:
- Response time: Results in milliseconds
- Throughput: Billions of searches per day
- Resource utilization: Efficient data structures

### 5. Maintainability
How easy it is to fix bugs, add features, and operate the system.

**Example**: Well-designed systems have:
- Clear separation of concerns
- Comprehensive documentation
- Automated testing and deployment

## The System Design Process

### Step 1: Understand the Problem
```
Questions to Ask:
- What are we building?
- Who are the users?
- What are the core features?
- What are the constraints?
```

### Step 2: Define Requirements

**Functional Requirements**: What the system should do
- User authentication
- Post creation and retrieval
- Search functionality

**Non-Functional Requirements**: How the system should perform
- Handle 10M daily active users
- Sub-200ms response time
- 99.9% uptime

### Step 3: Back-of-the-Envelope Estimation
```
Calculate:
- Traffic estimates (requests per second)
- Storage requirements (data size)
- Bandwidth needs (network capacity)
- Memory/cache requirements
```

### Step 4: High-Level Design
```
Components:
1. Client (Web/Mobile)
2. Load Balancer
3. Application Servers
4. Database
5. Cache
6. CDN
```

### Step 5: Deep Dive
```
Detail specific components:
- Database schema
- API contracts
- Caching strategy
- Scaling approach
```

### Step 6: Identify and Resolve Bottlenecks
```
Consider:
- Single points of failure
- Performance bottlenecks
- Data consistency issues
- Security vulnerabilities
```

## Common System Design Patterns

### 1. Client-Server Pattern
```
Client → Request → Server → Response → Client

Use Case: Web applications, mobile apps
Example: Traditional web applications
```

### 2. Layered Architecture

```mermaid
flowchart TD
    A["Presentation Layer"] --> B["Business Logic Layer"]
    B --> C["Data Access Layer"]
    C --> D["Database"]

    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#059669,stroke:#059669,color:#fff
```

```
Use Case: Enterprise applications
Example: Spring Boot applications
```

### 3. Microservices Pattern
```
Client → API Gateway → [Service A, Service B, Service C]

Use Case: Large-scale applications
Example: Netflix, Uber
```

### 4. Event-Driven Pattern
```
Producer → Message Queue → Consumer

Use Case: Asynchronous processing
Example: Order processing, notifications
```

## System Design Trade-offs

Every design decision involves trade-offs. Understanding these is crucial.

### Consistency vs Availability
**CAP Theorem**: Can't have all three (Consistency, Availability, Partition Tolerance)

```
Strong Consistency (CP):
- All nodes see the same data simultaneously
- May sacrifice availability during network partitions
- Example: Banking systems, inventory management

High Availability (AP):
- System remains operational even during failures
- May have temporary inconsistencies
- Example: Social media feeds, shopping carts
```

### Latency vs Throughput
```
Optimize for Latency:
- Quick response times
- May handle fewer total requests
- Example: Real-time gaming, video calls

Optimize for Throughput:
- Process more total requests
- Individual requests may be slower
- Example: Batch processing, data analytics
```

### Read vs Write Optimization
```
Read-Heavy Systems:
- Implement aggressive caching
- Use read replicas
- Example: News websites, blogs

Write-Heavy Systems:
- Optimize for write performance
- Use write-behind caching
- Example: Logging systems, analytics
```

## Real-World Example: Designing a Basic Blog

### Requirements
- Users can create, read, update, delete posts
- Support 10,000 daily active users
- Posts can have images
- Full-text search

### Simple Architecture

```mermaid
flowchart TD
    browser["Browser"]
    lb["Load Balancer"]
    app["App Servers (3)"]
    pg["PostgreSQL (Primary)"]
    redis["Redis (Cache)"]

    browser --> lb
    lb --> app
    app --> pg
    app --> redis

    style browser fill:#7c3aed,stroke:#7c3aed,color:#fff
    style lb fill:#f59e0b,stroke:#f59e0b,color:#fff
    style app fill:#2563eb,stroke:#2563eb,color:#fff
    style pg fill:#059669,stroke:#059669,color:#fff
    style redis fill:#059669,stroke:#059669,color:#fff
```

### Components Explained

**Load Balancer**: Distributes traffic across app servers
- Algorithm: Round-robin or least connections
- Health checks to remove failed servers

**App Servers**: Handle business logic
- Stateless design for easy scaling
- Horizontal scaling by adding more servers

**PostgreSQL**: Primary data store
- ACID transactions for data integrity
- Relational model for structured data

**Redis**: Caching layer
- Cache frequently accessed posts
- Cache user sessions
- TTL-based invalidation

### Growth Path
```
10K users → 100K users:
- Add read replicas for database
- Implement CDN for images
- Scale app servers horizontally

100K users → 1M users:
- Implement database sharding
- Add message queue for async tasks
- Introduce microservices
- Implement Elasticsearch for search
```

## Common Mistakes to Avoid

### 1. Over-Engineering
```
❌ Don't: Start with microservices for a small app
✅ Do: Start simple, refactor when needed
```

### 2. Under-Engineering
```
❌ Don't: Ignore future scalability completely
✅ Do: Design for 10x growth, not 1000x
```

### 3. Ignoring Requirements
```
❌ Don't: Jump to solutions immediately
✅ Do: Clarify requirements first
```

### 4. Single Point of Failure
```
❌ Don't: Rely on one database/server
✅ Do: Implement redundancy and failover
```

### 5. Premature Optimization
```
❌ Don't: Optimize everything upfront
✅ Do: Measure, then optimize bottlenecks
```

## Tools for System Design

### Diagramming
- **draw.io**: Free, web-based diagramming
- **Excalidraw**: Quick sketches and wireframes
- **Lucidchart**: Professional diagrams
- **Miro**: Collaborative whiteboarding

### Estimation
- **Envelope Calculator**: Quick calculations
- **AWS Calculator**: Estimate cloud costs
- **Back-of-Envelope**: Mental math for estimates

### Prototyping
- **Docker**: Containerize components
- **Kubernetes**: Orchestrate services
- **Postman**: API testing
- **JMeter**: Load testing

## Key Metrics to Track

### Performance Metrics
```
- Response Time: Time to complete a request
- Throughput: Requests handled per second
- Error Rate: Percentage of failed requests
- Saturation: Resource utilization (CPU, memory)
```

### Business Metrics
```
- Daily Active Users (DAU)
- Monthly Active Users (MAU)
- Conversion Rate
- User Retention
```

### Infrastructure Metrics
```
- Uptime/Availability
- Mean Time To Recovery (MTTR)
- Mean Time Between Failures (MTBF)
- Cost per user/request
```

## Practice Exercise

**Design a Simple URL Shortener**

Requirements:
- Convert long URLs to short codes
- Redirect short codes to original URLs
- Handle 100 requests per second
- Store URLs for 5 years

Try to design this yourself before moving to the next chapter!

**Consider**:
1. How will you generate short codes?
2. What database will you use?
3. How will you handle scale?
4. What about caching?

## Summary

- System design is about making informed trade-offs
- Start with requirements, then design
- Consider scalability, reliability, and maintainability
- Use appropriate patterns for your use case
- Avoid both over-engineering and under-engineering
- Iterate and improve based on real metrics

## Next Steps

Continue to [Requirements Gathering](../02-requirements/README.md) to learn how to properly define system requirements.

---

**Key Takeaway**: Good system design balances current needs with future scalability. Start simple, measure everything, and iterate based on real data.
