# Requirements Gathering

## Why Requirements Matter

The most expensive mistakes in software happen when you build the wrong thing. Clear requirements help you:

- **Avoid Scope Creep**: Stay focused on core features
- **Make Better Decisions**: Choose appropriate technologies
- **Estimate Accurately**: Calculate resources needed
- **Measure Success**: Know when you're done

## Types of Requirements

### 1. Functional Requirements (What the system does)

Define the features and capabilities of the system.

**Example: Twitter Clone**
```
✅ Functional Requirements:
- Users can create an account
- Users can post tweets (280 characters)
- Users can follow other users
- Users can like and retweet
- Users can see a personalized feed
- Users can search tweets
- Users can upload images/videos
```

### 2. Non-Functional Requirements (How the system performs)

Define quality attributes and constraints.

**Example: Twitter Clone**
```
✅ Non-Functional Requirements:
- Support 500 million users
- Handle 6,000 tweets per second
- 99.99% uptime (SLA)
- Feed loads in < 1 second
- Data retained indefinitely
- Comply with GDPR
```

### 3. System Constraints

Real-world limitations that affect design.

**Example: Twitter Clone**
```
✅ Constraints:
- Budget: $100K/month infrastructure
- Timeline: MVP in 6 months
- Team: 5 backend, 3 frontend engineers
- Must use existing authentication service
- Must run on AWS
```

## The Requirements Framework

### SMART Criteria

Make requirements **Specific, Measurable, Achievable, Relevant, Time-bound**.

#### Bad vs Good Requirements

```
❌ Bad: "The system should be fast"
✅ Good: "API responses must return in < 200ms for 95% of requests"

❌ Bad: "Support many users"
✅ Good: "Support 10 million daily active users by year 2"

❌ Bad: "Be highly available"
✅ Good: "Maintain 99.9% uptime (max 8.76 hours downtime/year)"

❌ Bad: "Store user data"
✅ Good: "Store 100GB of user data with 20% annual growth"
```

## Questions to Ask (The Requirements Checklist)

### 1. Users & Scale

```
Who are the users?
- Internal employees? External customers?
- Geographic distribution?
- Technical sophistication?

How many users?
- Daily Active Users (DAU)?
- Monthly Active Users (MAU)?
- Peak vs average load?
- Growth rate?
```

**Example:**
```
Users: Global consumers, age 13-65
DAU: 10 million
MAU: 50 million
Peak: 3x average (during events)
Growth: 20% year-over-year
```

### 2. Functionality & Features

```
What are the core features?
- Must-have vs nice-to-have?
- User workflows?
- Edge cases?

What are we NOT building?
- Out of scope features?
- Future considerations?
```

**Example: E-commerce Platform**
```
✅ In Scope (MVP):
- Product catalog
- Shopping cart
- Checkout with Stripe
- Order tracking
- Basic search

❌ Out of Scope:
- Recommendations engine (future)
- Social features (future)
- Multi-currency (future)
- Seller management (phase 2)
```

### 3. Performance & Scale

```
What is the traffic pattern?
- Read-heavy or write-heavy?
- Burst traffic or steady?
- Seasonal variations?

What are the SLAs?
- Response time targets?
- Throughput requirements?
- Availability guarantees?
```

**Example: Video Streaming**
```
Traffic: Read-heavy (95% reads)
Pattern: Evening peak (6 PM - 11 PM)
Response Time:
  - Video start: < 2 seconds
  - Metadata: < 100ms
Throughput: 100,000 concurrent streams
Availability: 99.95%
```

### 4. Data & Storage

```
What data do we store?
- Data types and sizes?
- How long to retain?
- Relationships between entities?

What about data privacy?
- PII (Personally Identifiable Information)?
- Compliance requirements (GDPR, HIPAA)?
- Data residency rules?
```

**Example: Healthcare App**
```
Data Types:
- User profiles: 5KB/user
- Medical records: 50KB/record
- Images: 5MB/image

Retention:
- Active users: Forever
- Inactive users: 7 years (legal requirement)
- Logs: 90 days

Compliance:
- HIPAA compliant
- Data encryption at rest and in transit
- Audit logging for all access
```

### 5. Integration & Dependencies

```
What external systems?
- Third-party APIs?
- Legacy systems?
- Data sources?

What are the contracts?
- API formats (REST, GraphQL, gRPC)?
- Authentication methods?
- Rate limits?
```

**Example: Payment Processing**
```
Integrations:
- Stripe API (payment processing)
- SendGrid (email notifications)
- Twilio (SMS verification)
- AWS S3 (receipt storage)

Rate Limits:
- Stripe: 100 requests/second
- SendGrid: 100 emails/second
- Must handle rate limit errors gracefully
```

### 6. Cost & Resources

```
What's the budget?
- Infrastructure costs?
- Third-party service costs?
- Operational overhead?

What's the team capacity?
- Number of engineers?
- Skills available?
- Timeline?
```

**Example:**
```
Budget: $50K/month
- Compute: $30K
- Storage: $10K
- Third-party APIs: $5K
- Monitoring: $5K

Team:
- 2 senior engineers
- 3 mid-level engineers
- Timeline: 4 months to MVP
```

## Requirements Template

Use this template for your next system design:

```markdown
# [System Name] Requirements

## 1. Overview
Brief description of what we're building and why.

## 2. Users
- **Primary Users**: [Who]
- **DAU**: [Number]
- **MAU**: [Number]
- **Geographic**: [Regions]
- **Growth Rate**: [Percentage]

## 3. Functional Requirements

### Must Have (P0)
1. [Core feature 1]
2. [Core feature 2]
3. [Core feature 3]

### Should Have (P1)
1. [Important feature 1]
2. [Important feature 2]

### Nice to Have (P2)
1. [Optional feature 1]
2. [Optional feature 2]

### Out of Scope
- [Future feature 1]
- [Future feature 2]

## 4. Non-Functional Requirements

### Performance
- **Response Time**: [Target]
- **Throughput**: [Requests/second]
- **Latency**: [Target percentiles]

### Scalability
- **Current**: [Users/data]
- **1 Year**: [Projected]
- **3 Years**: [Projected]

### Reliability
- **Availability**: [Target uptime]
- **Data Durability**: [Target]
- **MTTR**: [Target recovery time]

### Security
- **Authentication**: [Method]
- **Authorization**: [Model]
- **Data Encryption**: [Requirements]
- **Compliance**: [Standards]

## 5. Data Requirements

### Data Models
[Key entities and relationships]

### Storage Estimates
- **Current**: [Size]
- **Growth**: [Rate]
- **Retention**: [Policy]

### Data Privacy
- **PII**: [What data]
- **Compliance**: [GDPR, HIPAA, etc.]
- **Backup**: [Frequency]

## 6. Integration Requirements
- [External Service 1]: [Purpose]
- [External Service 2]: [Purpose]

## 7. Constraints
- **Budget**: [Amount/month]
- **Timeline**: [Deadline]
- **Technology**: [Required stack]
- **Team**: [Size and skills]

## 8. Success Metrics
- [KPI 1]: [Target]
- [KPI 2]: [Target]
- [KPI 3]: [Target]
```

## Case Study: Instagram Requirements (2010 Launch)

Let's see how Instagram gathered requirements for their MVP:

### User Research
```
Problem: Existing photo apps were slow and complicated
Users: Mobile photographers, social sharers
Insight: People want to share photos FAST
```

### Functional Requirements (MVP)
```
1. Upload a photo
2. Apply a filter
3. Share to feed
4. Follow users
5. Like photos
6. Comment on photos

Out of Scope:
- Video (added later)
- Stories (added later)
- Direct messages (added later)
- Multiple photos per post (added later)
```

### Non-Functional Requirements
```
Performance:
- Upload in < 5 seconds on 3G
- Feed loads in < 2 seconds
- Work offline (queue uploads)

Scale:
- Launch target: 25,000 users
- 6-month target: 1 million users

Platform:
- iOS only (Android later)
- Must work on iPhone 3GS
```

### Results
```
- Launched with 13 features
- 25,000 users on day 1
- 1 million users in 2 months
- Sold to Facebook for $1B in 2 years
```

**Key Lesson**: Start small, nail the core experience, iterate based on usage.

## Requirements Prioritization

### MoSCoW Method

**Must Have**: Non-negotiable features
```
Example (Messaging App):
- Send/receive messages
- User authentication
- End-to-end encryption
```

**Should Have**: Important but not critical
```
Example (Messaging App):
- Read receipts
- Typing indicators
- Image sharing
```

**Could Have**: Nice to have if time permits
```
Example (Messaging App):
- Stickers/GIFs
- Voice messages
- Custom themes
```

**Won't Have**: Out of scope for now
```
Example (Messaging App):
- Video calls
- Group channels
- Bots/automation
```

### Impact vs Effort Matrix

```
High Impact, Low Effort → Do First
High Impact, High Effort → Plan Carefully
Low Impact, Low Effort → Quick Wins
Low Impact, High Effort → Avoid

Example:

           High Impact
                │
    Plan    │ Do First
    Carefully│
────────────┼────────────→ Low Effort
    Avoid   │ Quick Wins
                │
           Low Impact
```

## Common Requirements Pitfalls

### 1. Vague Requirements
```
❌ "The system should be scalable"
✅ "Support 100K concurrent users with p95 latency < 200ms"
```

### 2. Gold Plating
```
❌ Adding features because they're "cool"
✅ Adding features because users need them
```

### 3. Scope Creep
```
❌ "While we're at it, let's also add..."
✅ "Let's track that for phase 2"
```

### 4. Ignoring Non-Functionals
```
❌ Only defining features
✅ Also defining performance, security, scalability
```

### 5. Not Validating Assumptions
```
❌ Assuming users want feature X
✅ Validating with user research/data
```

## Requirements Validation Techniques

### 1. User Stories
```
As a [user type]
I want to [action]
So that [benefit]

Example:
As a shopper
I want to save items to a wishlist
So that I can buy them later
```

### 2. Acceptance Criteria
```
Given [context]
When [action]
Then [expected result]

Example:
Given I'm viewing a product
When I click "Add to Wishlist"
Then the product is saved to my wishlist
And I see a confirmation message
```

### 3. Prototyping
```
Create mockups/prototypes to validate:
- User flows
- Feature utility
- Technical feasibility
```

### 4. Stakeholder Review
```
Get sign-off from:
- Product managers
- Engineering leads
- Security team
- Legal/compliance
```

## Practice Exercise

**Define Requirements for a Parking Spot Finder App**

### Prompts:
1. Who are the users?
2. What are the core features?
3. What scale do you need to support?
4. What are the performance requirements?
5. What data do you need to store?
6. What are the constraints?

Try to write complete requirements before checking the solution below.

<details>
<summary>Example Solution (Click to Expand)</summary>

```markdown
# Parking Spot Finder App Requirements

## Users
- Drivers looking for parking
- Major cities: NYC, SF, LA
- DAU: 50,000
- MAU: 200,000

## Functional Requirements

### Must Have
1. Show nearby available parking spots
2. Display price and distance
3. Navigate to selected spot
4. Reserve spot for 10 minutes
5. Pay for parking

### Should Have
1. Filter by price/distance
2. Save favorite locations
3. Parking history

### Out of Scope
- Valet parking
- Commercial vehicle parking
- Charging stations

## Non-Functional Requirements

### Performance
- Show spots within 2 seconds
- GPS update every 5 seconds
- Work on 3G networks

### Scale
- 5,000 searches per hour (peak)
- 10,000 parking spots tracked
- 50,000 transactions per month

### Reliability
- 99.5% uptime
- Offline mode (cached spots)

## Data Requirements
- Parking spot locations (100KB per spot)
- User profiles (10KB per user)
- Transaction history (2KB per transaction)
- Retention: 2 years

## Integrations
- Google Maps API
- Stripe for payments
- Twilio for SMS notifications

## Constraints
- Budget: $10K/month
- Must launch in 3 months
- iOS first, Android later
```

</details>

## Summary

- **Requirements drive all design decisions**
- **Be specific and measurable** - avoid vague statements
- **Prioritize ruthlessly** - start with MVP
- **Consider both functional and non-functional requirements**
- **Validate assumptions** with users and stakeholders
- **Document clearly** for future reference

## Next Steps

Continue to [Capacity Estimation](../03-capacity-estimation/README.md) to learn how to calculate system capacity needs.

---

**Key Takeaway**: Spend time on requirements upfront. The clarity you gain will save weeks of rework later.
