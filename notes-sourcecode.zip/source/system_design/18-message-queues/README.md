# Message Queues

## Why Message Queues?

```
Without a message queue — tight coupling:
──────────────────────────────────────────
User places order
  → Order Service calls Payment Service (sync, waits)
  → Order Service calls Email Service (sync, waits)
  → Order Service calls Inventory Service (sync, waits)
  → Order Service calls Analytics Service (sync, waits)

Problems:
❌ Order service is BLOCKED waiting for all dependencies
❌ If Email Service is slow, order placement is slow
❌ If Analytics Service is down, order placement FAILS
❌ Adding a new consumer (SMS Service) requires changing Order Service code
❌ Spike of 10,000 simultaneous orders overwhelms Email Service

With a message queue:
──────────────────────
User places order
  → Order Service publishes "OrderPlaced" event → returns immediately
  → Queue holds the message

  Later (async):
  Email Service   consumes → sends confirmation email
  Inventory Svc   consumes → updates stock
  Analytics Svc   consumes → records the sale
  SMS Service     consumes → sends SMS (added without changing Order Svc!)

Benefits:
✅ Order service is non-blocking (fast response to user)
✅ Slow email service doesn't slow down order creation
✅ Downstream failure doesn't fail the order
✅ New consumers added without touching Order Service
✅ Natural buffer: queue absorbs traffic spikes
```

### Three Core Problems Queues Solve

```
1. Decoupling
   ───────────
   Producers and consumers don't know about each other.
   Each evolves independently.
   Add/remove consumers without changing producer.

2. Buffering (Load Leveling)
   ──────────────────────────
   Peak traffic: 50,000 orders/minute arrive
   Email service can process: 5,000/minute
   Without queue: email service crashes
   With queue:    backlog builds up, emails send over 10 minutes
   → Users still get emails, system doesn't fall over

3. Async Processing
   ─────────────────
   Move slow work off the critical path:
   - Image resizing (upload returns immediately, resize happens later)
   - Report generation (submit job, poll for completion)
   - Payment processing (acknowledge receipt, process asynchronously)
```

## Core Concepts

```
Producer:
─────────
Service that creates and publishes messages.
Order Service is a producer when it publishes "OrderPlaced".

Consumer:
──────────
Service that reads and processes messages.
Email Service consumes "OrderPlaced" messages.

Broker:
────────
The middleware that stores and routes messages.
Examples: Kafka, RabbitMQ, AWS SQS, Google Pub/Sub.

Queue:
───────
A line of messages. One consumer processes each message.
Good for task queues — each task done by exactly one worker.

Topic:
───────
A category of messages that multiple consumers can subscribe to.
"OrderPlaced" is a topic; Email Svc AND Inventory Svc both read it.

Partition:
───────────
A topic is split into partitions for parallelism.
Kafka topic "orders" → Partition 0, Partition 1, Partition 2.
Each partition is an ordered, immutable log of messages.

Offset:
────────
Position of a message within a partition.
Kafka tracks: "Consumer Group X has read up to offset 42 in Partition 0"
Allows replay: restart from any offset to reprocess old messages.
```

## Delivery Semantics

```
At-Most-Once (Fire and Forget):
────────────────────────────────
Producer sends → broker stores → consumer reads → broker deletes immediately
If consumer crashes before processing: MESSAGE LOST

Pseudocode:
  msg = queue.receive()
  queue.delete(msg)     ← deleted BEFORE processing
  process(msg)          ← if crash here, message is gone

✅ Lowest latency (no ACK needed)
✅ No duplicate processing
❌ Data loss possible
Use case: Metrics, logs where occasional loss is acceptable

At-Least-Once:
───────────────
Producer sends → consumer reads → consumer processes → consumer ACKs
If consumer crashes before ACK: broker redelivers message

Pseudocode:
  msg = queue.receive()
  process(msg)          ← if crash here, broker redelivers
  queue.delete(msg)     ← deleted AFTER processing

✅ No data loss
❌ Same message may be processed TWICE
Requirement: Consumer must be IDEMPOTENT
  (processing same message twice gives same result)

Examples of idempotent operations:
✅ "Set user status to VERIFIED" (safe to do twice)
❌ "Charge user $10" (dangerous to do twice!)
✅ "Charge user $10 only if payment_id=abc123 not already charged"

Exactly-Once:
─────────────
Producer sends → consumer processes EXACTLY once, no matter what.
Much harder to guarantee. Requires distributed coordination.

Kafka's approach:
- Idempotent producer (each message gets unique sequence number)
- Transactional writes (atomic: consume + produce in one transaction)

✅ No data loss, no duplicates
❌ Significant performance cost
❌ Complex to implement correctly
Use case: Financial transactions where duplicate = real money problem
```

## Push vs Pull Models

```
Push (broker pushes to consumer):
───────────────────────────────────
Broker actively delivers messages to consumer as soon as available.

Broker → Consumer: "Here's a message, process it now"

✅ Low latency (consumer notified immediately)
✅ Simple consumer (just wait for messages)
❌ Broker must track consumer capacity
❌ Consumer can be overwhelmed if broker sends too fast
❌ Broker needs to know about consumers

Used by: RabbitMQ, AWS SQS (long polling mode)

Pull (consumer polls the broker):
──────────────────────────────────
Consumer asks the broker: "Any new messages?"
Consumer controls when and how many to fetch.

Consumer → Broker: "Give me up to 100 messages"
Broker → Consumer: [list of messages]

✅ Consumer controls its own rate
✅ Consumer can batch messages efficiently
✅ Consumer can pause (just stop polling)
❌ Higher latency (poll interval introduces delay)
❌ Consumer must manage polling loop

Used by: Kafka, AWS SQS (default), Kinesis

Kafka pull example:
while True:
  records = consumer.poll(timeout_ms=1000, max_records=500)
  for record in records:
    process(record)
  consumer.commit()   ← update offset (at-least-once)
```

## Kafka Architecture

Kafka is a distributed, high-throughput event streaming platform.

```mermaid
graph TD
    subgraph producers["Producers"]
        P1["Order Service"]
        P2["Payment Service"]
        P3["User Service"]
    end

    subgraph kafka["Kafka Cluster"]
        subgraph topic["Topic: orders (3 partitions)"]
            Part0["Partition 0\n[msg0][msg3][msg6]"]
            Part1["Partition 1\n[msg1][msg4][msg7]"]
            Part2["Partition 2\n[msg2][msg5][msg8]"]
        end
        ZK["ZooKeeper / KRaft\n(metadata, leader election)"]
    end

    subgraph cg1["Consumer Group: email-workers"]
        C1["Email Worker 1\n(reads Partition 0)"]
        C2["Email Worker 2\n(reads Partition 1)"]
        C3["Email Worker 3\n(reads Partition 2)"]
    end

    subgraph cg2["Consumer Group: analytics"]
        CA["Analytics Service\n(reads all partitions)"]
    end

    P1 --> Part0
    P1 --> Part1
    P2 --> Part2
    P3 --> Part0

    Part0 --> C1
    Part1 --> C2
    Part2 --> C3

    Part0 --> CA
    Part1 --> CA
    Part2 --> CA

    style Part0 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Part1 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Part2 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style ZK fill:#7c3aed,stroke:#5b21b6,color:#fff
    style C1 fill:#059669,stroke:#047857,color:#fff
    style C2 fill:#059669,stroke:#047857,color:#fff
    style C3 fill:#059669,stroke:#047857,color:#fff
    style CA fill:#f59e0b,stroke:#d97706,color:#fff
```


```python
# Kafka producer (Python)
from confluent_kafka import Producer

producer = Producer({'bootstrap.servers': 'kafka:9092'})

producer.produce(
    topic='orders',
    key='user-123',
    value='{"order_id": 456, "total": 99.99}'
)
producer.flush()

# Kafka consumer (Python)
from confluent_kafka import Consumer

consumer = Consumer({
    'bootstrap.servers': 'kafka:9092',
    'group.id': 'email-workers',
    'auto.offset.reset': 'earliest'
})
consumer.subscribe(['orders'])

while True:
    msg = consumer.poll(1.0)
    if msg is not None and not msg.error():
        process_order(msg.value())
        consumer.commit()   # at-least-once semantics
```

## RabbitMQ Architecture

RabbitMQ is a traditional message broker focused on routing flexibility.

```
RabbitMQ core model:
─────────────────────
Producer → Exchange → Binding → Queue → Consumer

Exchange types:
────────────────

1. Direct Exchange
   Producer sends: routing_key = "payment.completed"
   Queue bound to: routing_key = "payment.completed"
   → Exact match routing

   payment.completed → Payment Queue ✅
   order.placed      → Payment Queue ❌

2. Topic Exchange
   Producer sends: routing_key = "order.placed.US"
   Queue 1 bound to: "order.placed.*"  → matches!
   Queue 2 bound to: "order.#"         → matches! (# = many words)
   Queue 3 bound to: "payment.#"       → no match

3. Fanout Exchange
   All bound queues receive every message (broadcast)
   Great for "all services need to know about this event"

4. Headers Exchange
   Route by message header attributes instead of routing key
   More flexible, less common
```

```
RabbitMQ message flow for order processing:
─────────────────────────────────────────────

OrderSvc publishes:
  exchange = "orders"
  routing_key = "order.placed"
  message = { order_id: 123, user_id: 456 }

Exchange routes to queues:
  email-queue      ← bound to "order.placed"
  inventory-queue  ← bound to "order.placed"
  analytics-queue  ← bound to "order.*"  (topic exchange)

Email worker reads email-queue → sends email
Inventory worker reads inventory-queue → updates stock
Analytics worker reads analytics-queue → logs event
```

```python
# RabbitMQ producer (Python, pika)
import pika, json

connection = pika.BlockingConnection(pika.ConnectionParameters('rabbitmq'))
channel = connection.channel()

channel.exchange_declare(exchange='orders', exchange_type='topic')

channel.basic_publish(
    exchange='orders',
    routing_key='order.placed',
    body=json.dumps({'order_id': 123, 'user_id': 456}),
    properties=pika.BasicProperties(delivery_mode=2)  # persistent
)

# RabbitMQ consumer
channel.queue_declare(queue='email-queue', durable=True)
channel.queue_bind(exchange='orders', queue='email-queue', routing_key='order.placed')

def callback(ch, method, properties, body):
    send_confirmation_email(json.loads(body))
    ch.basic_ack(delivery_tag=method.delivery_tag)  # at-least-once

channel.basic_consume(queue='email-queue', on_message_callback=callback)
channel.start_consuming()
```

## Message Flow: Order Processing

```mermaid
sequenceDiagram
    participant User
    participant OrderSvc as Order Service
    participant Queue as Message Queue
    participant EmailSvc as Email Service
    participant InventorySvc as Inventory Service
    participant AnalyticsSvc as Analytics Service

    User->>OrderSvc: POST /orders
    OrderSvc->>OrderSvc: Save order to DB
    OrderSvc->>Queue: Publish "OrderPlaced" event
    OrderSvc-->>User: 201 Created (fast!)

    Note over Queue: Messages queued asynchronously

    Queue-->>EmailSvc: OrderPlaced event
    EmailSvc->>EmailSvc: Send confirmation email
    EmailSvc-->>Queue: ACK

    Queue-->>InventorySvc: OrderPlaced event
    InventorySvc->>InventorySvc: Reserve stock
    InventorySvc-->>Queue: ACK

    Queue-->>AnalyticsSvc: OrderPlaced event
    AnalyticsSvc->>AnalyticsSvc: Record sale
    AnalyticsSvc-->>Queue: ACK
```

## Use Cases

### Task Queues (Work Queues)

```
Pattern: Distribute CPU-intensive tasks across worker pool.

Example: Image resizing
───────────────────────
User uploads photo → API immediately returns "upload received"
API publishes: { job_id: 789, s3_path: "uploads/photo.jpg", sizes: [400, 800, 1200] }

Worker pool (10 workers):
Worker 1 picks up job 789 → resizes to 3 sizes → stores in S3 → ACKs

Scaling:
If queue is filling up → add more workers
If queue is empty → scale down workers

Used by: Celery (Python), Sidekiq (Ruby), Bull (Node.js)
```

### Event Streaming

```
Pattern: Keep a persistent log of events for multiple consumers.

Example: User activity stream
──────────────────────────────
User clicks, views, purchases → all events streamed to Kafka

Consumers:
- Recommendation engine: reads last 7 days of events → personalize feed
- Fraud detection: reads real-time events → detect anomalies
- Analytics: aggregates daily active users
- ML training: reprocesses 6 months of history

Kafka's retention makes this possible:
→ New consumer can "replay" past events
→ Consumers don't need to run at the same speed
```

### Dead Letter Queues

```
What happens when a message keeps failing?

Without DLQ:
  msg fails → broker requeues → consumer retries → fails again → loop forever

With DLQ:
  msg fails N times → moves to Dead Letter Queue
  Monitor DLQ → alert engineers → investigate root cause

Example (RabbitMQ):
  Normal queue:  max_retries=3
  After 3 failures → message → dead-letter-exchange → DLQ

Example (AWS SQS):
  maxReceiveCount=5 on source queue
  Configure DeadLetterQueueArn
  → After 5 failed receives, auto-moves to DLQ
```

## Kafka vs RabbitMQ vs SQS

| Factor | Kafka | RabbitMQ | AWS SQS |
|---|---|---|---|
| Model | Log-based (pull) | Broker-based (push) | Managed queue (pull) |
| Throughput | Very high (millions/sec) | High (100k/sec) | High (managed) |
| Message retention | Long (days/weeks) | Short (until consumed) | Short (14 days max) |
| Message ordering | Per-partition | Per-queue | Best-effort (FIFO queues) |
| Message replay | Yes (by offset) | No (consumed = gone) | No |
| Routing | By partition key | Flexible (exchanges) | Simple |
| Operational overhead | High (cluster mgmt) | Medium | None (managed) |
| Use case | Event streaming, audit logs | Task queues, routing | Simple async, AWS-native |

## Trade-offs

```
Choosing the right delivery guarantee:
────────────────────────────────────────
At-most-once:  metrics, telemetry, logs
At-least-once: most business events (with idempotent consumers)
Exactly-once:  financial transactions, billing

Queue depth as a health indicator:
────────────────────────────────────
Queue growing rapidly → consumers can't keep up
Solutions:
  ✅ Add more consumers (horizontal scale)
  ✅ Optimize consumer processing speed
  ✅ Increase partition count (Kafka)
  ⚠️ Don't ignore it — unbounded queue = memory exhaustion

Message ordering gotchas:
──────────────────────────
Kafka: ordering guaranteed WITHIN a partition
  If user_id used as key → all events for that user are ordered
  But events for different users may interleave

Need global ordering? → Use single partition (limits throughput)
Need per-entity ordering? → Partition by entity ID

Backpressure:
─────────────
If consumers are overwhelmed and queue fills up:
✅ Producer-side rate limiting
✅ Reject new messages with HTTP 429 (Too Many Requests)
✅ Monitor queue depth, alert at 80% capacity
```

## Interview Tips

```
Common interview questions on message queues:

Q: "Why would you use a message queue instead of a direct API call?"
A:
  ✅ Decoupling: producer doesn't need to know about consumers
  ✅ Reliability: if consumer is down, messages queue up
  ✅ Buffering: absorbs traffic spikes
  ✅ Async: producer doesn't wait for consumer to finish
  ✅ Fan-out: one event → many independent consumers

Q: "What's the difference between a queue and a topic?"
A:
  ✅ Queue: point-to-point — one consumer per message (work queue)
  ✅ Topic: publish-subscribe — multiple consumers, each gets the message
  ✅ Kafka uses topics with consumer groups for both patterns

Q: "How do you ensure exactly-once delivery?"
A:
  ✅ Hard to guarantee at infrastructure level
  ✅ Make consumers idempotent (safe to call twice)
  ✅ Kafka's transactional API for exactly-once within Kafka
  ✅ Deduplication key: check if message ID already processed

Q: "What is consumer lag and why does it matter?"
A:
  ✅ Lag = how far behind consumer is from latest message
  ✅ Growing lag = consumers can't keep up with producers
  ✅ Monitor: Kafka's consumer_lag metric, SQS's ApproximateAgeOfOldestMessage
  ✅ Respond: scale consumers, optimize processing, increase partitions
```

## Practice Exercise

**Design a notification system using message queues**

```
Requirements:
- Users can receive notifications via Email, SMS, and Push
- Different event types: new_follower, comment, like, order_shipped
- Users can opt out of specific notification types
- High reliability: notifications must not be lost

Questions:
1. How would you structure your topics/queues?
2. What delivery semantics do you need?
3. How do you handle a user's notification preferences?
4. What happens if the SMS provider is down for 2 hours?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Topic structure:
   ─────────────────
   Option A: One topic per event type
     topics: new_follower, comment, like, order_shipped
     Pros: easy to filter, can scale each independently
     Cons: many topics to manage

   Option B: One topic per channel
     topics: email-notifications, sms-notifications, push-notifications
     Pros: each delivery channel manages its own queue
     Cons: fan-out logic at producer side

   Recommended: Event topic + notification dispatcher
     topic: user-events (all events land here)
     Notification Dispatcher consumes all events:
       - Checks user preferences
       - Routes to email-queue, sms-queue, push-queue as appropriate
     Each channel has its own consumer group

2. Delivery semantics:
   ────────────────────
   At-least-once + idempotent consumers
   - Notifications must not be lost (so not at-most-once)
   - Exactly-once is complex and overkill for notifications
   - Idempotency: track notification_id; if already sent, skip

3. User preferences:
   ──────────────────
   Notification Dispatcher fetches preferences (cached in Redis):
   user:456:preferences → { email: true, sms: false, push: true,
                             new_follower: true, like: false }
   Before routing, check preferences.
   Cache with TTL=5min; refresh on preference change.

4. SMS provider down:
   ────────────────────
   Messages remain in sms-queue (durable queue)
   Dead Letter Queue after N failures → alert on-call
   When provider recovers → resume consuming
   Users get SMS 2 hours late → acceptable for non-critical notifications
   For critical messages (2FA codes): use backup provider + DLQ alert
```

</details>

## Summary

- **Message queues decouple producers and consumers** — the core value proposition
- **At-least-once + idempotent consumers** is the pragmatic choice for most use cases
- **Kafka** excels at high-throughput event streaming with replay capability
- **RabbitMQ** excels at flexible routing with complex binding patterns
- **Monitor queue depth and consumer lag** — growing lag means consumers need scaling
- **Dead Letter Queues** are essential for handling poison messages

## Next Steps

Continue to [API Gateway](../19-api-gateway/README.md) to learn how API gateways sit in front of microservices to handle cross-cutting concerns.

---

**Key Takeaway**: Message queues shift your system from synchronous (fragile, coupled) to asynchronous (resilient, decoupled). The trade-off is complexity — you must design for eventual consistency and idempotency throughout your consumers.
