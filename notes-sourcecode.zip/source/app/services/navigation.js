const fs = require('fs');
const path = require('path');
const { CONTENT_ROOT, EXCLUDED } = require('../config');
const { formatName } = require('../utils/formatters');

/**
 * Builds a navigation tree from the file system
 * @param {string} dir - Directory to scan
 * @param {string} relPath - Relative path from content root
 * @returns {Array} Tree structure
 */
function buildTree(dir, relPath = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const items = [];

  // Separate dirs and files, then sort each
  const dirs = entries.filter(e => e.isDirectory() && !EXCLUDED.has(e.name) && !e.name.startsWith('.'));
  const files = entries.filter(e => e.isFile() && e.name.toLowerCase().endsWith('.md'));

  dirs.sort((a, b) => a.name.localeCompare(b.name));
  files.sort((a, b) => a.name.localeCompare(b.name));

  for (const d of dirs) {
    const childRel = relPath ? `${relPath}/${d.name}` : d.name;
    const children = buildTree(path.join(dir, d.name), childRel);
    if (children.length > 0) {
      items.push({
        type: 'folder',
        name: d.name,
        label: formatName(d.name),
        path: childRel,
        children,
      });
    }
  }

  for (const f of files) {
    // Skip project metadata files
    if (['claude.md', 'agents.md'].includes(f.name.toLowerCase())) continue;

    const fileRel = relPath ? `${relPath}/${f.name}` : f.name;
    items.push({
      type: 'file',
      name: f.name,
      label: formatName(f.name),
      path: fileRel,
    });
  }

  return items;
}

/**
 * Flattens a tree structure into a linear array of files
 * @param {Array} nodes - Tree nodes
 * @returns {Array} Flat array of file nodes
 */
function flattenTree(nodes) {
  let list = [];
  for (const n of nodes) {
    if (n.type === 'file') list.push(n);
    else if (n.type === 'folder') list = list.concat(flattenTree(n.children));
  }
  return list;
}

/**
 * Initializes navigation tree
 * @returns {Object} Navigation tree and flat file list
 */
function initializeNavigation() {
  console.log('Building navigation tree...');
  const navTree = buildTree(CONTENT_ROOT);
  const flatFiles = flattenTree(navTree);
  console.log(`Navigation tree built: ${flatFiles.length} files`);
  return { navTree, flatFiles };
}

module.exports = {
  buildTree,
  flattenTree,
  initializeNavigation,
};
