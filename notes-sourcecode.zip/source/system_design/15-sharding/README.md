# Database Sharding

## Why Sharding?

```
Single Database Server — The Scaling Wall:
───────────────────────────────────────────
100GB data  → Fine on one server
1TB data    → Getting tight
10TB data   → Queries slow, disk full
100TB data  → Single server can't hold this!

Problems at scale:
❌ Storage limits (one disk only holds so much)
❌ Query throughput ceiling (one CPU, one I/O bus)
❌ Single point of failure
❌ Memory can't cache enough data
```

### Vertical vs Horizontal Scaling

```
Vertical Scaling (Scale Up):
─────────────────────────────
Add more RAM, CPU, faster disk to one server

Small   →  Medium   →  Large    →  XL       →  STOP
4GB RAM    32GB RAM    128GB RAM   1TB RAM     Wall!
                                              $ Exponential cost
                                              Still SPOF

Horizontal Scaling (Scale Out):
────────────────────────────────
Split data across many servers

Server 1: Users A-M   (50GB)
Server 2: Users N-Z   (50GB)

Add more:
Server 3: Users A-D   (33GB)
Server 4: Users E-M   (33GB)
Server 5: Users N-Z   (34GB)

✅ Linear cost
✅ Linear capacity
✅ No single point of failure
```

**Sharding** is the technique of splitting one large database into many smaller databases (shards), each holding a subset of the data.

## Sharding Strategies

### 1. Range-Based Sharding

**Split data by value ranges**

```
User IDs:
─────────
Shard 1: user_id 1       – 1,000,000
Shard 2: user_id 1,000,001 – 2,000,000
Shard 3: user_id 2,000,001 – 3,000,000

Date-based example:
───────────────────
Shard 1: orders from 2022
Shard 2: orders from 2023
Shard 3: orders from 2024

Query: SELECT * WHERE user_id = 1,500,000
→ Router knows → Shard 2

Pros:
✅ Easy range queries (WHERE id BETWEEN 1 AND 500000)
✅ Simple routing logic
✅ Works well for time-series data

Cons:
❌ Hotspot risk (new users go to last shard)
❌ Uneven distribution if data is not uniform
❌ Requires resharding when a range fills up
```

### 2. Hash-Based Sharding

**Apply a hash function to the shard key**

```
Algorithm:
──────────
shard_number = hash(shard_key) % total_shards

Example (4 shards):
───────────────────
user_id=1001  → hash(1001) = 3456789 → 3456789 % 4 = 1 → Shard 1
user_id=1002  → hash(1002) = 8901234 → 8901234 % 4 = 2 → Shard 2
user_id=1003  → hash(1003) = 2345678 → 2345678 % 4 = 3 → Shard 3
user_id=1004  → hash(1004) = 6789012 → 6789012 % 4 = 0 → Shard 0

Distribution is even (pseudo-random)

Pros:
✅ Even data distribution
✅ No hotspots (if key is high-cardinality)
✅ Simple to implement

Cons:
❌ Range queries are expensive (must scan all shards)
❌ Adding shards requires resharding ALL data
❌ No locality — related records may be on different shards
```

### 3. Directory-Based Sharding

**A lookup table maps each key to a shard**

```
Lookup Table (stored in fast KV store like Redis):
──────────────────────────────────────────────────
key=user:1001 → Shard 3
key=user:1002 → Shard 1
key=user:1003 → Shard 3
key=user:1004 → Shard 2

Query flow:
───────────
1. App requests user 1003
2. Router looks up: user:1003 → Shard 3
3. Router queries Shard 3
4. Returns result

Pros:
✅ Maximum flexibility (move data between shards freely)
✅ No resharding — just update the lookup table
✅ Can implement custom placement logic

Cons:
❌ Lookup table is a bottleneck + single point of failure
❌ Extra hop on every query
❌ Lookup table can get very large
❌ Must keep lookup table consistent with data
```

### Strategy Comparison

| Factor | Range | Hash | Directory |
|---|---|---|---|
| Range queries | Excellent | Poor (all shards) | Depends |
| Data distribution | Uneven | Even | Flexible |
| Hotspot risk | High | Low | Manageable |
| Resharding cost | Medium | Very High | Low |
| Query routing | Simple | Simple | Extra lookup |
| Use case | Time-series, ordered data | User data, evenly distributed | Complex placement rules |

## Shard Key Selection

The shard key is the most critical design decision. A bad shard key breaks the entire system.

```
What makes a GOOD shard key:
─────────────────────────────

1. High Cardinality
   ✅ user_id (millions of users)
   ❌ country (only ~200 values — uneven)
   ❌ boolean status (2 values — terrible!)

2. Even Distribution
   ✅ user_id (IDs spread randomly)
   ❌ created_at (all new data goes to latest shard)
   ❌ region (US may get 80% of traffic)

3. Query Locality
   ✅ user_id (most queries are "all data for user X")
   ❌ product_category (order queries need user + category)

4. Immutable
   ✅ user_id never changes
   ❌ email (users change email → must move data between shards!)

5. Avoids Cross-Shard Joins
   ✅ tenant_id in multi-tenant SaaS (all tenant data on one shard)
   ❌ department_id if queries join employees + departments + offices
```

### Composite Shard Keys

```
Single key problem:
───────────────────
Shard by user_id → great for "get user's posts"
But what about "get all posts in category X"?
→ Must scan every shard!

Composite key:
──────────────
Shard by (tenant_id, user_id):
- All data for tenant 42 is on the same shard
- Queries for tenant 42 hit only 1 shard
- Works well for multi-tenant SaaS

Example: MongoDB compound shard key
{ tenant_id: 1, created_at: -1 }
```

## Consistent Hashing

Standard hash sharding problem: adding a new shard requires rehashing everything.

```
Before (3 shards, hash % 3):
─────────────────────────────
user_id=100 → 100 % 3 = 1 → Shard 1
user_id=200 → 200 % 3 = 2 → Shard 2
user_id=300 → 300 % 3 = 0 → Shard 0

Add a 4th shard (hash % 4):
────────────────────────────
user_id=100 → 100 % 4 = 0 → Shard 0  ← MOVED!
user_id=200 → 200 % 4 = 0 → Shard 0  ← MOVED!
user_id=300 → 300 % 4 = 0 → Shard 0  ← MOVED!

Problem: EVERYTHING must be moved. Massive migration!
```

### The Consistent Hashing Ring

```mermaid
graph TD
    subgraph ring["Hash Ring (0 → 2³²)"]
        direction TB
        N0["Node A\n(position 100)"]
        N1["Node B\n(position 300)"]
        N2["Node C\n(position 600)"]
        N3["Node D\n(position 850)"]

        K1["Key X\n(hash=150)\n→ Node B"]
        K2["Key Y\n(hash=400)\n→ Node C"]
        K3["Key Z\n(hash=700)\n→ Node D"]
    end

    N0 -->|next clockwise| N1
    N1 -->|next clockwise| N2
    N2 -->|next clockwise| N3
    N3 -->|wraps to| N0

    K1 -.->|assigned to| N1
    K2 -.->|assigned to| N2
    K3 -.->|assigned to| N3

    style N0 fill:#7c3aed,stroke:#5b21b6,color:#fff
    style N1 fill:#7c3aed,stroke:#5b21b6,color:#fff
    style N2 fill:#7c3aed,stroke:#5b21b6,color:#fff
    style N3 fill:#7c3aed,stroke:#5b21b6,color:#fff
    style K1 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style K2 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style K3 fill:#2563eb,stroke:#1d4ed8,color:#fff
```


## Hash vs Range Sharding — Visual Comparison

```mermaid
graph LR
    subgraph hash_sharding["Hash-Based Sharding"]
        direction TB
        HK1["user_id=1001\nhash=3456789\n%4 = 1"]
        HK2["user_id=1002\nhash=8901234\n%4 = 2"]
        HK3["user_id=1003\nhash=2345678\n%4 = 3"]
        HS1["Shard 0\n25% of data"]
        HS2["Shard 1\n25% of data"]
        HS3["Shard 2\n25% of data"]
        HS4["Shard 3\n25% of data"]
        HK1 --> HS2
        HK2 --> HS3
        HK3 --> HS4
    end

    subgraph range_sharding["Range-Based Sharding"]
        direction TB
        RK1["user_id=500\n→ Shard A"]
        RK2["user_id=1500\n→ Shard B"]
        RK3["user_id=2500\n→ Shard C"]
        RS1["Shard A\nIDs 1–1000"]
        RS2["Shard B\nIDs 1001–2000"]
        RS3["Shard C\nIDs 2001–3000"]
        RK1 --> RS1
        RK2 --> RS2
        RK3 --> RS3
    end

    style HS1 fill:#059669,stroke:#047857,color:#fff
    style HS2 fill:#059669,stroke:#047857,color:#fff
    style HS3 fill:#059669,stroke:#047857,color:#fff
    style HS4 fill:#059669,stroke:#047857,color:#fff
    style RS1 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style RS2 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style RS3 fill:#2563eb,stroke:#1d4ed8,color:#fff
    style HK1 fill:#374151,stroke:#1f2937,color:#fff
    style HK2 fill:#374151,stroke:#1f2937,color:#fff
    style HK3 fill:#374151,stroke:#1f2937,color:#fff
    style RK1 fill:#374151,stroke:#1f2937,color:#fff
    style RK2 fill:#374151,stroke:#1f2937,color:#fff
    style RK3 fill:#374151,stroke:#1f2937,color:#fff
```

## The Hotspot Problem

```
Scenario 1: Celebrity / Viral content
───────────────────────────────────────
Shard key = user_id
Celebrity has 50M followers
All 50M followers read celebrity's tweets
→ All reads hit the SAME shard
→ That shard becomes a hotspot!

Solutions:
✅ Add read replicas for hot shards
✅ Cache celebrity data aggressively
✅ Use a "salted" shard key: (user_id + random_suffix)
   - Write to 10 sub-shards
   - Read from all 10 sub-shards, merge
   - Reduces hotspot by 10x

Scenario 2: Sequential IDs as shard key
─────────────────────────────────────────
INSERT with auto-increment ID:
→ All new writes go to the LAST shard
→ Last shard is always hot

Solutions:
✅ Use random UUIDs instead of sequential IDs
✅ Use hash-based sharding instead of range
✅ Use snowflake IDs (time + machine + sequence)
```

## Resharding

```
When you need to reshard:
──────────────────────────
- Shard is running out of storage
- A shard is a hotspot (overloaded)
- Adding capacity requires rebalancing

The challenge:
───────────────
Data is LIVE. You can't stop the world to migrate.

Strategy: Double-write migration
─────────────────────────────────
Phase 1: Setup
  - Create new shard layout
  - Set up new shards

Phase 2: Dual-write (writes go to OLD and NEW)
  - All new writes → old shards + new shards
  - Old data still only in old shards

Phase 3: Backfill
  - Copy old data to new shards
  - Apply any writes from dual-write log
  - Verify checksums

Phase 4: Cutover
  - Switch reads to new shards
  - Stop dual-writes
  - Decommission old shards

Risk:
❌ Complex to orchestrate
❌ Temporary doubled storage
❌ Any bug = data loss or inconsistency
```

## Cross-Shard Queries and Distributed Transactions

```
The cross-shard problem:
─────────────────────────
SELECT u.name, o.total
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE u.country = 'US'
AND o.created_at > '2024-01-01'

If users and orders are on DIFFERENT shards:
→ Can't do a simple JOIN
→ Must scatter-gather: query all shards, merge in app

Options:
─────────
1. Scatter-Gather
   - Send query to ALL shards in parallel
   - Merge results in application layer
   - ✅ Works   ❌ Slow for large result sets

2. Denormalize / Co-locate
   - Store orders INSIDE user document (MongoDB)
   - User and orders always on same shard
   - ✅ Fast   ❌ Data duplication, harder updates

3. Shared lookup service
   - A separate service resolves cross-shard lookups
   - ✅ Flexible   ❌ Extra service to maintain

Distributed Transactions:
──────────────────────────
"Transfer $100 from Account A (Shard 1) to Account B (Shard 2)"

Two-Phase Commit (2PC):
───────────────────────
Phase 1 — Prepare:
  Coordinator → Shard 1: "Can you debit $100?"
  Coordinator → Shard 2: "Can you credit $100?"
  Both reply: "Yes, ready"

Phase 2 — Commit:
  Coordinator → Shard 1: "Commit"
  Coordinator → Shard 2: "Commit"

Problem:
❌ Coordinator is SPOF
❌ Shards locked during protocol (blocks other txns)
❌ If coordinator dies between phases → stuck forever

Saga Pattern (better):
───────────────────────
Break into local transactions with compensating actions:
  Step 1: Debit Shard 1   (if fail: nothing to undo)
  Step 2: Credit Shard 2  (if fail: undo Step 1 — credit back)

✅ No global lock
✅ Eventually consistent
❌ More complex to implement
❌ Not strictly atomic
```

## Real Systems

### MongoDB Sharding

```
MongoDB sharding architecture:
────────────────────────────────
mongos (router)        ← App connects here
    │
    ├── Config Servers  ← Stores chunk locations
    │
    ├── Shard 1 (replica set)  ← Data chunks
    ├── Shard 2 (replica set)
    └── Shard 3 (replica set)

Chunks:
- Data is split into 128MB chunks
- Config servers track which shard owns which chunk range
- mongos routes queries based on shard key
- Balancer automatically moves chunks when shards are uneven

Example shard key selection:
db.users.createIndex({ tenant_id: 1, user_id: 1 })
sh.shardCollection("mydb.users", { tenant_id: 1, user_id: 1 })
```

### Cassandra Partitioning

```
Cassandra = consistent hashing built-in
────────────────────────────────────────
Every table has a PARTITION KEY
Partition key is hashed → determines which node owns the data

CREATE TABLE orders (
  user_id    UUID,
  order_id   TIMEUUID,
  amount     DECIMAL,
  PRIMARY KEY (user_id, order_id)  -- user_id is partition key
);

Query: SELECT * FROM orders WHERE user_id = ?
→ Hash user_id → find responsible node → single-node query

Cross-partition query (avoid!):
SELECT * FROM orders WHERE amount > 100  -- full cluster scan
```

### MySQL Sharding

```
MySQL doesn't have built-in sharding.
Common approaches:

1. Application-level sharding
   - App contains shard routing logic
   - Each shard is a separate MySQL instance
   - Libraries: Vitess, ProxySQL

2. Vitess (YouTube's solution)
   - Kubernetes-native MySQL sharding
   - Transparent to application
   - Handles resharding, failover, query routing
   - Used by: YouTube, Slack, GitHub

3. Proxy-based (ProxySQL)
   - Sits between app and MySQL shards
   - Routes queries based on rules
   - Handles connection pooling
```

## Trade-offs Summary

| Concern | Sharded | Single DB |
|---|---|---|
| Read/write throughput | Scales linearly | Limited by one machine |
| Storage capacity | Near-unlimited | Limited by one disk |
| Cross-shard queries | Slow, complex | Fast, simple JOIN |
| Transactions | Complex (2PC/Saga) | Simple ACID |
| Operational complexity | Very high | Low |
| Resharding | Painful, risky | N/A |
| Query flexibility | Restricted by shard key | Full SQL freedom |

## Interview Tips

```
Common interview questions on sharding:

Q: "How would you shard a users table for 1 billion users?"
A: Talk through:
   - Shard key: user_id (high cardinality, immutable, good locality)
   - Strategy: consistent hashing (handles node addition smoothly)
   - Start with 64 shards, use virtual nodes
   - Mention hotspot prevention for celebrity accounts

Q: "What are the downsides of sharding?"
A:
   ✅ Cross-shard queries become expensive scatter-gather operations
   ✅ Distributed transactions lose ACID guarantees
   ✅ The shard key choice is irreversible (changing = full migration)
   ✅ Operational complexity explodes

Q: "When NOT to shard?"
A:
   ✅ When vertical scaling still works (try this first!)
   ✅ When you have complex relational queries
   ✅ When your data is < 1TB
   ✅ When read replicas can handle your read load
   ✅ Consider read replicas + caching before sharding

Golden rule: Shard as late as possible.
Most applications never need sharding.
```

## Practice Exercise

**Design sharding for a social media platform**

```
Requirements:
- 500M users
- Each user has posts, comments, followers
- Most queries are "get all posts by user X"
- Some queries are "trending posts in category X"

Questions:
1. What shard key would you choose?
2. How would you handle the "trending" query?
3. How would you handle a celebrity with 10M followers?
4. What happens when you need to add more shards?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Shard Key: user_id
   ──────────────────
   ✅ High cardinality (500M users)
   ✅ Immutable
   ✅ Queries are user-centric → all data on one shard
   ✅ Use consistent hashing for easy expansion

2. Trending posts query:
   ──────────────────────
   ✅ Maintain a separate "trending" service / table
   ✅ Not sharded by user — sharded by category or time
   ✅ Or: scatter-gather all shards, aggregate top-N per shard
   ✅ Cache results heavily (trending doesn't change per-millisecond)

3. Celebrity hotspot:
   ───────────────────
   ✅ Read replicas for celebrity shards
   ✅ Cache celebrity posts at CDN level
   ✅ Fan-out on write: pre-populate followers' feeds
      (so no read hotspot at query time)

4. Adding shards:
   ────────────────
   ✅ Consistent hashing — only ~1/N keys move
   ✅ Double-write during migration window
   ✅ Virtual nodes for even distribution
```

</details>

## Summary

- **Sharding splits data horizontally** across many servers — essential beyond ~1TB or high write throughput
- **Shard key selection is critical** — choose high cardinality, immutable, query-local keys
- **Hash sharding = even distribution**, range sharding = good range queries, directory = flexible
- **Consistent hashing** minimizes data movement when adding/removing shards
- **Avoid if possible** — try read replicas and caching first; sharding adds enormous complexity

## Next Steps

Continue to [Replication](../16-replication/README.md) to learn how data is copied across servers for high availability.

---

**Key Takeaway**: The shard key decision is permanent. Choose wrong and you'll face hotspots, expensive cross-shard queries, or a painful full re-migration. Design shard keys around your most frequent query patterns.
