# Distributed Consensus Algorithms

## What is Distributed Consensus?

```
The Problem:
────────────
Multiple servers need to agree on a value or decision,
even when:
- Servers can crash
- Networks can partition
- Messages can be lost or delayed
- Servers might be malicious (Byzantine)

Consensus:
──────────
A protocol that guarantees all non-faulty nodes
eventually agree on the same value.

Example Use Cases:
──────────────────
✅ Leader election: Which server is the primary?
✅ Configuration management: What's the current cluster config?
✅ Distributed transactions: Should we commit or rollback?
✅ Log replication: What order did events occur?
✅ State machine replication: All nodes apply same operations
```

## Why Consensus is Hard

### The CAP Theorem Review

```
CAP Theorem states you can only have 2 of 3:
────────────────────────────────────────────

C (Consistency):    All nodes see the same data
A (Availability):   Every request gets a response
P (Partition):      System works despite network failures

Consensus algorithms are CP systems:
────────────────────────────────────
✅ Consistency: Guaranteed agreement
✅ Partition tolerance: Handle network splits
❌ Availability: May refuse requests during partitions

Why?
────
To achieve consensus, nodes must communicate.
If the network partitions, consensus requires
a majority (quorum). Minority nodes cannot serve
requests → unavailable.
```

```mermaid
flowchart TB
    subgraph Normal["✅ Normal Operation"]
        N1["Node 1"] <-->|"consensus OK"| N2["Node 2"]
        N2 <--> N3["Node 3"]
        N1 <--> N3
    end

    subgraph Partition["🔴 Network Partition"]
        P1["Node 1\n(majority)"] <--> P2["Node 2\n(majority)"]
        P3["Node 3\n(minority)"]
        
        P1 -.-|"❌ can't reach"| P3
        P2 -.-|"❌ can't reach"| P3
    end

    subgraph Result["Consensus Behavior"]
        R1["Majority partition:\n✅ Can accept writes\n(has quorum)"]
        R2["Minority partition:\n❌ Refuses writes\n(no quorum)"]
    end

    Partition --> Result

    style P1 fill:#059669,color:#fff
    style P2 fill:#059669,color:#fff
    style P3 fill:#ef4444,color:#fff
    style R1 fill:#059669,color:#fff
    style R2 fill:#ef4444,color:#fff
```

### The Byzantine Generals Problem

```
The Classic Problem (Lamport, 1982):
─────────────────────────────────────

Byzantine army surrounds an enemy city.
Several divisions, each with a general.
Generals can only communicate by messenger.

Goal: All loyal generals agree on same plan (attack or retreat)

Challenges:
───────────
❌ Some generals might be traitors (send false info)
❌ Messengers can be captured (messages lost)
❌ Messages can be delayed (no time bounds)

Solution requires:
──────────────────
✅ All loyal generals agree on the same decision
✅ A small number of traitors can't cause loyal generals to disagree

Analogy to Distributed Systems:
────────────────────────────────
Generals    = Nodes/servers
Messengers  = Network messages
Traitors    = Byzantine faults (malicious nodes, corruption)
Decision    = Consensus value
```

**Types of Faults:**

```
Crash Faults (easier to handle):
─────────────────────────────────
Node stops responding (fail-stop model)
- Server crashes
- Process killed
- Power outage

Algorithms: Paxos, Raft, Zab (handle crash faults)

Byzantine Faults (harder to handle):
─────────────────────────────────────
Node behaves arbitrarily or maliciously
- Sends contradictory messages
- Corrupted memory/disk
- Compromised by attacker

Algorithms: PBFT, Tendermint, blockchain consensus
           (handle Byzantine faults)

Requirements:
─────────────
Crash fault tolerance:   need f+1 nodes to tolerate f crashes
Byzantine fault tolerance: need 3f+1 nodes to tolerate f Byzantine nodes

Why? With Byzantine faults, can't trust any single node.
     Need majority of honest nodes to outvote traitors.
```

### Network Partitions and Failures

```
What Can Go Wrong in Distributed Systems:
──────────────────────────────────────────

1. Network Partition (split-brain):
   ─────────────────────────────────
   Cluster splits into 2+ groups that can't communicate
   
   Cluster: [A, B, C] | [D, E]
            majority  |  minority
   
   Without consensus: Both sides might accept writes → conflict!
   With consensus: Only majority can write (quorum)

2. Message Loss:
   ─────────────
   Packet dropped by network
   Must use timeouts and retries
   Can't distinguish "slow" from "lost"

3. Message Delay:
   ──────────────
   Message delayed by seconds/minutes
   Consensus must work even with arbitrary delays (asynchronous network)

4. Message Reordering:
   ───────────────────
   Message 2 arrives before message 1
   Consensus must track sequence/order

5. Node Crashes:
   ─────────────
   Node fails mid-operation
   Must recover state from persistent log

6. Clock Skew:
   ───────────
   Nodes have different time (clocks drift)
   Can't rely on timestamps for ordering
   Use logical clocks instead (Lamport timestamps, vector clocks)
```

**The FLP Impossibility Result (1985):**

```
Fischer, Lynch, Paterson proved:
────────────────────────────────
"In an asynchronous distributed system with even ONE faulty node,
 no deterministic algorithm can guarantee consensus in finite time."

What this means:
────────────────
You can't have a perfect consensus algorithm that:
✅ Always terminates (liveness)
✅ Never produces wrong result (safety)
✅ Tolerates even one crash

In an asynchronous network (no time bounds on messages).

Practical Takeaway:
───────────────────
Real algorithms choose to:
- Prioritize safety (may not terminate if no majority)
- Add timeouts/randomization (not deterministic)
- Assume partially synchronous networks (bounded delays most of the time)

Paxos and Raft are "safe" but may not terminate.
They sacrifice liveness for safety.
```

## Paxos Algorithm

**The original and most famous consensus algorithm (Lamport, 1998)**

```
What Paxos Solves:
──────────────────
Single value consensus: All nodes agree on one value.

Not covered by basic Paxos:
───────────────────────────
- Ordering multiple values (Multi-Paxos extends this)
- State machine replication (use Multi-Paxos)

Guarantees:
───────────
✅ Safety: Only one value is chosen
✅ Liveness: Eventually a value is chosen (if majority alive)
✅ Fault tolerance: Works with up to (n-1)/2 failures

Roles in Paxos:
───────────────
Proposer:  Proposes values
Acceptor:  Votes to accept values (majority needed)
Learner:   Learns which value was chosen

Note: One node can play multiple roles
```

### Paxos Phases

**Phase 1: Prepare (Promise to not accept older proposals)**

```mermaid
sequenceDiagram
    participant P as Proposer
    participant A1 as Acceptor 1
    participant A2 as Acceptor 2
    participant A3 as Acceptor 3

    Note over P: Wants to propose value V
    P->>A1: PREPARE(n=5)
    P->>A2: PREPARE(n=5)
    P->>A3: PREPARE(n=5)

    Note over A1,A3: Each acceptor checks:<br/>Have I seen higher n?<br/>If not, promise to ignore n<5

    A1-->>P: PROMISE(n=5, no prior value)
    A2-->>P: PROMISE(n=5, accepted n=3, value=X)
    A3-->>P: PROMISE(n=5, no prior value)

    Note over P: Majority promised!<br/>A2 already accepted value X at n=3<br/>Proposer MUST propose X (not V)
```

**Phase 1 Rules:**

```
Proposer:
─────────
1. Generate unique proposal number n (higher than any seen before)
2. Send PREPARE(n) to majority of acceptors
3. Wait for PROMISE responses from majority

Acceptor (on receiving PREPARE(n)):
────────────────────────────────────
1. If n > highest_n_seen:
   - Store highest_n_seen = n
   - PROMISE: "I won't accept any proposal < n"
   - Include: Any value already accepted (if any)
2. If n <= highest_n_seen:
   - Reject (or ignore)

Unique Proposal Numbers:
────────────────────────
Use (counter, server_id) tuple:
  Server 1: 1, 11, 21, 31, ...
  Server 2: 2, 12, 22, 32, ...
  Server 3: 3, 13, 23, 33, ...
Guarantees uniqueness and ordering.
```

**Phase 2: Accept (Actually vote for the value)**

```mermaid
sequenceDiagram
    participant P as Proposer
    participant A1 as Acceptor 1
    participant A2 as Acceptor 2
    participant A3 as Acceptor 3
    participant L as Learners

    Note over P: Received majority promises<br/>Must use value X (from A2's promise)

    P->>A1: ACCEPT(n=5, value=X)
    P->>A2: ACCEPT(n=5, value=X)
    P->>A3: ACCEPT(n=5, value=X)

    Note over A1,A3: Each acceptor checks:<br/>Did I promise to ignore n<5?<br/>If not, accept it

    A1-->>P: ACCEPTED(n=5, value=X)
    A2-->>P: ACCEPTED(n=5, value=X)
    A3-->>P: ACCEPTED(n=5, value=X)

    Note over P: Majority accepted!<br/>Value X is chosen

    A1->>L: ACCEPTED(n=5, value=X)
    A2->>L: ACCEPTED(n=5, value=X)
    A3->>L: ACCEPTED(n=5, value=X)

    Note over L: Learners observe majority<br/>Learn that X is the chosen value
```

**Phase 2 Rules:**

```
Proposer:
─────────
1. If received PROMISE from majority:
   - If any PROMISE included a value → MUST propose that value
   - If no PROMISE included a value → propose your own value V
2. Send ACCEPT(n, value) to majority of acceptors
3. Wait for ACCEPTED responses from majority

Acceptor (on receiving ACCEPT(n, value)):
──────────────────────────────────────────
1. If n >= highest_n_promised:
   - Store accepted_value = value
   - Store accepted_n = n
   - Send ACCEPTED(n, value) to proposer and learners
2. If n < highest_n_promised:
   - Reject (already promised to ignore this n)

Learner:
────────
1. Listen for ACCEPTED messages
2. When majority of acceptors send ACCEPTED(n, value):
   → Value is chosen!
3. Apply value to state machine
```

### Why Paxos is Safe

```
Key Invariant:
──────────────
"Once a value is chosen, no future proposal can choose a different value."

How this is guaranteed:
───────────────────────

1. A value is chosen when majority accepts it
2. Any future proposal needs majority promises
3. Majorities overlap (pigeonhole principle)
   
   Example (5 nodes):
   First majority: {A, B, C}
   Second majority: {B, C, D}
   Overlap: {B, C}
   
4. At least one node in the overlap accepted the first value
5. That node sends the first value in its PROMISE
6. New proposer MUST propose that same value (Phase 1 rule)

Result: Once a value is chosen, it's sticky forever.
```

**Example: Conflicting Proposals**

```
Scenario: Two proposers compete
────────────────────────────────

Time  Proposer 1 (n=10)          Proposer 2 (n=15)          Acceptors
────  ─────────────────────────  ─────────────────────────  ─────────
t0    PREPARE(10) →                                          
t1                                                           Promise(10)
t2    ACCEPT(10, value=A) →                                 
t3                                                           Accept(10,A) ✅
t4                                PREPARE(15) →              
t5                                                           Promise(15) ⚠️
                                                             (send accepted=A)
t6                                ACCEPT(15, value=A) →      Must use A!
t7                                                           Accept(15,A) ✅

Result: Both proposers converge on value A.
        Paxos ensures safety even with contention.

What if Proposer 2 started earlier?
────────────────────────────────────
t0                                PREPARE(15) →
t1                                                           Promise(15)
t2    PREPARE(10) →                                          
t3                                                           Reject(10) ❌
                                                             (already promised n=15)
t4                                ACCEPT(15, value=B) →
t5                                                           Accept(15,B) ✅

Result: Proposer 1 is rejected. Only B is accepted.
```

### Multi-Paxos Optimization

```
Problem with Basic Paxos:
─────────────────────────
For each value to agree on (log entry), need 2 round trips:
  1. PREPARE/PROMISE
  2. ACCEPT/ACCEPTED

For a replicated log (1000s of entries), this is too slow!

Multi-Paxos Solution:
─────────────────────
Elect a "leader" who can skip Phase 1 for subsequent proposals.

Step 1: Run Paxos once to elect a leader (leader = proposer)
Step 2: Leader sends ACCEPT directly for all future values
        (skips PREPARE phase)

Why this works:
───────────────
Leader already got PROMISE from majority during election.
As long as leader doesn't change, acceptors won't promise to other nodes.

When to re-run Phase 1:
───────────────────────
- Leader suspects it lost leadership (timeout)
- Acceptor rejects ACCEPT (saw higher n from new leader)
- Leader crashes (new leader runs full Paxos)

Result: 1 round trip per log entry (in normal case)
        Same as Raft performance
```

```mermaid
flowchart TB
    subgraph Election["Leader Election (one-time)"]
        E1["Node 1: PREPARE(100)"]
        E2["Majority: PROMISE(100)"]
        E3["Node 1 becomes leader"]
    end

    subgraph Normal["Normal Operation (fast path)"]
        N1["Leader: ACCEPT(100, cmd1)"]
        N2["Majority: ACCEPTED"]
        N3["Leader: ACCEPT(100, cmd2)"]
        N4["Majority: ACCEPTED"]
        N5["Leader: ACCEPT(100, cmd3)"]
        N6["Majority: ACCEPTED"]
    end

    Election --> Normal

    style E3 fill:#059669,color:#fff
    style N1 fill:#2563eb,color:#fff
    style N3 fill:#2563eb,color:#fff
    style N5 fill:#2563eb,color:#fff
```

### Real-World Paxos Usage

```
Google Chubby:
──────────────
Distributed lock service
Uses Multi-Paxos for consensus
Powers BigTable, GFS coordination

Google Spanner:
───────────────
Globally distributed SQL database
Paxos for replication within each shard
TrueTime API for ordering across shards

Apache ZooKeeper:
─────────────────
Uses Zab (similar to Multi-Paxos)
Coordination service for Hadoop, Kafka, HBase

Challenges with Paxos:
──────────────────────
❌ Hard to understand (even Lamport admits it)
❌ Hard to implement correctly
❌ Many subtle edge cases
❌ Original paper doesn't cover real-world issues (log compaction, membership changes)

Result: Most systems use Raft instead (simpler, equivalent)
```

## Raft Consensus Algorithm

**"Paxos made understandable" (Ongaro & Ousterhout, 2014)**

```
Why Raft was Created:
──────────────────────
Paxos is notoriously hard to understand and implement.
Raft was designed to be:
✅ Easier to understand (clear leader-based model)
✅ Easier to implement (reference implementation available)
✅ Equivalent safety to Paxos
✅ Practical (covers log compaction, membership changes)

Core Idea:
──────────
Decompose consensus into three independent subproblems:
1. Leader election
2. Log replication
3. Safety

Only the leader can append to the log.
Followers simply replicate the leader's log.
```

### Raft Overview

```
Server Roles:
─────────────

Leader:     Handles all client requests
            Appends to log, replicates to followers
            Only one leader per term

Follower:   Passive: respond to leader and candidates
            Replicate leader's log
            Redirect clients to leader

Candidate:  Trying to become leader
            Requests votes from other servers

Role Transitions:
─────────────────

    Starts election       Receives votes        Times out
        ┌─────┐              from majority       starts new
        │     ▼                  │                election
    Follower → Candidate ────────► Leader         │
        ▲           ▲                  │           │
        │           │                  │           ▼
        │           └──────────────────┘       Candidate
        │        Discovers leader or
        │         new term
        │
    Discovers server
    with higher term
```

### Raft Terms

```
Term = Logical clock / Epoch number
───────────────────────────────────

Each term has at most one leader.
Term increments on each election attempt.

Timeline:
─────────

Term 1    Term 2    Term 3    Term 4    Term 5
──────    ──────    ──────    ──────    ──────
Leader    Leader      X       Leader    Leader
  A         B      (split)      C         C
                   election
                    failed

Term in messages:
─────────────────
Every RPC includes sender's current term.

Receiver checks:
- If RPC term > current term: update to RPC term, convert to follower
- If RPC term < current term: reject RPC

This ensures stale leaders can't disrupt new leaders.
```

### Leader Election

```mermaid
sequenceDiagram
    participant C as Candidate (Node 2)
    participant N1 as Node 1
    participant N3 as Node 3
    participant N4 as Node 4
    participant N5 as Node 5

    Note over C: Election timeout<br/>No heartbeat from leader

    Note over C: Increment term → 5<br/>Vote for self<br/>Become Candidate

    par Request votes
        C->>N1: RequestVote(term=5)
        C->>N3: RequestVote(term=5)
        C->>N4: RequestVote(term=5)
        C->>N5: RequestVote(term=5)
    end

    Note over N1,N5: Haven't voted in term 5 yet<br/>Candidate's log is up-to-date

    par Grant votes
        N1-->>C: VoteGranted
        N3-->>C: VoteGranted
        N4-->>C: VoteGranted (delayed)
        N5--xC: Network partition (vote lost)
    end

    Note over C: Received 3 votes (including self)<br/>Majority of 5 = 3<br/>Become Leader!

    par Send heartbeats
        C->>N1: AppendEntries (heartbeat)
        C->>N3: AppendEntries (heartbeat)
        C->>N4: AppendEntries (heartbeat)
        C->>N5: AppendEntries (heartbeat)
    end

    Note over N1,N5: Recognize new leader<br/>Convert to Follower
```

**Election Rules:**

```
Follower (election timeout):
─────────────────────────────
1. Increment current term
2. Vote for self
3. Send RequestVote to all other servers
4. Reset election timeout (randomized 150-300ms)

Candidate (on receiving votes):
────────────────────────────────
If majority grant votes:
  → Become leader
  → Send heartbeat to all servers immediately

If receive AppendEntries from leader with term >= current:
  → Recognize leader, convert to follower

If election timeout:
  → Start new election (increment term, request votes again)

Server (on receiving RequestVote):
───────────────────────────────────
Grant vote if ALL of:
1. Candidate's term >= current term
2. Haven't voted in this term yet (or voted for this candidate)
3. Candidate's log is "at least as up-to-date" (see below)

Otherwise: reject

Up-to-date check:
─────────────────
Candidate's log is at least as up-to-date if:
- Last log term > receiver's last log term, OR
- Last log term == receiver's last log term AND
  log length >= receiver's log length

This prevents servers with stale logs from becoming leader.
```

**Split Vote Scenario:**

```
Problem: Multiple candidates start election simultaneously
─────────────────────────────────────────────────────────

5 nodes, 2 candidates:
Candidate A gets votes from: A, B     (2 votes)
Candidate B gets votes from: C, D     (2 votes)
Node E: network partition (doesn't vote)

Neither gets majority (need 3/5).

Solution: Randomized timeouts
──────────────────────────────
Each server chooses random election timeout (150-300ms).

Likely outcome:
- One server times out first → becomes candidate
- Requests votes before others timeout
- Gets majority before others start their own election

If split vote occurs anyway:
- Both candidates timeout (different random times)
- One times out first, starts new term
- Gets majority in new term

Probability of repeated split votes: very low (exponentially decreasing)
```

### Log Replication

```
Client Request Flow:
────────────────────

1. Client sends command to leader
2. Leader appends command to its log (uncommitted)
3. Leader sends AppendEntries to followers
4. Followers append to their logs
5. Followers respond success
6. Leader receives majority acks → commit
7. Leader applies command to state machine
8. Leader responds to client
9. Leader notifies followers to commit (in next heartbeat)
10. Followers apply command to state machine

State Machine:
──────────────
Deterministic: same inputs → same outputs
Examples: key-value store, database, lock service

Log Structure:
──────────────

Index:  1    2    3    4    5    6    7
Term:   1    1    1    2    2    2    3
Cmd:   x=1  y=2  z=3  x=4  y=5  x=6  y=7
        └──committed───┘ └─uncommitted─┘
                          (not majority yet)

commitIndex = 3 (highest index known to be committed)
lastApplied = 3 (highest index applied to state machine)
```

```mermaid
sequenceDiagram
    participant C as Client
    participant L as Leader
    participant F1 as Follower 1
    participant F2 as Follower 2
    participant F3 as Follower 3

    C->>L: SET x=5

    Note over L: Append to log (index=4)<br/>term=2, cmd="SET x=5"

    par Replicate to followers
        L->>F1: AppendEntries(term=2, entries=[SET x=5])
        L->>F2: AppendEntries(term=2, entries=[SET x=5])
        L->>F3: AppendEntries(term=2, entries=[SET x=5])
    end

    Note over F1,F3: Append to log<br/>Not yet committed

    par Acknowledge
        F1-->>L: Success
        F2-->>L: Success
        F3--xL: Network delay (no response yet)
    end

    Note over L: Received 2/3 follower acks<br/>+ leader = 3/5 majority<br/>Commit index=4

    L->>C: OK (x=5)

    Note over L: Apply "SET x=5" to state machine

    par Next heartbeat
        L->>F1: AppendEntries(commitIndex=4)
        L->>F2: AppendEntries(commitIndex=4)
        L->>F3: AppendEntries(commitIndex=4)
    end

    Note over F1,F3: commitIndex=4<br/>Apply "SET x=5" to state machine
```

**AppendEntries RPC:**

```
Leader sends:
─────────────
term:          Leader's current term
leaderId:      So followers can redirect clients
prevLogIndex:  Index of log entry immediately before new ones
prevLogTerm:   Term of prevLogIndex entry
entries[]:     Log entries to append (empty for heartbeat)
leaderCommit:  Leader's commitIndex

Follower responds:
──────────────────
term:    Current term (for leader to update itself)
success: true if follower has entry matching prevLogIndex and prevLogTerm

Follower logic:
───────────────
1. If term < currentTerm: reject (stale leader)
2. If log doesn't have entry at prevLogIndex with prevLogTerm:
   → reject (log inconsistency)
3. If existing entry conflicts with new one (same index, different term):
   → delete existing entry and all following it
4. Append new entries
5. If leaderCommit > commitIndex:
   → set commitIndex = min(leaderCommit, index of last new entry)
   → apply newly committed entries to state machine
```

**Handling Log Inconsistencies:**

```
Scenario: Leader crashes, new leader elected
────────────────────────────────────────────

Follower logs might diverge:

Leader (term 6):  1 1 1 2 2 2 3 3 4 4 5 6
                  ─────────────────────────

Follower A:       1 1 1 2 2 2 3 3 4 4 5 6   (matches)
Follower B:       1 1 1 2 2 2 3 3 4         (missing entries)
Follower C:       1 1 1 2 2 2 3 3 3         (extra uncommitted)
Follower D:       1 1 1 2 2                 (way behind)

Log Repair:
───────────
Leader decrements nextIndex[] for each follower until it finds match.

Leader → Follower B:
  AppendEntries(prevLogIndex=11, prevLogTerm=6) → reject
  AppendEntries(prevLogIndex=10, prevLogTerm=4) → reject
  AppendEntries(prevLogIndex=9, prevLogTerm=4) → success! ✅
  Now append entries 10, 11

Leader → Follower C:
  AppendEntries(prevLogIndex=11, prevLogTerm=6) → reject
  AppendEntries(prevLogIndex=10, prevLogTerm=4) → reject
  AppendEntries(prevLogIndex=9, prevLogTerm=4) → reject
  AppendEntries(prevLogIndex=8, prevLogTerm=3) → success!
  Delete conflicting entry at index 9 (term 3)
  Append entries 9(term 4), 10, 11

Optimization:
─────────────
Follower can return (conflictingTerm, firstIndexOfTerm)
Leader jumps back to start of conflicting term
Reduces round trips
```

### Safety Properties

```
Raft Safety Guarantees:
───────────────────────

1. Election Safety:
   ─────────────────
   At most one leader per term

2. Leader Append-Only:
   ───────────────────
   Leader never overwrites or deletes entries in its log

3. Log Matching:
   ─────────────
   If two logs contain an entry with same index and term,
   then they contain identical entries up to that index

4. Leader Completeness:
   ────────────────────
   If a log entry is committed in a given term,
   that entry will be present in the leaders' logs
   for all higher-numbered terms

5. State Machine Safety:
   ─────────────────────
   If a server has applied a log entry at a given index,
   no other server will ever apply a different entry
   for the same index
```

**Election Restriction (ensures Leader Completeness):**

```
Problem:
────────
What if a candidate with incomplete log gets elected?
It would overwrite committed entries!

Example (dangerous scenario):
─────────────────────────────

Server 1 (leader term 3):   1 1 1 2 2 2 3(committed)
Server 2 (crashed, old):    1 1 1
Server 3 (follower):        1 1 1 2 2 2 3

Server 2 comes back, starts election in term 4.
If elected, would Server 2 overwrite committed entry 3? ❌

Solution: Up-to-date check in RequestVote
──────────────────────────────────────────

Candidate's log must be "at least as up-to-date":

lastLogTerm = 1 < 3 → Server 2's log is outdated
Server 3 rejects vote.

Server 2 can't get majority (needs server with term 3 entry).

Only servers with committed entries can become leader.
```

**Commit Rules:**

```
Leader commit conditions:
─────────────────────────

Entry can be committed when:
1. Stored on majority of servers, AND
2. At least one entry from current term is on majority

Why rule #2?
────────────

Without it:

Term 1: Leader A replicates entry to 2/5 servers, crashes
Term 2: Leader B elected, doesn't replicate entry, crashes
Term 3: Leader A re-elected, sees entry on 2/5 servers
        Should it commit? NO!
        
        If it commits and crashes, new leader might not have it.

With rule #2:

Term 3: Leader A appends no-op entry in term 3
        Replicates term 3 entry to majority
        Now commits term 3 entry
        As a side effect, commits term 1 entry too

This ensures committed entries are never lost.
```

### Raft vs Paxos Comparison

| Aspect | Raft | Paxos |
|---|---|---|
| **Understandability** | Designed for clarity | Notoriously complex |
| **Leader** | Strong leader (only leader appends) | Weak leader (can have multiple proposers) |
| **Log structure** | Must be contiguous, ordered | Can have holes |
| **Election** | Randomized timeouts | Prepare/promise phases |
| **Normal operation** | 1 round trip (leader→followers) | 1 round trip (Multi-Paxos) |
| **Log repair** | Leader overwrites follower logs | Complex merge logic |
| **Membership changes** | Joint consensus (two-phase) | Not specified in original |
| **Implementation** | ~2000 lines (reference) | Much larger, subtle edge cases |
| **Correctness** | TLA+ spec, model checked | Multiple interpretations exist |
| **Performance** | Equivalent | Equivalent (when optimized) |
| **Real usage** | etcd, Consul, CockroachDB | Chubby, Spanner (rare) |

```
Bottom Line:
────────────
Raft and Paxos provide equivalent guarantees.

Raft is much easier to understand and implement correctly.

Use Raft unless:
- You have Paxos experts on your team
- You're maintaining legacy Paxos code
- You need a specific Paxos variant (e.g., Fast Paxos)
```

### Raft in Production

```
etcd:
─────
Distributed key-value store
Used by Kubernetes for configuration
Raft replication across 3-5 nodes
Linearizable reads/writes

Consul:
───────
Service mesh and service discovery
HashiCorp's consensus layer
Raft for leader election and state
Multi-datacenter support

CockroachDB:
────────────
Distributed SQL database
Each range (shard) is a Raft group
Thousands of Raft groups per cluster
Used for replication and consistency

Dgraph:
───────
Distributed graph database
Raft for consensus and replication
```

## Other Consensus Protocols

### ZooKeeper's Zab (ZooKeeper Atomic Broadcast)

```
What is Zab?
────────────
Consensus protocol used by Apache ZooKeeper.
Similar to Multi-Paxos/Raft but optimized for ZooKeeper's use case.

Differences from Raft:
──────────────────────
✅ Optimized for read-heavy workloads
✅ Broadcast protocol (leader broadcasts updates)
✅ Focus on total order of messages
✅ Primary-backup replication model

Phases:
───────
1. Leader Election: Similar to Raft
2. Discovery: New leader learns most recent state
3. Synchronization: Leader syncs all followers
4. Broadcast: Normal operation (like Raft log replication)

ZooKeeper Guarantees:
─────────────────────
✅ Linearizable writes (all go through leader)
✅ FIFO client ordering
✅ Sequential consistency for reads
   (reads can be served by followers)

Performance:
────────────
Reads: 100k+ ops/sec (served locally by followers)
Writes: ~10k ops/sec (must go through leader)

Used by:
────────
- Hadoop (NameNode HA, ResourceManager HA)
- Kafka (controller election, topic metadata)
- HBase (region assignment)
- Solr (cluster coordination)
```

### Viewstamped Replication

```
What is Viewstamped Replication (VR)?
──────────────────────────────────────
Published in 1988 (before Paxos!).
Independently discovered similar ideas.

Concepts:
─────────
View number = Term (in Raft terminology)
Primary = Leader
Backup = Follower

Similarities to Raft:
─────────────────────
✅ Primary-backup replication
✅ View changes (like leader election)
✅ Log-based state machine replication
✅ Quorum-based commits

Why not widely used?
────────────────────
Published in academic paper, not widely known until recently.
Paxos and Raft became more popular.

Historical significance:
────────────────────────
Showed consensus was possible before Paxos.
Influenced Raft's design.
```

### Byzantine Fault Tolerance (PBFT)

```
What is PBFT?
─────────────
Practical Byzantine Fault Tolerance (Castro & Liskov, 1999)
Handles Byzantine faults (malicious nodes).

Byzantine Faults:
─────────────────
❌ Node sends different messages to different nodes
❌ Corrupted memory/disk
❌ Malicious node (hacked, compromised)
❌ Software bugs that cause arbitrary behavior

Requirements:
─────────────
Need 3f+1 nodes to tolerate f Byzantine nodes.

Example: 4 nodes can tolerate 1 Byzantine node
         7 nodes can tolerate 2 Byzantine nodes

Why 3f+1?
─────────
Need to distinguish faulty from non-faulty responses.
With 3f+1 nodes:
- f nodes can be faulty
- f nodes might be slow/unreachable
- f+1 nodes are guaranteed honest and responsive
- f+1 is a majority of non-faulty nodes (2f+1)

PBFT Phases:
────────────
1. Pre-prepare: Primary proposes operation
2. Prepare: Replicas agree on order
3. Commit: Replicas commit operation
4. Reply: Replicas respond to client

Client must wait for f+1 matching replies.
```

```mermaid
sequenceDiagram
    participant C as Client
    participant P as Primary
    participant R1 as Replica 1
    participant R2 as Replica 2
    participant R3 as Replica 3

    C->>P: Request(operation)
    
    Note over P: Assign sequence number

    par Pre-prepare
        P->>R1: PRE-PREPARE(seq, op)
        P->>R2: PRE-PREPARE(seq, op)
        P->>R3: PRE-PREPARE(seq, op)
    end

    Note over R1,R3: Verify sequence number<br/>Accept pre-prepare

    par Prepare (replicas broadcast)
        R1->>R2: PREPARE(seq, op)
        R1->>R3: PREPARE(seq, op)
        R2->>R1: PREPARE(seq, op)
        R2->>R3: PREPARE(seq, op)
        R3->>R1: PREPARE(seq, op)
        R3->>R2: PREPARE(seq, op)
    end

    Note over R1,R3: Wait for 2f PREPAREs<br/>All agree on sequence

    par Commit (replicas broadcast)
        R1->>R2: COMMIT(seq, op)
        R1->>R3: COMMIT(seq, op)
        R2->>R1: COMMIT(seq, op)
        R2->>R3: COMMIT(seq, op)
        R3->>R1: COMMIT(seq, op)
        R3->>R2: COMMIT(seq, op)
    end

    Note over R1,R3: Wait for 2f+1 COMMITs<br/>Execute operation

    par Reply
        P->>C: REPLY(result)
        R1->>C: REPLY(result)
        R2->>C: REPLY(result)
        R3->>C: REPLY(result)
    end

    Note over C: Wait for f+1 matching replies<br/>(2 replies = f+1 where f=1)
```

**PBFT Challenges:**

```
Performance:
────────────
❌ O(n²) messages (every replica talks to every other)
❌ Much slower than crash fault tolerance (Raft)
❌ High CPU overhead (signature verification)

Scalability:
────────────
❌ Limited to ~10-20 nodes
❌ 3f+1 requirement means expensive redundancy

When to use PBFT:
─────────────────
✅ Untrusted environment (blockchain, multi-org consortium)
✅ High security requirements
✅ Can tolerate lower performance
✅ Small number of nodes

Modern Byzantine consensus:
───────────────────────────
- Tendermint: Used by Cosmos blockchain
- HotStuff: Used by Diem (formerly Libra)
- Istanbul BFT: Used by some enterprise blockchains

Crash fault tolerance usually sufficient:
──────────────────────────────────────────
Most systems assume:
- Nodes are not malicious (datacenter environment)
- Use checksums to detect corruption
- Use authentication to prevent tampering
- Byzantine faults are rare

Raft/Paxos is enough for 99% of use cases.
```

## Practical Applications

### Distributed Databases

```
Consensus in Databases:
───────────────────────

CockroachDB:
────────────
- Each range (64MB shard) is a Raft group
- Raft for replication across replicas
- Guarantees serializable isolation
- Automatic rebalancing preserves Raft groups

Example:
  Range 1 [a-m]:  Raft group {Node 1, Node 2, Node 3}
  Range 2 [n-z]:  Raft group {Node 2, Node 3, Node 4}

TiDB:
─────
- Based on Raft (via tikv storage layer)
- Each region is a Raft group
- Placement driver uses etcd (also Raft!)
- Multi-Raft architecture

MongoDB:
────────
- Replica set = one Raft-like protocol
- Primary-secondary replication
- Automatic failover using election
- Configurable write concern (w:majority)

Spanner:
────────
- Paxos for replication within each shard
- TrueTime for global ordering across shards
- Synchronous replication (strong consistency)
```

### Configuration Management

```
Use Case:
─────────
Distributed systems need shared configuration:
- Service discovery
- Feature flags
- Leader election
- Distributed locks

Why Consensus?
──────────────
Configuration must be consistent across all nodes.
Can't have split-brain (two leaders).

etcd:
─────
Distributed key-value store with Raft.

API:
  PUT /config/db_host value="db1.example.com"
  GET /config/db_host
  DELETE /config/db_host

Guarantees:
✅ Linearizable reads/writes
✅ Watch for changes (pub/sub)
✅ Lease-based TTLs
✅ Transactions (compare-and-swap)

Used by Kubernetes:
───────────────────
- Store cluster state (pods, services, nodes)
- Controller leader election
- Configuration data

Consul:
───────
Service discovery + config + health checks.

Features:
- DNS and HTTP API
- Multi-datacenter support
- Health checking with automatic failover
- KV store (Raft-based)

Example:
  Register service:
    consul services register web.json
  
  Discover service:
    dig @127.0.0.1 -p 8600 web.service.consul
```

### Leader Election Patterns

```
Pattern 1: Lease-based Leader Election
───────────────────────────────────────

1. Candidate writes ephemeral key to etcd with TTL:
   PUT /leader/primary value="node1" lease=10s

2. If write succeeds: becomes leader

3. Leader renews lease every 5s (before TTL expires)

4. If leader crashes: lease expires, key deleted

5. Other nodes watch /leader/primary
   When key deleted → start new election

Used by: Kubernetes controllers, Hadoop YARN


Pattern 2: Lowest ID Election
──────────────────────────────

1. All nodes create ephemeral sequential keys:
   /election/candidate-0000000001
   /election/candidate-0000000002
   /election/candidate-0000000003

2. Node with lowest ID is leader

3. Others watch next lowest ID
   If it disappears → check if now leader

Used by: ZooKeeper recipes


Pattern 3: Consensus-based Election
────────────────────────────────────

Run Raft/Paxos to elect leader.
Leader continues until it fails.

Used by: etcd (internal leader), Consul


Example: Distributed Cron Job
──────────────────────────────

Problem: Run scheduled task exactly once (not multiple times).

Solution:
1. Multiple workers try to acquire lock:
   TXN:
     IF NOT EXISTS /lock/daily_report
     THEN PUT /lock/daily_report value="worker1" lease=60s

2. Winner gets lock → runs job

3. Other workers retry later (or wait until next day)

4. Lock auto-releases after 60s (in case worker crashes mid-job)
```

## When to Use Which Algorithm

### Decision Matrix

```
Choose Raft if:
───────────────
✅ Building new system
✅ Need strong consistency
✅ Team unfamiliar with consensus algorithms
✅ Want clear, well-documented protocol
✅ Need full-featured implementation (log compaction, membership changes)

Examples: etcd, Consul, custom distributed systems


Choose Paxos if:
────────────────
✅ Maintaining legacy Paxos system
✅ Team has Paxos experts
✅ Need specific variant (Fast Paxos, Cheap Paxos)
✅ Google (they use it everywhere)

Examples: Chubby, Spanner (Google-internal)


Choose Zab if:
──────────────
✅ Using ZooKeeper
✅ Read-heavy workload (reads don't need leader)
✅ Need ZooKeeper's ordering guarantees

Examples: Hadoop, Kafka, HBase (via ZooKeeper)


Choose PBFT/Byzantine if:
─────────────────────────
✅ Untrusted environment (multi-organization)
✅ Blockchain or cryptocurrency
✅ Security > performance
✅ Can tolerate high overhead

Examples: Tendermint, HotStuff, consortium blockchains


Choose Eventual Consistency if:
───────────────────────────────
✅ Consensus is too slow
✅ Availability > consistency
✅ Can tolerate conflicts
✅ Scale matters more than strong guarantees

Examples: DynamoDB, Cassandra (no consensus, use quorums)
```

### Consensus vs Quorums

```
Consensus (Raft/Paxos):
───────────────────────
Guarantees: Linearizable, strongly consistent
Mechanism: Explicit agreement protocol
Performance: 1-2 round trips per operation
Availability: Requires majority (n/2 + 1)
Complexity: High (election, log replication)

When to use:
- Need strong consistency guarantees
- Leader election required
- Configuration management
- Small cluster (3-5 nodes)

Quorums (Dynamo-style):
───────────────────────
Guarantees: Tunable consistency (W+R>N for strong)
Mechanism: No explicit agreement, just overlapping sets
Performance: 1 round trip (parallel reads/writes)
Availability: Can tune for higher availability
Complexity: Lower (no leader, no election)

When to use:
- Can tolerate eventual consistency
- Need high availability
- Large cluster (100s of nodes)
- Read/write heavy workload

Comparison:
───────────
                    Consensus      Quorums
Consistency:        Strong         Tunable
Availability:       Medium (CP)    High (AP)
Latency:            Higher         Lower
Leader election:    Yes            No
Complexity:         Higher         Lower
Scale:              <10 nodes      100s nodes

You can use BOTH:
─────────────────
Consensus for metadata (who's the leader?)
Quorums for data (replicate log entries)

Example: CockroachDB uses Raft for replication,
         but Raft itself is a consensus algorithm.
```

## Common Interview Questions

```
Q1: Explain the difference between Raft and Paxos.
───────────────────────────────────────────────────

A: Both provide equivalent safety guarantees. Raft is designed for
   understandability with a strong leader model (only leader appends
   to log). Paxos is more flexible but complex (multiple proposers can
   compete). Raft is easier to implement correctly. In production,
   Raft is more common (etcd, Consul, CockroachDB).


Q2: How does Raft handle a network partition?
──────────────────────────────────────────────

A: Raft requires a majority quorum to make progress. If the cluster
   splits into [A,B] and [C,D,E] (5 nodes), only the majority partition
   [C,D,E] can elect a leader and accept writes. The minority [A,B]
   refuses writes (no quorum). When partition heals, [A,B] recognize
   the new leader (higher term) and replicate its log. This prevents
   split-brain.


Q3: What is the FLP impossibility result?
──────────────────────────────────────────

A: Fischer, Lynch, Paterson proved (1985) that in an asynchronous
   distributed system with even one faulty node, no deterministic
   consensus algorithm can guarantee termination. In practice, systems
   use timeouts, randomization, or assume partial synchrony (bounded
   message delays most of the time). Raft and Paxos are safe but may
   not terminate if there's no majority.


Q4: How does a Raft leader ensure committed entries are never lost?
────────────────────────────────────────────────────────────────────

A: Raft's election restriction: a candidate can only become leader if
   its log is "at least as up-to-date" as a majority. This is checked
   during voting (compare last log term and length). A candidate with
   an incomplete log won't get majority votes. Therefore, any new leader
   has all committed entries.


Q5: What's the difference between crash faults and Byzantine faults?
────────────────────────────────────────────────────────────────────

A: Crash faults: nodes fail by stopping (fail-stop). Raft/Paxos handle
   crash faults. Byzantine faults: nodes behave arbitrarily (send
   conflicting messages, corrupt data, malicious). PBFT and blockchain
   consensus handle Byzantine faults. Byzantine tolerance requires
   3f+1 nodes to tolerate f faults (vs 2f+1 for crash faults).


Q6: When would you choose eventual consistency over consensus?
───────────────────────────────────────────────────────────────

A: When availability and performance are more important than strong
   consistency. Examples: shopping carts (can tolerate temporary
   staleness), social media feeds (eventual consistency is fine),
   analytics (approximate results acceptable). Consensus adds latency
   and reduces availability during partitions. Use eventual consistency
   for AP systems (DynamoDB, Cassandra).


Q7: How does ZooKeeper differ from etcd?
─────────────────────────────────────────

A: Both are coordination services with consensus. ZooKeeper uses Zab
   (similar to Paxos), etcd uses Raft. Key differences:
   - ZooKeeper allows stale reads from followers (sequential consistency)
   - etcd defaults to linearizable reads (must go through leader)
   - ZooKeeper has watches, sessions, ephemeral nodes
   - etcd has simpler API (HTTP/gRPC), leases, transactions
   - etcd is more modern (better for Kubernetes)


Q8: Explain Multi-Paxos optimization.
──────────────────────────────────────

A: Basic Paxos requires 2 phases (PREPARE + ACCEPT) per value. Multi-Paxos
   elects a stable leader who can skip PREPARE for subsequent values.
   Leader already has promises from majority, so it sends ACCEPT directly.
   This reduces latency from 2 round trips to 1. If leadership changes,
   new leader runs full Paxos to get promises. Equivalent to Raft's
   normal operation (leader sends AppendEntries).


Q9: How do you prevent split-brain in distributed systems?
───────────────────────────────────────────────────────────

A: Use quorum-based consensus. Require majority (n/2 + 1) to make
   decisions. During partition, at most one partition has majority.
   Minority partition cannot elect leader or accept writes. Prevents
   conflicting writes. Alternative: use external coordinator (ZooKeeper,
   etcd) for tie-breaking. Never use naive "ping-pong" leader election
   (can cause split-brain).


Q10: What is log compaction in Raft?
─────────────────────────────────────

A: Raft log grows unbounded (every operation appended). Compaction
   creates a snapshot of the state machine at a certain index, then
   discards log entries before that index. Snapshot includes:
   - Last included index and term
   - State machine state
   Sent to slow followers via InstallSnapshot RPC. Reduces disk usage
   and recovery time. Similar to database checkpointing.
```

## Practice Exercises

### Exercise 1: Raft Leader Election

```
Scenario:
─────────
5-node Raft cluster (A, B, C, D, E)
Current term: 3
Current leader: A

A crashes. Election timeout expires on B first.

Questions:
──────────
1. What does B do?
2. What term will B use for RequestVote?
3. If C and D grant votes, but E's message is delayed, can B become leader?
4. What happens when E's vote arrives?
5. If A comes back online during the election, what happens?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. What does B do?
   ────────────────
   - Increment term → 4
   - Vote for self
   - Send RequestVote(term=4) to A, C, D, E
   - Become Candidate
   - Reset election timeout (randomized)

2. What term will B use?
   ──────────────────────
   Term 4 (incremented from 3)

3. Can B become leader with C and D's votes?
   ──────────────────────────────────────────
   Yes! B has:
   - Self vote (B)
   - C's vote
   - D's vote
   Total: 3/5 = majority
   
   B becomes leader immediately (doesn't wait for E).

4. What happens when E's vote arrives?
   ────────────────────────────────────
   B ignores it (already leader).
   B sends heartbeat to E.
   E recognizes B as leader, converts to follower.

5. If A comes back during election?
   ─────────────────────────────────
   A is still in term 3.
   When A receives RequestVote(term=4) from B:
   - A updates to term 4
   - A converts to follower
   - A may grant vote to B (if B's log is up-to-date)
```

</details>

### Exercise 2: Log Replication Conflict

```
Scenario:
─────────
Leader (term 5): [1,1,2,2,3,3,4,4,5]
Follower X:      [1,1,2,2,3,3,3]

Leader sends AppendEntries:
  prevLogIndex = 7
  prevLogTerm = 4
  entries = [5]

Questions:
──────────
1. Does Follower X accept this AppendEntries? Why or why not?
2. If rejected, what does the leader do next?
3. How many round trips until logs match?
4. What will Follower X's log look like after sync?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Does Follower X accept?
   ────────────────────────
   No! Follower X checks:
   - Do I have entry at index 7? Yes: [1,1,2,2,3,3,3]
   - Does it have term 4? No: has term 3
   
   → Reject (log inconsistency)

2. What does leader do next?
   ──────────────────────────
   Leader decrements nextIndex for Follower X:
   nextIndex[X] = 7 → 6
   
   Retry:
   AppendEntries(prevLogIndex=6, prevLogTerm=3, entries=[4,5])
   
   Follower X checks:
   - Entry at index 6? Yes: term 3
   - Term matches? Yes! ✅
   
   → Accept

3. How many round trips?
   ──────────────────────
   2 round trips:
   - Round trip 1: reject (prevLogIndex=7)
   - Round trip 2: accept (prevLogIndex=6)

4. Final log for Follower X?
   ──────────────────────────
   [1,1,2,2,3,3,4,5]
   
   Follower deletes conflicting entry at index 7 (term 3)
   Appends entries [4,5]
   Now matches leader.
```

</details>

### Exercise 3: Byzantine Generals

```
Scenario:
─────────
4 generals: A (loyal), B (loyal), C (loyal), D (traitor)
Need to agree on attack or retreat.

D (traitor) sends:
- "Attack" to A
- "Retreat" to B
- "Attack" to C

Each general also forwards messages they receive.

Questions:
──────────
1. Can the 3 loyal generals reach agreement?
2. How many rounds of messages are needed?
3. What algorithm can they use?
4. What if there were 2 traitors out of 5 generals?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Can they reach agreement?
   ──────────────────────────
   Yes! 3f+1 = 4 can tolerate f=1 Byzantine fault.
   
   Loyal generals use Byzantine consensus:
   - Each general broadcasts their vote
   - Collect all votes
   - Discard outliers (majority vote)

2. How many rounds?
   ────────────────
   2 rounds minimum:
   
   Round 1: Each general broadcasts their vote
   Round 2: Each general forwards what they heard
   
   Now each general has:
   - Their own vote
   - Direct votes from others
   - Forwarded votes (to detect traitor inconsistency)

3. What algorithm?
   ────────────────
   Simplified Byzantine agreement:
   
   After 2 rounds, each loyal general knows:
   A heard from D: "Attack"
   B heard from D: "Retreat"
   C heard from D: "Attack"
   
   Majority from D: "Attack" (2/3)
   
   All loyal generals apply majority vote → all decide "Attack"

4. With 2 traitors out of 5?
   ──────────────────────────
   Need 3f+1 nodes:
   f=2 → need 7 generals
   
   With only 5 generals and 2 traitors:
   - 3 loyal, 2 traitors
   - Not enough! 3 < 3*2+1=7
   
   Traitors can cause loyal generals to disagree.
   No consensus possible with 2 traitors in 5 nodes.
```

</details>

### Exercise 4: Quorum Consistency

```
Scenario:
─────────
5-node cluster, tunable consistency

Write configuration: W=3 (write to 3 replicas)
Read configuration:  R=2 (read from 2 replicas)

Questions:
──────────
1. Is this configuration strongly consistent? (W+R > N?)
2. Client writes X=5, and 3 replicas acknowledge. Then one replica
   crashes before replicating. Client reads X from 2 replicas.
   Is the read guaranteed to see X=5?
3. What's the minimum R to guarantee strong consistency with W=3?
4. If we change to W=1, R=1, what consistency do we get?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Is this strongly consistent?
   ─────────────────────────────
   W=3, R=2, N=5
   W + R = 3 + 2 = 5
   5 = N (not > N)
   
   → NO, not strongly consistent!
   
   Need W + R > N for strong consistency.

2. Is the read guaranteed to see X=5?
   ────────────────────────────────────
   No! Scenario:
   
   Write X=5 goes to replicas A, B, C
   Replica C crashes
   Read from replicas D, E (didn't get the write yet)
   
   Read might see old value!
   
   W+R=N means possible overlap, but not guaranteed.

3. Minimum R for strong consistency?
   ──────────────────────────────────
   Need W + R > N
   3 + R > 5
   R > 2
   R = 3 minimum
   
   With W=3, R=3: 3+3=6 > 5 ✅ strong consistency

4. W=1, R=1 consistency?
   ──────────────────────
   W + R = 1 + 1 = 2 < 5
   
   Eventual consistency only.
   
   Reads might see stale data.
   High availability, low latency.
   Used for caching, shopping carts.
```

</details>

## Summary

- **Distributed consensus** allows nodes to agree on values despite failures
- **CAP theorem**: Consensus algorithms are CP (sacrifice availability during partition)
- **Byzantine Generals Problem**: Shows difficulty of consensus with malicious nodes
- **FLP impossibility**: Perfect consensus is impossible in asynchronous systems
- **Paxos**: Original consensus algorithm, complex but foundational
  - Phases: Prepare/Promise, Accept/Accepted, Learn
  - Multi-Paxos optimization: stable leader skips prepare phase
- **Raft**: Modern alternative, designed for understandability
  - Leader election with randomized timeouts
  - Log replication from leader to followers
  - Safety via election restriction (up-to-date log required)
  - Widely used: etcd, Consul, CockroachDB
- **Zab**: ZooKeeper's protocol, optimized for read-heavy workloads
- **PBFT**: Byzantine fault tolerance for untrusted environments (blockchain)
- **Use consensus for**: leader election, configuration management, distributed locks
- **Choose Raft** for new systems (easier to understand and implement)
- **Choose quorums** (Dynamo-style) for high availability over strong consistency

## Next Steps

- Explore [Replication](../16-replication/README.md) for related concepts
- Study [CAP Theorem](../07-cap-theorem/README.md) for theoretical foundations
- Review [Consistency Models](../08-consistency/README.md) for application-level guarantees

---

**Key Takeaway**: Distributed consensus is essential for building reliable distributed systems. Raft provides a practical, understandable approach to achieving strong consistency and fault tolerance, making it the consensus algorithm of choice for modern distributed systems.
