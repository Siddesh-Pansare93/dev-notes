# Circuit Breaker

## The Cascading Failure Problem

```
Microservice architecture without circuit breakers:

User Request
     │
     ▼
 [API Gateway]
     │
     ▼
[Order Service] ──────────────► [Payment Service] ← SLOW (DB timeout)
     │                               │
     │ waits 30s for timeout         │ waits 30s for DB
     │                               │
     ▼                               ▼
All threads blocked              DB connection pool exhausted
     │
     ▼
[API Gateway] starts timing out
     │
     ▼
[Load Balancer] retries → more requests → more blocked threads
     │
     ▼
ENTIRE SYSTEM DOWN
```

One slow database brings down everything — the cascade:

```
DB slow (500ms → 30s)
  → Payment Service threads exhausted
    → Order Service requests queued
      → API Gateway connection pool full
        → Load balancer health checks failing
          → All users see 503
            → Incident declared
```

**Root cause**: Services blindly wait for failing dependencies instead of failing fast.

## The Circuit Breaker Solution

Named after the electrical circuit breaker — it "trips" to stop the flow of current when a fault is detected.

```
Without circuit breaker:          With circuit breaker:
─────────────────────────         ─────────────────────────
Order → Payment (waiting...)      Order → CB → Payment
Order → Payment (waiting...)      Order → CB (OPEN: fail fast!)
Order → Payment (waiting...)      Order → CB (OPEN: fail fast!)

Order threads: EXHAUSTED          Order threads: FREE
Latency: 30s per request          Latency: 5ms per request
```

## Circuit Breaker State Machine

```mermaid
stateDiagram-v2
    [*] --> CLOSED : System starts

    CLOSED --> OPEN : Failure threshold exceeded\n(e.g. 5 failures in 10s)
    OPEN --> HALF_OPEN : Timeout elapsed\n(e.g. 30 seconds)
    HALF_OPEN --> CLOSED : Success threshold met\n(e.g. 3 successes)
    HALF_OPEN --> OPEN : Any failure during probe
```

### State: CLOSED (Normal Operation)

```
CLOSED state: requests flow through normally

Request ──► [CB: CLOSED] ──► Service
                │
                ▼
         Track outcomes:
         failures: 2 / 5 threshold
         (still under threshold → stay CLOSED)

Configuration:
  failure_threshold  = 5 failures
  window_size        = 10 seconds
  min_requests       = 3 (don't trip on 1 bad request)
```

### State: OPEN (Failing Fast)

```
OPEN state: all requests rejected immediately, no downstream calls

Request ──► [CB: OPEN] ──► 503 / fallback
                │
                ▼
         No call to service.
         Returns immediately.
         Timeout countdown running...

Configuration:
  open_timeout = 30 seconds (how long before trying again)

Why fast-fail helps:
✅ Threads freed immediately
✅ Cascading failure stopped
✅ Gives downstream time to recover
```

### State: HALF-OPEN (Probing Recovery)

```
HALF-OPEN state: allow a limited number of probe requests through

Request 1 ──► [CB: HALF-OPEN] ──► Service ──► SUCCESS
Request 2 ──► [CB: HALF-OPEN] ──► Service ──► SUCCESS
Request 3 ──► [CB: HALF-OPEN] ──► Service ──► SUCCESS
              ─────────────────────────────────
              success_threshold met → transition to CLOSED

Request 1 ──► [CB: HALF-OPEN] ──► Service ──► FAILURE
              ─────────────────────────────────
              any failure → back to OPEN immediately
```

### Cascading Failure vs Circuit Breaker

```mermaid
flowchart LR
    subgraph WITHOUT ["Without Circuit Breaker"]
        direction LR
        U1[User] --> GW1[API Gateway]
        GW1 --> OS1[Order\nService]
        OS1 -->|waits 30s| PS1[Payment\nService]
        PS1 -->|timeout| DB1[(DB Slow)]
        OS1 -->|threads full| GW1
        GW1 -->|503 cascade| U1
    end

    subgraph WITH ["With Circuit Breaker"]
        direction LR
        U2[User] --> GW2[API Gateway]
        GW2 --> OS2[Order\nService]
        OS2 --> CB[Circuit\nBreaker\nOPEN]
        CB -->|fail fast\n5ms| OS2
        OS2 -->|fallback| U2
        CB -.->|no calls| PS2[Payment\nService]
        PS2 -.-> DB2[(DB Slow)]
    end

    style CB fill:#ef4444,color:#fff
    style PS1 fill:#ef4444,color:#fff
    style DB1 fill:#ef4444,color:#fff
    style DB2 fill:#f59e0b,color:#fff
    style PS2 fill:#f59e0b,color:#fff
    style GW2 fill:#7c3aed,color:#fff
    style GW1 fill:#7c3aed,color:#fff
    style OS2 fill:#059669,color:#fff
```

## Configuration Parameters

```
Circuit Breaker Configuration:
────────────────────────────────

failure_threshold    = 50%       # trip if >50% of requests fail
minimum_requests     = 20        # don't trip on first bad request
window_size          = 60s       # evaluation window
open_timeout         = 30s       # time before trying HALF-OPEN
success_threshold    = 5         # successes needed to close

Tweaking for different services:
  Critical payment service:  lower threshold (20%), shorter timeout (10s)
  Slow analytics service:    higher threshold (70%), longer timeout (60s)
  Non-essential feature:     trip fast, return empty/cached fallback
```

## Bulkhead Pattern

**Isolate service connection pools** to prevent one slow service from exhausting all threads.

```
Without Bulkhead:
──────────────────
Thread pool: 200 threads (shared by all services)

Payment calls (slow): consumes 180 threads
Order calls:          20 threads left
User calls:           0 threads — BLOCKED
Search calls:         0 threads — BLOCKED

With Bulkhead:
──────────────
Thread pool A: 50 threads → Payment Service
Thread pool B: 50 threads → Order Service
Thread pool C: 50 threads → User Service
Thread pool D: 50 threads → Search Service

Payment slow → only pool A affected
Other services: unaffected
```

```mermaid
flowchart TD
    GW[API Gateway] --> BH1[Bulkhead A\n50 threads\nPayment]
    GW --> BH2[Bulkhead B\n50 threads\nOrders]
    GW --> BH3[Bulkhead C\n50 threads\nUsers]
    GW --> BH4[Bulkhead D\n50 threads\nSearch]

    BH1 --> PS[Payment Service\nSLOW]
    BH2 --> OS[Order Service\nOK]
    BH3 --> US[User Service\nOK]
    BH4 --> SS[Search Service\nOK]

    style PS fill:#ef4444,color:#fff
    style BH1 fill:#f59e0b,color:#fff
    style OS fill:#059669,color:#fff
    style US fill:#059669,color:#fff
    style SS fill:#059669,color:#fff
    style BH2 fill:#059669,color:#fff
    style BH3 fill:#059669,color:#fff
    style BH4 fill:#059669,color:#fff
    style GW fill:#7c3aed,color:#fff
```

Named after the watertight compartments in a ship — one flooded compartment does not sink the vessel.

## Retry with Exponential Backoff + Jitter

**Never retry immediately** — you will amplify the problem.

```
Naive retry (BAD):
──────────────────
t=0:    request fails
t=0ms:  retry 1 → fails
t=0ms:  retry 2 → fails
t=0ms:  retry 3 → fails

Result: service receives 4x traffic instantly

Exponential backoff (BETTER):
───────────────────────────────
t=0:    request fails
t=1s:   retry 1 → fails
t=2s:   retry 2 → fails
t=4s:   retry 3 → fails
t=8s:   retry 4 → fails
(stop after max retries)

Result: traffic spaced out, service has time to recover

With Jitter (BEST):
────────────────────
t=0:     request fails
t=1.3s:  retry 1 (1s ± 0.5s random)
t=2.7s:  retry 2 (2s ± 1s random)
t=5.1s:  retry 3 (4s ± 2s random)

Result: multiple clients don't all retry at the same moment
```

```python
import random
import time

def retry_with_backoff(fn, max_retries=4, base_delay=1.0, max_delay=60.0):
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as e:
            if attempt == max_retries:
                raise
            delay = min(base_delay * (2 ** attempt), max_delay)
            jitter = random.uniform(0, delay * 0.5)
            time.sleep(delay + jitter)
```

## Timeout Strategies

**Always set timeouts.** A request without a timeout can wait forever.

```
Timeout types:
───────────────

Connection timeout: time to establish TCP connection
  → 3–5 seconds (if server not responding at all)

Read timeout: time to wait for response data
  → depends on SLA of the downstream service

Total timeout: end-to-end time limit for entire request chain
  → must be < caller's own timeout

Cascading timeout budget:
────────────────────────
Client timeout:          30s
  API Gateway timeout:   25s
    Order Service:       20s
      Payment Service:   10s
        DB query:        5s

Each layer's timeout < parent's timeout
Prevents orphaned requests waiting after parent gave up
```

| Timeout Type | Typical Value | What Happens on Expiry |
|-------------|---------------|------------------------|
| Connection | 3–5s | TCP SYN dropped |
| Read | 5–30s | Socket closed, exception raised |
| Circuit Breaker open | 30–60s | HALF-OPEN probe begins |
| Retry max wait | 60–300s | Give up, surface error |

## Real Libraries

### Resilience4j (Java)

```java
CircuitBreakerConfig config = CircuitBreakerConfig.custom()
    .failureRateThreshold(50)          // 50% failure rate trips CB
    .waitDurationInOpenState(Duration.ofSeconds(30))
    .slidingWindowSize(20)
    .minimumNumberOfCalls(10)
    .permittedNumberOfCallsInHalfOpenState(5)
    .build();

CircuitBreaker cb = CircuitBreaker.of("payment", config);

// Decorate the call
Supplier<Payment> decorated = CircuitBreaker
    .decorateSupplier(cb, () -> paymentService.charge(amount));

// Execute with fallback
Try.ofSupplier(decorated)
    .recover(CallNotPermittedException.class, ex -> cachedFallback());
```

### Hystrix (Netflix — legacy, read-only)

```java
// Hystrix pioneered the pattern (now in maintenance mode)
public class PaymentCommand extends HystrixCommand<Payment> {
    @Override
    protected Payment run() {
        return paymentService.charge(amount);
    }

    @Override
    protected Payment getFallback() {
        return Payment.pending();  // graceful degradation
    }
}
```

### Polly (.NET)

```csharp
var circuitBreaker = Policy
    .Handle<HttpRequestException>()
    .CircuitBreakerAsync(
        exceptionsAllowedBeforeBreaking: 5,
        durationOfBreak: TimeSpan.FromSeconds(30),
        onBreak: (ex, ts) => Log.Warning("CB opened for {ts}", ts),
        onReset: () => Log.Info("CB reset"),
        onHalfOpen: () => Log.Info("CB half-open, probing...")
    );

var retryPolicy = Policy
    .Handle<HttpRequestException>()
    .WaitAndRetryAsync(3, attempt =>
        TimeSpan.FromSeconds(Math.Pow(2, attempt)));

// Combine retry + circuit breaker
var policy = Policy.WrapAsync(retryPolicy, circuitBreaker);
await policy.ExecuteAsync(() => httpClient.PostAsync("/charge", body));
```

## Fallback Strategies

When the circuit is OPEN, what should you return?

```
Option 1: Cached response
────────────────────────
  Return last known-good data (products, prices)
  ✅ User sees something
  ❌ May be stale

Option 2: Default / empty response
────────────────────────────────────
  Return empty list, zero count, "unavailable"
  ✅ Simple, always available
  ❌ Potentially confusing UX

Option 3: Queue for later
─────────────────────────
  Accept the request, process async when service recovers
  ✅ User action not lost
  ❌ Complex; only works for idempotent writes

Option 4: Graceful degradation
───────────────────────────────
  Show partial UI; disable affected feature
  ✅ Best user experience
  ❌ Requires frontend coordination
```

## Observability

Circuit breakers are useless if you cannot see their state:

```
Metrics to monitor:
────────────────────
cb.state           gauge   0=CLOSED, 1=OPEN, 2=HALF-OPEN
cb.calls.success   counter successful calls through CB
cb.calls.failed    counter failed calls through CB
cb.calls.rejected  counter calls rejected (CB OPEN)
cb.open.duration   histogram time spent in OPEN state

Alerts to set:
────────────────
CRITICAL: cb.state == OPEN for > 5 minutes
WARNING:  cb.calls.failed rate > 20% for 2 minutes
INFO:     cb.state transitions (CLOSED→OPEN, OPEN→CLOSED)
```

## Trade-offs Summary

| Pattern | Protects Against | Cost | When to Use |
|---------|-----------------|------|-------------|
| Circuit Breaker | Cascading failures | Medium complexity | All synchronous service calls |
| Bulkhead | Thread pool exhaustion | Memory overhead | Services with mixed criticality |
| Retry + Backoff | Transient failures | Increased latency | Idempotent operations |
| Timeout | Infinite wait | Lost requests | Every network call |
| Fallback | Unavailability | Feature degradation | User-facing features |

## Practice Exercise

**Design resilience for a checkout service**

```
Scenario:
- Checkout calls: Inventory, Payment, Notification, Analytics
- Payment: critical — must succeed or fail cleanly
- Notification: nice-to-have (email confirmation)
- Analytics: non-critical (tracking)
- Inventory: must check before payment

Design:
1. Which calls get circuit breakers?
2. What are the fallbacks?
3. What retry policy for Payment?
4. How do you size thread pools (bulkheads)?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Circuit breakers:
   ──────────────────
   All 4 calls get circuit breakers.
   Different thresholds:
     Payment:      threshold 20%, timeout 15s (low tolerance)
     Inventory:    threshold 30%, timeout 10s
     Notification: threshold 60%, timeout 5s (lenient)
     Analytics:    threshold 80%, timeout 2s (fire-and-forget)

2. Fallbacks:
   ───────────
   Payment:      no fallback — return error to user
   Inventory:    use last-known stock count (stale OK for 30s)
   Notification: queue email for retry later (SQS/Kafka)
   Analytics:    drop silently, log locally

3. Retry for Payment:
   ────────────────────
   Retries: 2 (not 3 — it's a payment, be careful)
   Backoff: 1s, 2s
   Jitter: ±500ms
   Idempotency key: required to prevent double-charge
   Do NOT retry on: 400 (bad request), 402 (insufficient funds)
   DO retry on: 503, 504, network timeout

4. Bulkhead sizing:
   ──────────────────
   Total threads: 200
   Payment:      60 threads (critical)
   Inventory:    50 threads (blocking)
   Notification: 40 threads (async-ish)
   Analytics:    20 threads (best-effort)
   Reserve:      30 threads (for other work)
```

</details>

## Interview Tips

- **Lead with the problem**: start by explaining cascading failures — interviewers want to see you understand the why
- **Draw the state machine**: CLOSED → OPEN → HALF-OPEN is a classic diagram to whiteboard
- **Mention Bulkhead as the companion pattern**: circuit breakers prevent cascading; bulkheads contain the blast radius
- **Be specific about configuration**: failure threshold, window size, open timeout — shows you've thought this through
- **Discuss fallbacks**: an open circuit breaker is only useful if there's a graceful degradation strategy
- **Name real libraries**: Resilience4j (Java), Polly (.NET), Hystrix (legacy context) — shows practical knowledge

## Summary

- **One slow service can kill everything** — cascading failures are the most common cause of large-scale outages
- **Circuit Breaker has 3 states**: CLOSED (normal), OPEN (fast-fail), HALF-OPEN (probing)
- **Bulkhead pattern** isolates thread pools — one failing service cannot exhaust shared resources
- **Retry with exponential backoff + jitter** prevents retry storms
- **Always set timeouts** — no timeout means you can wait forever
- **Fallbacks are required**: an open circuit is only useful if you have something to return

## Next Steps

Continue to [Real-Time Communication](../22-real-time/README.md) to learn about WebSockets, SSE, and scaling live connections.

---

**Key Takeaway**: Circuit breakers stop failure from spreading. Fail fast, recover safely, and always have a fallback.
