# API Gateway

## What Is an API Gateway?

```
Without an API Gateway:
────────────────────────
Each client must know the address of every service.
Each service must implement its own auth, rate limiting, logging.

Mobile App:
  GET https://user-service.internal:8001/users/123
  GET https://order-service.internal:8002/orders?user_id=123
  POST https://payment-service.internal:8003/payments
  ...

Problems:
❌ Client knows internal service topology (tight coupling)
❌ Each service re-implements auth, rate limiting, CORS, SSL
❌ Changing service addresses breaks clients
❌ Mobile app is chatty — 5 round trips to load one screen
❌ No single place to apply security policies
```

```
With an API Gateway:
─────────────────────
Clients talk to ONE address. Gateway handles the rest.

Mobile App:
  GET  https://api.example.com/users/123    → routed to User Service
  GET  https://api.example.com/orders       → routed to Order Service
  POST https://api.example.com/payments     → routed to Payment Service

API Gateway handles:
  ✅ Route to correct backend service
  ✅ Validate JWT / API keys (once, not per service)
  ✅ Rate limit by client
  ✅ SSL termination
  ✅ Log every request
  ✅ Cache GET responses
  ✅ Aggregate multiple service calls (BFF)
```

## API Gateway vs Load Balancer vs Reverse Proxy

```
These three are often confused. Each operates at a different level:

Reverse Proxy:
───────────────
Forwards requests to ONE type of backend.
"Forward all /api traffic to my app servers"
Handles: SSL termination, caching, compression
Does NOT handle: auth, routing to multiple different services

Examples: Nginx, HAProxy, Caddy

Load Balancer:
───────────────
Distributes requests across IDENTICAL instances of ONE service.
"Spread traffic across my 10 app server replicas"
Handles: health checks, algorithms (round-robin, least-conn)
Does NOT handle: auth, routing between different services

Examples: AWS ALB/NLB, Nginx upstream, HAProxy

API Gateway:
─────────────
Routes requests to DIFFERENT services based on the path/headers.
Application-layer intelligence.
"Route /users to User Service, /orders to Order Service"
Handles: auth, rate limiting, routing, transformation, BFF aggregation

Examples: AWS API Gateway, Kong, NGINX (configured as gateway), Traefik

Visual comparison:
──────────────────
                      ┌─────────────┐
Reverse Proxy:  App ──► Nginx/HAProxy──► [Same App Servers]
                      └─────────────┘

                      ┌─────────────┐
Load Balancer:  App ──►    ALB      ──► [Instance 1]
                      └─────────────┘  [Instance 2]
                                       [Instance 3]

                      ┌─────────────┐
API Gateway:    App ──►  Kong/APIGW ──► User Service
                      └─────────────┘  Order Service
                                       Payment Service
                                       (routing by path)
```

## API Gateway Architecture

```mermaid
graph TD
    Mobile["Mobile App\n(iOS/Android)"]
    Web["Web Browser\n(React/Vue)"]
    Third["Third-Party\nPartner API"]
    IoT["IoT Device"]

    GW["API Gateway\n─────────────────────────\n1. SSL Termination\n2. Auth (JWT / API Key)\n3. Rate Limiting\n4. Request Routing\n5. Request Transformation\n6. Response Caching\n7. Logging / Metrics\n8. Circuit Breaking"]

    US["User\nService\n:8001"]
    OS["Order\nService\n:8002"]
    PS["Payment\nService\n:8003"]
    NS["Notification\nService\n:8004"]
    SS["Search\nService\n:8005"]

    Mobile --> GW
    Web --> GW
    Third --> GW
    IoT --> GW

    GW -->|"GET /users/*"| US
    GW -->|"GET /orders\nPOST /orders"| OS
    GW -->|"POST /payments"| PS
    GW -->|"GET /notifications"| NS
    GW -->|"GET /search"| SS

    style GW fill:#7c3aed,stroke:#5b21b6,color:#fff
    style Mobile fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Web fill:#2563eb,stroke:#1d4ed8,color:#fff
    style Third fill:#2563eb,stroke:#1d4ed8,color:#fff
    style IoT fill:#2563eb,stroke:#1d4ed8,color:#fff
    style US fill:#374151,stroke:#1f2937,color:#fff
    style OS fill:#374151,stroke:#1f2937,color:#fff
    style PS fill:#374151,stroke:#1f2937,color:#fff
    style NS fill:#374151,stroke:#1f2937,color:#fff
    style SS fill:#374151,stroke:#1f2937,color:#fff
```

## Request Flow Through the Gateway

```mermaid
sequenceDiagram
    participant Client
    participant GW as API Gateway
    participant Auth as Auth Service
    participant OrderSvc as Order Service
    participant Cache as Response Cache

    Client->>GW: GET /orders/123\nAuthorization: Bearer jwt_token

    GW->>GW: 1. SSL Termination (HTTPS → HTTP)
    GW->>GW: 2. Rate limit check (100 req/min)

    GW->>Auth: Validate JWT
    Auth-->>GW: {user_id: 456, roles: [user]}

    GW->>Cache: Check cache for /orders/123
    Cache-->>GW: MISS

    GW->>OrderSvc: GET /orders/123\nX-User-Id: 456
    OrderSvc-->>GW: 200 OK {order data}

    GW->>Cache: Store response (TTL=60s)
    GW->>GW: Add response headers\n(X-Request-Id, X-RateLimit-Remaining)
    GW-->>Client: 200 OK {order data}
```

## Cross-Cutting Concerns

### Authentication and Authorization

```
The gateway handles auth ONCE for all services.
No service needs to re-implement JWT validation.

Gateway auth flow:
───────────────────
1. Client sends request with Authorization: Bearer <token>
2. Gateway validates JWT:
   - Check signature (using public key)
   - Check expiry (exp claim)
   - Check issuer (iss claim)
3. If valid: extract claims, add to request headers
   X-User-Id: 456
   X-User-Roles: admin,user
4. Forward to backend service
5. Backend trusts these headers (gateway already validated)

If invalid:
  Gateway returns 401 Unauthorized immediately.
  Backend service never receives the request.

API Key authentication:
────────────────────────
Third-party partners use API keys instead of JWT.
Gateway checks API key against key store (Redis or DB).
If valid: identify the partner, apply their rate limits.
```

### Rate Limiting

```
Without rate limiting:
───────────────────────
Malicious user sends 100,000 requests/second
→ Backend services overwhelmed → service down for all users

Rate limiting strategies:
──────────────────────────

1. Fixed Window
   100 requests per minute, reset at :00 of each minute
   Problem: burst at boundary (100 at :59, 100 at :00 = 200 in 2 sec)

2. Sliding Window
   Count requests in the last 60 seconds (rolling window)
   More accurate, prevents boundary bursts
   Cost: need to store per-request timestamps

3. Token Bucket
   Bucket holds N tokens. Refills at rate R tokens/sec.
   Each request consumes 1 token. Burst up to bucket size.
   ✅ Allows short bursts, smooth long-term average
   Used by: AWS, Twitter, Stripe

4. Leaky Bucket
   Queue of fixed size. Process at constant rate.
   ✅ Perfectly smooth outbound rate
   ❌ Adds latency for bursty traffic

Rate limit scopes:
───────────────────
Per IP:      100 req/min per IP address
Per user:    1000 req/min per authenticated user
Per API key: 10,000 req/min per API key (B2B)
Global:      50,000 req/min across all traffic

Rate limit response:
─────────────────────
HTTP 429 Too Many Requests
Retry-After: 30
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1709000000
```

### Request and Response Transformation

```
Gateway can modify requests before forwarding:
───────────────────────────────────────────────
Add headers:
  X-Request-Id: uuid4()          ← correlation ID for tracing
  X-Forwarded-For: client_ip     ← original client IP
  X-User-Id: 456                 ← from JWT claims

Rename paths:
  External: GET /api/v1/users/123
  Internal: GET /users/123
  (version your external API without changing internals)

Strip headers:
  Remove Authorization header before forwarding to service
  (service shouldn't re-validate, and shouldn't log the token)

Transform response:
  Wrap in standard envelope:
  { data: {order...}, meta: { request_id: "abc", version: "v1" } }

Protocol translation:
  External: REST/JSON
  Internal: gRPC/Protobuf
  Gateway translates between them
```

## BFF — Backend for Frontend

```
Problem: Different clients need different data shapes.
──────────────────────────────────────────────────────
Mobile app: screen space is small, needs minimal data, needs to batch calls
Web app:    screen is large, can make more requests, wants rich data
TV app:     different navigation, different data needs

Without BFF:
  One generic API tries to serve everyone.
  Mobile gets too much data (wastes battery/bandwidth).
  Web makes 6 round trips to assemble one screen.

With BFF pattern:
──────────────────
Each client type gets its own gateway/aggregator:

Mobile App  → Mobile BFF Gateway  → [User Svc, Order Svc, Product Svc]
Web App     → Web BFF Gateway     → [User Svc, Order Svc, Product Svc, Recommendation Svc]
TV App      → TV BFF Gateway      → [User Svc, Content Svc, Search Svc]

Each BFF:
- Fetches from multiple services
- Merges the results
- Trims data to what the client actually needs
- Returns in ONE round trip
```

```mermaid
graph TD
    Mobile["Mobile App"]
    Web["Web Browser"]
    TV["TV App"]

    MBFF["Mobile BFF\n• Compact responses\n• Batches 3 service calls\n• Offline-friendly"]
    WBFF["Web BFF\n• Rich responses\n• Server-side rendering data\n• Pagination"]
    TVBFF["TV BFF\n• Content-focused\n• Large media metadata\n• Recommendations"]

    US["User Service"]
    OS["Order Service"]
    PS["Product Service"]
    CS["Content Service"]
    RS["Recommendation Service"]

    Mobile --> MBFF
    Web --> WBFF
    TV --> TVBFF

    MBFF --> US
    MBFF --> OS
    MBFF --> PS

    WBFF --> US
    WBFF --> OS
    WBFF --> PS
    WBFF --> RS

    TVBFF --> US
    TVBFF --> CS
    TVBFF --> RS

    style MBFF fill:#7c3aed,stroke:#5b21b6,color:#fff
    style WBFF fill:#2563eb,stroke:#1d4ed8,color:#fff
    style TVBFF fill:#059669,stroke:#047857,color:#fff
    style US fill:#374151,stroke:#1f2937,color:#fff
    style OS fill:#374151,stroke:#1f2937,color:#fff
    style PS fill:#374151,stroke:#1f2937,color:#fff
    style CS fill:#374151,stroke:#1f2937,color:#fff
    style RS fill:#374151,stroke:#1f2937,color:#fff
```

## Real Products

### AWS API Gateway

```
AWS API Gateway features:
──────────────────────────
✅ Managed service (no infra to operate)
✅ REST and WebSocket APIs
✅ Lambda integration (routes → trigger Lambda functions)
✅ JWT authorizers / Cognito integration
✅ Throttling and quota management
✅ Usage plans (different limits per API key)
✅ Caching (TTL per endpoint)
✅ OpenAPI/Swagger import

Cost model: pay per request + data transfer
Best for: AWS-native apps, serverless architectures

Limitations:
❌ Vendor lock-in
❌ 29-second timeout limit
❌ Complex VPC integration
❌ Expensive at high volume vs self-hosted

Example routing config:
  GET /users/{id}     → Lambda: GetUserFunction
  POST /orders        → Lambda: CreateOrderFunction
  GET /products       → HTTP integration → Product Service URL
```

### Kong

```
Kong is an open-source API gateway built on NGINX + Lua.

Architecture:
──────────────
Kong (NGINX core) ← plugin system → upstream services
         │
   Kong Admin API  ← configure routes, plugins, consumers

Key plugins:
  key-auth        → API key authentication
  jwt             → JWT validation
  rate-limiting   → token bucket rate limiting
  proxy-cache     → response caching
  request-transformer → add/remove/rename headers
  zipkin          → distributed tracing
  prometheus      → metrics export
  openid-connect  → OAuth2/OIDC integration

Configuration example (declarative):
──────────────────────────────────────
services:
  - name: order-service
    url: http://order-service:8002

routes:
  - name: orders-route
    service: order-service
    paths: [/orders]
    methods: [GET, POST]

plugins:
  - name: jwt
    service: order-service
  - name: rate-limiting
    config:
      minute: 100
      policy: local
```

### NGINX as API Gateway

```nginx
# NGINX configured as API gateway

upstream user_service {
  server user-svc:8001;
  server user-svc-2:8001;
}

upstream order_service {
  server order-svc:8002;
}

server {
  listen 443 ssl;
  server_name api.example.com;

  ssl_certificate /etc/ssl/certs/example.crt;
  ssl_certificate_key /etc/ssl/private/example.key;

  # Rate limiting zone (10MB shared memory, 100 req/s per IP)
  limit_req_zone $binary_remote_addr zone=api:10m rate=100r/s;

  location /users/ {
    limit_req zone=api burst=20 nodelay;

    # Strip /users prefix, forward to service
    proxy_pass http://user_service/;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Request-Id $request_id;

    # JWT validation via auth_request
    auth_request /auth;
    auth_request_set $auth_user $upstream_http_x_user_id;
    proxy_set_header X-User-Id $auth_user;
  }

  location /orders/ {
    proxy_pass http://order_service/;
    proxy_set_header X-Request-Id $request_id;
    auth_request /auth;
  }

  # Internal JWT validation endpoint
  location = /auth {
    internal;
    proxy_pass http://auth-service/validate;
    proxy_pass_request_body off;
    proxy_set_header Content-Length "";
    proxy_set_header Authorization $http_authorization;
  }
}
```

### Traefik

```
Traefik is a cloud-native reverse proxy / gateway built for containers.

Key differentiator: Auto-discovery
  Traefik watches Docker/Kubernetes for new services.
  When a new service starts with the right labels → auto-configured.
  No manual config updates needed.

Docker Compose example:
──────────────────────────
version: '3'
services:
  traefik:
    image: traefik:v3
    command:
      - "--providers.docker=true"
      - "--entrypoints.web.address=:80"
      - "--entrypoints.websecure.address=:443"
    ports:
      - "80:80"
      - "443:443"

  order-service:
    image: order-service:latest
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.orders.rule=PathPrefix('/orders')"
      - "traefik.http.routers.orders.entrypoints=websecure"
      - "traefik.http.middlewares.orders-auth.forwardAuth.address=http://auth-svc/validate"
      - "traefik.http.routers.orders.middlewares=orders-auth"

Traefik advantages:
✅ No restart needed when adding services (auto-discovery)
✅ Let's Encrypt integration (auto SSL cert provisioning)
✅ Dashboard out of the box
✅ Kubernetes Ingress Controller support
```

## GraphQL Federation as API Gateway

```
Traditional REST gateway: routes paths to services.
GraphQL federation: exposes ONE unified GraphQL schema.

How federation works:
──────────────────────
Each service defines its own GraphQL subschema:

User Service subschema:
  type User { id: ID!, name: String!, email: String! }
  type Query { user(id: ID!): User }

Order Service subschema:
  type Order { id: ID!, total: Float!, user: User }
  extend type User @key(fields: "id") { orders: [Order] }

Federation gateway (Apollo Router):
  Combines subschemas into one unified schema.
  Client queries:
    query {
      user(id: "123") {       ← routes to User Service
        name
        orders {              ← routes to Order Service
          total
        }
      }
    }

  Gateway executes both queries, stitches response.

Pros:
✅ Client writes one query, gets exactly the data it needs
✅ No over-fetching, no under-fetching
✅ Strong typing (schema is the contract)
✅ Introspection (tools can query the schema)

Cons:
❌ GraphQL learning curve
❌ N+1 query problem (need DataLoader for batching)
❌ Complex caching (queries are POSTs, not cacheable by default)
❌ Overkill for simple APIs

Used by: GitHub, Shopify, Netflix
```

## Trade-offs Summary

| Concern | With API Gateway | Without |
|---|---|---|
| Auth implementation | Once in gateway | Once per service |
| Rate limiting | Centralized | Per service or none |
| Routing complexity | Centralized, manageable | Clients must know all services |
| Latency | Extra hop (+1-5ms) | Slightly less |
| Single point of failure | Yes (mitigate with HA) | Distributed failure modes |
| Client simplicity | Simple (one endpoint) | Complex (many endpoints) |
| Internal service discovery | Hidden from clients | Exposed to clients |
| Operational overhead | One gateway to manage | Cross-cutting logic everywhere |

## Gateway Anti-Patterns

```
❌ Don't put business logic in the gateway
   The gateway should route and apply policies.
   "Calculate discount based on user tier" belongs in a service.
   Putting business logic in the gateway creates a new monolith.

❌ Don't make the gateway a bottleneck
   All traffic flows through it.
   Deploy in HA (active-active, multiple instances behind LB).
   Horizontally scalable (stateless — rate limit state in Redis).

❌ Don't skip circuit breaking
   If Order Service is timing out, gateway should stop forwarding.
   Failing fast protects both the service and the client.
   Tools: Hystrix, Resilience4j, Envoy.

❌ Don't route service-to-service calls through the gateway
   Internal calls bypass the gateway.
   Gateway is for external (north-south) traffic.
   Service mesh (Istio, Linkerd) handles internal (east-west) traffic.
```

## Interview Tips

```
Common interview questions on API gateways:

Q: "What is an API gateway and why would you use one?"
A:
  ✅ Single entry point for all clients into a microservices backend
  ✅ Handles auth, rate limiting, routing, SSL, logging in one place
  ✅ Clients are decoupled from internal service topology
  ✅ Reduces duplicated cross-cutting logic across services

Q: "What's the difference between an API gateway and a load balancer?"
A:
  ✅ Load balancer: distributes traffic to identical instances of ONE service
  ✅ API gateway: routes to DIFFERENT services based on path/headers
  ✅ API gateway adds: auth, rate limiting, transformation, BFF aggregation
  ✅ In practice: often both (LB in front of the gateway instances)

Q: "What is the BFF pattern? When would you use it?"
A:
  ✅ Backend for Frontend: each client type gets its own gateway layer
  ✅ Each BFF aggregates calls to multiple services, returns tailored response
  ✅ Use when: mobile vs web have very different data needs
  ✅ Use when: chatty clients making too many round trips

Q: "How do you prevent the API gateway from being a single point of failure?"
A:
  ✅ Deploy multiple gateway instances (active-active)
  ✅ Put a load balancer in front of the gateway instances
  ✅ Gateway must be stateless (rate limit counters in Redis, not in-process)
  ✅ Health checks + auto-restart (Kubernetes, ECS)
  ✅ Circuit breaking to prevent cascading failures
```

## Practice Exercise

**Design an API gateway for a multi-platform e-commerce system**

```
Requirements:
- Clients: mobile app, web app, third-party seller API
- Services: User, Product, Order, Payment, Search (all separate)
- Auth: users login with JWT; partners use API keys
- Rate limits: 100 req/min for users, 10,000 req/min for partners
- Mobile app needs: user info + recent orders in ONE request
- Partners need access only to Product and Order endpoints

Questions:
1. How would you structure the routing rules?
2. How would you implement the BFF for mobile?
3. How would you enforce different rate limits per client type?
4. What happens if the Payment Service is down?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Routing rules:
   ──────────────
   /api/v1/users/*      → User Service       (auth: JWT required)
   /api/v1/products/*   → Product Service    (auth: JWT or API key)
   /api/v1/orders/*     → Order Service      (auth: JWT or API key)
   /api/v1/payments/*   → Payment Service    (auth: JWT required)
   /api/v1/search       → Search Service     (auth: optional)
   /api/v1/mobile/*     → Mobile BFF         (auth: JWT required)
   /partner/v1/*        → Partner gateway    (auth: API key required)

2. Mobile BFF:
   ──────────
   GET /api/v1/mobile/home
   Gateway/BFF:
     ① GET /users/{user_id}          (User Service)
     ② GET /orders?user_id={id}&limit=5  (Order Service)
     ③ GET /products/recommended?user_id={id}  (Product Service)
   All 3 in parallel → merge → one response to mobile
   Mobile gets one round trip instead of three.

3. Rate limits by client type:
   ──────────────────────────
   Detect client type from auth method:
   JWT → authenticated user → 100 req/min per user_id
   API key → partner → look up key's quota (10,000 req/min per key)
   No auth → anonymous → 20 req/min per IP
   Store counters in Redis (sliding window algorithm)

4. Payment Service down:
   ─────────────────────
   Circuit breaker: after 5 failures in 10s → open circuit
   Gateway returns 503 Service Unavailable immediately
   Retry-After: 30
   Client shows "Payment temporarily unavailable, please retry"
   After 30s → half-open: let 1 request through as probe
   If probe succeeds → close circuit, resume normal traffic
   Alert on-call engineer via PagerDuty
```

</details>

## Summary

- **API Gateway is the front door** — single entry point that decouples clients from internal services
- **Cross-cutting concerns belong in the gateway** — auth, rate limiting, SSL, logging handled once
- **BFF pattern** creates client-specific gateways that aggregate and tailor responses
- **Stateless gateway** is essential for high availability — store shared state in Redis
- **Don't put business logic in the gateway** — keep it as a routing and policy layer
- **Circuit breaking** at the gateway level prevents cascading failures from reaching all clients

## Next Steps

This concludes the core distributed systems concepts. Review the full index:
- [Sharding](../15-sharding/README.md) — splitting data across multiple databases
- [Replication](../16-replication/README.md) — copying data for availability and scale
- [Microservices](../17-microservices/README.md) — decomposing systems into independent services
- [Message Queues](../18-message-queues/README.md) — async communication and decoupling
- [API Gateway](../19-api-gateway/README.md) — the unified entry point for microservices

---

**Key Takeaway**: An API gateway is powerful infrastructure — but it can also become a bottleneck or a logic dumping ground. Keep it stateless, keep it focused on routing and policies, and deploy it in high-availability configuration.
