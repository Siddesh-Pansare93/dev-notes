import re
import glob


def remove_ascii_diagrams_after_mermaid(content):
    """
    Remove ASCII diagrams that appear immediately after Mermaid diagrams.
    Pattern: ```mermaid ... ``` followed by ``` ... ``` with ASCII art
    """
    # Pattern to match: Mermaid block followed by ASCII diagram block
    # We look for a mermaid block, then optionally whitespace/newlines, then a code block with ASCII characters
    pattern = r"(```mermaid\n.*?```)\n*\n*(```\n(?:[^\n]*[┌└├│→▼▲►◄]|[^\n]*↓|[^\n]*├|[^\n]*│|[^\n]*┌|[^\n]*└)[^\n]*\n(?:.*?\n)*?```)"

    def replacer(match):
        # Return just the Mermaid part, removing the ASCII part
        return match.group(1)

    # Apply the replacement
    new_content = re.sub(pattern, replacer, content, flags=re.DOTALL | re.MULTILINE)

    return new_content


def process_file(filepath):
    """Process a single file to remove ASCII diagrams after Mermaid."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        # Check if file has both Mermaid and ASCII
        has_mermaid = "```mermaid" in content
        has_ascii = bool(re.search(r"[┌└├│→]", content))

        if not (has_mermaid and has_ascii):
            return False, "No changes needed"

        new_content = remove_ascii_diagrams_after_mermaid(content)

        if new_content != content:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(new_content)
            return True, "Modified"
        else:
            return False, "No ASCII diagrams found after Mermaid"

    except Exception as e:
        return False, f"Error: {str(e)}"


# Process all files
modified_files = []
for pattern in [
    "python/**/*.md",
    "typescript/**/*.md",
    "postgresql/**/*.md",
    "system_design/**/*.md",
]:
    for file in glob.glob(pattern, recursive=True):
        modified, message = process_file(file)
        if modified:
            modified_files.append((file, message))

# Print results
print(f"Modified {len(modified_files)} files:")
for file, msg in modified_files:
    print(f"  - {file}: {msg}")
