# CAP Theorem

## What is the CAP Theorem?

The CAP Theorem (also called Brewer's Theorem) states that distributed systems can guarantee at most **two** of these three properties:

```mermaid
flowchart TB
    C["**Consistency (C)**<br/>All nodes see the same<br/>data at the same time"]
    A["**Availability (A)**<br/>Every request gets<br/>a response"]
    P["**Partition Tolerance (P)**<br/>System operates despite<br/>network failures"]

    CA["**CA** systems<br/>Single-node RDBMS<br/>PostgreSQL / MySQL<br/>(no distribution)"]
    CP["**CP** systems<br/>MongoDB / HBase<br/>Redis (cluster mode)<br/>Refuses requests when partitioned"]
    AP["**AP** systems<br/>DynamoDB / Cassandra<br/>CouchDB / DNS<br/>Returns stale data when partitioned"]

    C --- CA
    A --- CA
    C --- CP
    P --- CP
    A --- AP
    P --- AP

    Center["⚠️ Can't have all 3\nin a distributed system"]

    style C fill:#2563eb,color:#fff
    style A fill:#059669,color:#fff
    style P fill:#7c3aed,color:#fff
    style CA fill:#374151,color:#fff
    style CP fill:#374151,color:#fff
    style AP fill:#374151,color:#fff
    style Center fill:#ef4444,color:#fff
```

## Breaking Down CAP

### 1. Consistency (C)

**All nodes see the same data at the same time**

```
Example: Bank Account
─────────────────────

Your balance: $100

Account updated to $150

Consistent System:
──────────────────
You see $150 immediately everywhere
ATM sees $150
Online banking sees $150
Mobile app sees $150

Inconsistent System:
────────────────────
You see $150
ATM still shows $100
Online banking shows $150
(Inconsistent state across the system)
```

**Types of Consistency:**

```
Strong Consistency:
──────────────────
All nodes synchronized immediately
Example: Primary-replica with synchronous replication
Cost: Slower writes

Eventual Consistency:
────────────────────
Data becomes consistent "eventually"
Example: Asynchronous replication
Cost: Temporary inconsistency

Weak Consistency:
─────────────────
No guarantee of consistency
Example: Cache without cache invalidation
```

### 2. Availability (A)

**Every request receives a response (success or failure)**

```
Example: Website
────────────────

You make a request:
✅ Consistent system: Responds (might wait for sync)
✅ Available system: Always responds (might be stale)

❌ Unavailable system: Times out or refuses connection
```

**SLA Examples:**

```
99.9% availability (3 nines):
───────────────────────────────
- 8.76 hours downtime per year
- ~4 minutes per day

99.99% availability (4 nines):
───────────────────────────────
- 52.56 minutes downtime per year
- ~30 seconds per day

99.999% availability (5 nines):
────────────────────────────────
- 5.26 minutes downtime per year
- ~3 seconds per day
```

### 3. Partition (P)

**System continues to operate despite network failures**

```mermaid
flowchart LR
    subgraph Normal["✅ Normal Operation"]
        NA["Server A"] <-->|"network OK"| NB["Server B"]
    end

    subgraph Part["🔴 Network Partition"]
        PA["Server A\n(still running)"] -.-|"❌ disconnected"| PB["Server B\n(still running)"]
    end

    subgraph Choice["⚠️ Partition Tolerance: You must choose"]
        CP_["CP choice:\nRefuse requests\n(stay consistent)"]
        AP_["AP choice:\nReturn stale data\n(stay available)"]
    end

    Part --> Choice

    style PA fill:#ef4444,color:#fff
    style PB fill:#ef4444,color:#fff
    style CP_ fill:#2563eb,color:#fff
    style AP_ fill:#059669,color:#fff
```

## CAP Theorem Explained

**You must choose 2 of 3:**

### CA (Consistency + Availability)

**Sacrificing Partition Tolerance**

```
Properties:
───────────
✅ Strong consistency
✅ Always available
❌ Fails when network splits

When Network Partition Occurs:
──────────────────────────────
System goes down (unavailable)

Real-World Example:
──────────────────
Traditional relational databases (single node)
- PostgreSQL on single server
- MySQL on single server

Why Works:
──────────
- No network partition between nodes
- All data in one place
- ACID transactions guarantee consistency

Problem:
────────
- Single point of failure
- Can't survive node failure
- Not suitable for distributed systems
```

### CP (Consistency + Partition Tolerance)

**Sacrificing Availability**

```
Properties:
───────────
✅ Strong consistency
❌ May not be available
✅ Handles network partitions

When Network Partition Occurs:
──────────────────────────────
System blocks writes to maintain consistency
(Conservative approach)

Real-World Example:
──────────────────
HBase, MongoDB, PostgreSQL with replication

Example Scenario:
─────────────────
Database cluster with 2 nodes:

Node A ─── [Network Partition] ─── Node B

Client writes to Node A:
Node A tries to sync with Node B, but can't reach it.

CP System:
──────────
❌ Rejects write (maintains consistency)
✅ Data is consistent across cluster

Client writes to Node B:
Node B rejects write (not enough replicas)
```

### AP (Availability + Partition Tolerance)

**Sacrificing Consistency**

```
Properties:
───────────
❌ Weak consistency (eventual)
✅ Always available
✅ Handles network partitions

When Network Partition Occurs:
──────────────────────────────
Both sides continue operating
(Optimistic approach)

Real-World Example:
──────────────────
DynamoDB, Cassandra, Redis, Memcached

Example Scenario:
─────────────────
Distributed cache with 2 nodes:

Node A ─── [Network Partition] ─── Node B

User 1 writes to Node A:   data = "version 1"
User 2 writes to Node B:   data = "version 2"

AP System:
──────────
✅ Both writes succeed immediately
❌ Nodes have different data (inconsistent)
✅ When network heals, they merge (eventually consistent)
```

## Real-World CAP Decisions

### Example 1: E-commerce Checkout

```
Requirement: Accept payment reliably

Choice: CP (Consistency + Partition)

Reason:
───────
- Money is involved (consistency critical)
- Better to be unavailable than inconsistent
- Would rather "try again" than lose money

Implementation:
────────────────
- Use transactions with locks
- Synchronous replication
- Refuse writes during partition
- Database goes read-only if can't reach replicas

Real System: Amazon (uses CP approach)
```

### Example 2: Shopping Cart

```
Requirement: Users can always add items

Choice: AP (Availability + Partition)

Reason:
───────
- Must be available (user experience)
- Temporary inconsistency is acceptable
- Items can sync when network heals

Implementation:
────────────────
- No locks
- Asynchronous replication
- Both replicas accept writes
- Conflict resolution when syncing

Real System: Alibaba (carts across regions)
```

### Example 3: Social Media Feed

```
Requirement: Users see current posts quickly

Choice: AP (Availability + Partition)

Reason:
───────
- Availability more important than perfect consistency
- "Eventual consistency is fine"
- Users expect fast response, not perfect data

Implementation:
────────────────
- Cache with eventual sync
- Async replication across regions
- Can have stale data temporarily

Real System: Facebook, Twitter
```

### Example 4: Banking System

```
Requirement: Transactions must be consistent

Choice: CP (Consistency + Partition)

Reason:
───────
- Consistency is mandatory
- Must maintain ACID properties
- Better unavailable than inconsistent

Implementation:
────────────────
- Primary-backup replication (synchronous)
- Transactions locked until synced
- Fails over carefully

Real System: Banks, payment systems
```

## Network Partitions Always Happen

```
"You cannot assume that the network is reliable.
Therefore, partition tolerance is not optional.
You must choose between C and A."

— Eric Brewer, CAP Theorem creator

This means:
───────────
1. Network WILL fail eventually
2. You must choose CP or AP
3. Perfect CA is impossible in distributed systems
```

### Causes of Partitions

```
Common causes:
──────────────
- Server crashes
- Network cable cut
- Firewall misconfiguration
- BGP misconfiguration (ISP level)
- DNS failures
- Cloud provider failures
- Overloaded network causing timeout
- Software bugs in networking code
```

**Real Examples:**

```
GitHub (2018):
──────────────
- Database replication lag
- Consistency issues
- Users saw stale data
- Lessons: AP systems need careful design

Amazon S3 (2008):
──────────────────
- Network partition in data center
- Some servers separated
- Consistency violation
- Lessons: Even AP systems can fail

Facebook (2019):
─────────────────
- BGP misconfiguration
- Network unreachable
- Worldwide outage
- Partition tolerance is critical
```

## Handling Network Partitions

### Strategy 1: CP (Sacrifice Availability)

```
Quorum-based approach:
──────────────────────

Cluster of 3 nodes:

Write requires 2/3 quorum:
└─ Node A and B agree
└─ Node C might be down

Read requires 2/3 quorum:
└─ Ensures reading from updated node

During Partition:
─────────────────
Partition A: Has 2 nodes (can write)
Partition B: Has 1 node (can't write, no quorum)

Result:
───────
✅ Consistency guaranteed
❌ One partition unavailable
```

### Strategy 2: AP (Sacrifice Consistency)

```
Last-write-wins approach:
─────────────────────────

Database split into 2 partitions:

Partition A:
└─ Write: user.name = "Alice" (timestamp: 10:00)

Partition B:
└─ Write: user.name = "Bob" (timestamp: 10:02)

When Partitions Heal:
─────────────────────
Compare timestamps:
└─ Bob's write is newer (10:02 > 10:00)
└─ Keep Bob's value
└─ Discard Alice's value

Result:
───────
✅ Both partitions available
❌ Alice's write lost
```

## CAP in Practice

### Most Systems Are AP

```
Why?
────
- Availability is business critical
- Eventual consistency is acceptable
- Users tolerate temporary stale data

How to Use AP Safely?
─────────────────────
1. Accept eventual consistency
2. Use version vectors for conflicts
3. Implement conflict resolution
4. Document consistency guarantees
5. Design application knowing this
```

### Practical Examples

```
CP Systems (Consistency > Availability):
─────────────────────────────────────────
- HBase: Used for financial data
- MongoDB (w:majority): Replica majority writes
- Zookeeper: For distributed coordination
- etcd: Kubernetes configuration management

AP Systems (Availability > Consistency):
─────────────────────────────────────────
- DynamoDB: NoSQL designed for web scale
- Cassandra: Multi-region writes
- Redis: In-memory cache, eventual sync
- Memcached: Volatile, eventual consistency
- Riak: Distributed key-value store

Tunable Systems (Choose per operation):
───────────────────────────────────────
- Dynamo (Amazon's internal): Can choose consistency
- MongoDB: Configurable write concern
- Cassandra: Configurable consistency level
```

## PACELC Theorem (Extension of CAP)

The CAP theorem assumes a partition is happening. What about during normal operation?

```
If Partition then (C or A) else (Latency or Consistency)

Meaning:
────────
During normal operation (no partition):
- You must choose between Latency and Consistency

PC/EL: Strong consistency, higher latency
PA/EL: Available, lower latency
```

**Example:**

```
Using PostgreSQL Replication:

PC/EL (Partition: Consistency, Else: Latency):
──────────────────────────────────────────────
Write path:
1. Write to primary
2. Wait for all replicas to sync
3. Return to client
Result: Consistent but slow (high latency)

PA/EL (Partition: Availability, Else: Latency):
─────────────────────────────────────────────
Write path:
1. Write to primary
2. Return immediately to client
3. Replicate asynchronously
Result: Fast (low latency) but eventual consistency
```

## CAP Theorem Recap

```
Decision Matrix:

                What can you afford to lose?

System          Sacrifices          Trade-offs
──────────────────────────────────────────────
Banking         A (Availability)    CP
Shopping Cart   C (Consistency)     AP
Cache Layer     C (Consistency)     AP
Inventory       A (Availability)    CP
Comments        A (Availability)    AP
Notifications   C (Consistency)     AP
Payments        A (Availability)    CP

Key Rule:
─────────
In a distributed system with network partitions,
you MUST choose between:
- Consistency (strong) or
- Availability (always on)

You can't have both during a partition.
```

## Practice Exercise

**Choose CAP for These Systems**

1. **Email System**
   - Requirements?
   - CP or AP?
   - Why?

2. **Real-time Stock Ticker**
   - Requirements?
   - CP or AP?
   - Why?

3. **Social Media Likes Counter**
   - Requirements?
   - CP or AP?
   - Why?

4. **Healthcare Records**
   - Requirements?
   - CP or AP?
   - Why?

<details>
<summary>Solutions (Click to Expand)</summary>

```
1. Email System: AP (Availability > Consistency)
   ───────────────────────────────────────────
   - Must not lose emails
   - But can have eventual consistency
   - User expects to send/receive always

2. Real-time Stock Ticker: AP (Availability)
   ──────────────────────────────────────
   - Users need updates constantly
   - Slight delays acceptable
   - Stale prices OK (will update soon)

3. Social Media Likes: AP (Availability)
   ───────────────────────────────────
   - Users can always like/unlike
   - Exact count can be eventual
   - Consistency not critical

4. Healthcare Records: CP (Consistency)
   ────────────────────────────────────
   - Must be accurate (lives at stake)
   - Better unavailable than wrong
   - Regulatory compliance required
```

</details>

## Summary

- **CAP Theorem**: Choose 2 of 3 (Consistency, Availability, Partition)
- **Partitions are inevitable**: Must handle network failures
- **Most systems choose AP**: Availability is usually more important
- **Know your trade-offs**: Understand what consistency guarantees you have
- **Application matters**: Different parts may need different guarantees
- **Document clearly**: Users need to know what to expect

## Next Steps

Continue to [Consistency Patterns](../08-consistency/README.md) to learn how to implement consistency in distributed systems.

---

**Key Takeaway**: You can't have perfect consistency AND availability in a distributed system. Choose wisely based on your business needs.
