# Caching Strategies

## Why Caching?

```
Problem: Database is slow
─────────────────────────
Database read: 10ms
× 1M requests = 10,000 seconds!

Solution: Cache hot data
──────────────────────────
Cache read: 0.1ms
× 1M requests = 100 seconds!

Result: 100x faster!
```

## Cache Levels

```
CPU
 │ L1 Cache (32 KB): 1 cycle
 │ L2 Cache (256 KB): 4 cycles
 │ L3 Cache (8 MB): 12 cycles
 │
 RAM (8 GB): 200+ cycles
 │
 SSD (1 TB): 1,000,000+ cycles
 │
 Disk (10 TB): 10,000,000+ cycles

For Applications:
─────────────────
L1: In-memory cache (HashMap in process)
L2: Local cache (Redis on same server)
L3: Distributed cache (Redis cluster)
L4: Database (source of truth)
```

## Cache Types

### 1. Client-Side Cache (Browser)

```
HTTP Response:
──────────────
Cache-Control: max-age=3600
ETag: "33a64df551425fcc55e4d42a148795d9f25f89d4"

Browser stores response for 1 hour
├─ On next request for same URL:
│  ├─ First check local cache
│  ├─ If exists and not expired: Use cached
│  └─ If expired: Ask server

Pros:
✅ Fastest (stored locally)
✅ Reduces server load
✅ Works offline

Cons:
❌ Storage limited
❌ Data inconsistency possible
❌ Hard to invalidate
```

### 2. CDN Cache (Edge)

```
Content Delivery Network:
─────────────────────────
Origin Server (Tokyo)
      │
      └─ CDN Edge Server (New York)
         ├─ Caches static content
         ├─ Closest to user
         └─ Much faster

Example: Cloudflare, Akamai

Pros:
✅ Global distribution
✅ Reduced latency
✅ Offload origin server

Cons:
❌ Expensive
❌ Cache invalidation challenges
❌ Works best for static content
```

### 3. Application Cache

```
In-Process Memory Cache:
────────────────────────
Java HashMap: Fast but limited per server
Ruby @cache: Simple but no sharing

Distributed Cache:
──────────────────
Redis: Fast shared cache across servers
Memcached: Similar, slightly different

Example Usage:
──────────────
request → Application Server
         │
         ├─ Check Redis: get("user:123")
         │  ├─ Cache hit (50ms): Return cached
         │  ├─ Cache miss: Query database
         │  ├─ Store in Redis: set("user:123", data)
         │  └─ Return to client
```

### 4. Database Cache

```
Query Result Cache:
───────────────────
SELECT * FROM users WHERE id = 123
↓
Database caches result internally
↓
Next identical query: Much faster

Index Cache:
────────────
B-tree indexes in memory
Speeds up lookups

Write-Through Cache:
────────────────────
Data written to both cache and database
├─ Pros: Consistent
├─ Cons: Slower writes

Write-Behind Cache:
───────────────────
Data written to cache first, database later
├─ Pros: Fast writes
├─ Cons: Data loss if crash before flush
```

## Cache Policies

### Eviction Policies

**What to remove when cache is full?**

#### LRU (Least Recently Used)

```
Cache: [A, B, C, D] (capacity: 4)

Access pattern: A, B, C, D, A, B, E

A → [A]
B → [A, B]
C → [A, B, C]
D → [A, B, C, D]
A → [B, C, D, A] (A accessed, move to end)
B → [C, D, A, B] (B accessed, move to end)
E → [D, A, B, E] (Cache full, remove C - least recently used)

Pros:
✅ Good for most use cases
✅ Balances recency and frequency

Cons:
❌ Need to track access time
❌ One-time scans trash entire cache
```

#### LFU (Least Frequently Used)

```
Cache: [A(freq=5), B(freq=2), C(freq=3), D(freq=1)]

New item: E

Remove: D (freq=1, least frequent)

Pros:
✅ Good for popularity-based data
✅ Hot data stays longer

Cons:
❌ Tracks frequency overhead
❌ Can keep old popular items too long
```

#### FIFO (First In First Out)

```
Cache: [A, B, C, D] (capacity: 4)

Access: A, B, C, D, E

When E added (cache full):
├─ Remove A (first in)
├─ Result: [B, C, D, E]

Pros:
✅ Simple
✅ Fast

Cons:
❌ No concept of usage
❌ Doesn't adapt to access patterns
```

#### Random

```
When cache full:
├─ Remove random item

Pros:
✅ Very simple
✅ No overhead

Cons:
❌ Poor performance
❌ No adaptation
```

## Cache Invalidation Strategies

The hard part of caching!

### 1. Time-Based Invalidation (TTL)

```
Set expiry time:
─────────────────
set("user:123", data, ttl=3600)

After 3600 seconds:
├─ Cache entry expires
├─ Next request queries database
├─ Fresh data returned

Pros:
✅ Simple
✅ Automatic cleanup
✅ Works for most cases

Cons:
❌ Data might be stale
❌ Or expires too quickly
```

### 2. Event-Based Invalidation

```
When data changes:
──────────────────
User profile updated → DELETE cache "user:123"

Next request:
├─ Cache miss
├─ Query database (fresh data)
├─ Cache new value

Pros:
✅ Always consistent
✅ No stale data

Cons:
❌ Complex (need hooks everywhere)
❌ Risk of cache leaks (forget to invalidate)
```

### 3. Write-Through Pattern

```
Write to cache and database together:
─────────────────────────────────────
update_user(user_id, data):
  ├─ Update database
  ├─ Update cache
  └─ Return success

Pros:
✅ Consistent
✅ Simple

Cons:
❌ Both writes must succeed
❌ If one fails, cleanup complexity
```

### 4. Write-Behind (Write-Back) Pattern

```
Write to cache first, database later:
─────────────────────────────────────
update_user(user_id, data):
  ├─ Update cache (fast)
  ├─ Queue database update (async)
  └─ Return immediately

Background job:
  ├─ Read from queue
  ├─ Write to database
  └─ Verify success

Pros:
✅ Super fast (user sees response immediately)
✅ Handles burst writes well

Cons:
❌ Data loss if cache crashes before flush
❌ Complex to implement correctly
❌ Read-write ordering issues
```

## Cache Warming

**Pre-populate cache with hot data**

```
On startup or schedule:
───────────────────────
cache_warm():
  ├─ Query top 1000 products
  ├─ Query top 100 users
  ├─ Query latest 10000 posts
  └─ Store in cache

Result:
───────
✅ No cache misses for popular data
✅ Users see fast responses immediately
✅ Reduces database load

Challenges:
───────────
❌ What data to warm?
❌ When to warm?
❌ Memory usage
```

## Cache Stampede Problem

```
Popular item expires at exact time:
───────────────────────────────────
Item "product:123" is popular (100K requests/sec)
Expires at 10:00:00

At 10:00:00.001:
├─ 100 concurrent requests hit cache
├─ All get cache miss
├─ All query database simultaneously
├─ Database gets 10,000 requests at once
└─ Database crashes!

Solutions:
──────────

1. Staggered expiry:
   Add random offset (±10 seconds)
   ├─ Some expire at 9:59:55
   ├─ Some expire at 10:00:05
   └─ Spread load over time

2. Lazy refresh:
   When expired, 1 request queries database
   ├─ Others wait briefly for result
   ├─ Then all get refreshed data
   ├─ Called "single-threaded refresh"

3. Background refresh:
   Refresh before expiry:
   ├─ When cache has 30 seconds left
   ├─ Start background refresh
   ├─ Keep serving stale data
   ├─ New data replaces soon
```

## Cache Aside Pattern

```mermaid
sequenceDiagram
    participant Client
    participant App as Application
    participant Cache as Redis Cache
    participant DB as Database

    Client->>App: Request User Profile (ID: 123)
    
    App->>Cache: GET user:123
    
    alt Cache Hit
        Cache-->>App: Returns cached profile
        App-->>Client: Returns profile (Fast!)
    else Cache Miss
        Cache-->>App: Returns null
        App->>DB: SELECT * FROM users WHERE id=123
        DB-->>App: Returns data
        App->>Cache: SET user:123 data (TTL: 1hr)
        App-->>Client: Returns profile (Slower)
    end
```

Pros:
✅ Simple
✅ Only cached data that's actually used

Cons:
❌ Cache miss on first request (slower)
❌ Risk of cache leaks if not careful
❌ Cache invalidation needed on updates

Most common pattern for web applications
```

## Redis: Popular Cache Solution

```
In-Memory Data Store:
──────────────────────
✅ Fast: Sub-millisecond latency
✅ Flexible: Supports many data types
✅ Persistent: Optional persistence
✅ Cluster-able: Can shard across servers

Data Types:
───────────
String:  set mykey "value"
List:    lpush mylist "item"
Set:     sadd myset "member"
Hash:    hset myhash field value
Sorted Set: zadd myzset 1 "member"

Example Cache Usage:
────────────────────
# Cache user profile
SET user:123 '{"name": "John", "email": "john@example.com"}' EX 3600

# Cache search result
LPUSH search:nodejs result1 result2 result3
EXPIRE search:nodejs 300

# Leaderboard
ZADD leaderboard 1000 user1 2000 user2 3000 user3
ZREVRANGE leaderboard 0 10  # Top 10

Costs:
──────
Self-managed: $0 + infrastructure
AWS ElastiCache: $15-100/month
```

## Caching Best Practices

```
Do:
───
✅ Cache expensive computations
✅ Use appropriate TTL
✅ Monitor cache hit rate
✅ Warm cache on startup
✅ Plan cache invalidation
✅ Use Redis/Memcached for distributed cache

Don't:
──────
❌ Cache small, cheap queries
❌ Cache user sessions naively (use Redis)
❌ Ignore cache invalidation
❌ Use browser cache for sensitive data
❌ Cache database errors
❌ Make cache the source of truth
```

## Metrics to Track

```
Cache Hit Ratio:
────────────────
hit_ratio = cache_hits / (cache_hits + cache_misses)

Good targets:
├─ L1 (CPU): 95%+
├─ L2 (Memory): 90%+
├─ L3 (Distributed): 80%+
└─ If below target: Increase cache or adjust TTL

Other metrics:
──────────────
- Eviction rate: How often items removed
- Memory usage: How full is cache
- Response time: User-facing latency
- Database load: Is cache helping?
```

## Practice Exercise

**Design Cache for E-commerce Product Catalog**

Scenario:
```
- 100,000 products
- 10,000 products viewed per hour
- Hot products: 0.1% get 80% of traffic
- Product prices change frequently
- Product descriptions rarely change
- 50,000 concurrent users

Questions:
1. What should you cache?
2. TTL values?
3. Invalidation strategy?
4. Cache size?
5. Expected hit rate?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. What to cache:
   ──────────────
   ✅ Product descriptions (TTL: 1 day)
   ✅ Images (TTL: 1 week, via CDN)
   ✅ Popular product lists (TTL: 1 hour)
   ❌ Product prices (change frequently, TTL: 5 min)
   ❌ User cart (cache-aside only)

2. TTL Values:
   ────────────
   Product details: 3600 seconds (1 hour)
   Category pages: 600 seconds (10 min)
   Search results: 300 seconds (5 min)
   Prices: 300 seconds (5 min)
   Images: 86400 seconds (1 day, via CDN)

3. Invalidation:
   ──────────────
   On price update:
   ├─ Invalidate cache key "product:123:price"
   ├─ Invalidate all search caches
   ├─ Invalidate category caches

   On description update:
   ├─ Invalidate cache key "product:123:details"
   ├─ Keep images cached

4. Cache Size:
   ───────────
   Hot products: 0.1% × 100K = 100 products
   ├─ Product data: 10 KB × 100 = 1 MB
   ├─ Images: 500 KB × 100 = 50 MB (on CDN)
   ├─ Total: ~100 MB (very manageable)

   Recommended: 1-2 GB Redis cluster
   ├─ All hot products
   ├─ Search results
   ├─ Category pages
   ├─ Some headroom

5. Expected Hit Rate:
   ──────────────────
   Products: 80% of views = hot products
   ├─ Hit rate: 90%+

   Search: Popular searches repeat
   ├─ Hit rate: 85%+

   Categories: Most users browse categories
   ├─ Hit rate: 95%+

   Overall: ~90% hit rate
```

</details>

## Summary

- **Caching dramatically improves performance**: 100x+ speedups possible
- **TTL is your friend**: Simple and effective invalidation
- **Cache aside pattern is most common**: Lazy loading into cache
- **Watch out for cache stampede**: Use staggered expiry or single-threaded refresh
- **Monitor hit rates**: Tells you if cache is working
- **Redis is the standard**: For distributed caching

## Next Steps

Continue to [CDN (Content Delivery Networks)](../12-cdn/README.md) to learn about geographic caching.

---

**Key Takeaway**: Caching is essential for performance, but invalidation is the hardest problem. Plan carefully.
