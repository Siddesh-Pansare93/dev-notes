# Case Study: Design Netflix

## Scale and Context

```
Netflix by the numbers (2024):
───────────────────────────────
Subscribers:      260+ million globally
Streaming traffic: ~15% of global internet bandwidth
Content library:  17,000+ titles
Daily streams:    250+ million hours of content watched
Microservices:    1,000+ services
CDN nodes:        Open Connect Appliances in 1,000+ locations
Engineers:        12,000+
Uptime target:    99.99%
```

## Functional Requirements

```
Core features to design:
─────────────────────────
1. Browse catalog
   ├─ Display titles with thumbnails
   ├─ Search by title, genre, actor
   └─ Personalized homepage (recommendations)

2. Stream video
   ├─ Start playing a title
   ├─ Adaptive bitrate: adjust quality to network speed
   └─ Smooth playback with minimal buffering

3. Continue watching
   ├─ Resume from last position across devices
   └─ Watch history

Non-functional requirements:
─────────────────────────────
├─ Latency: video starts within 2 seconds
├─ Availability: 99.99% (52 minutes downtime/year)
├─ Scalability: handle 250M concurrent streams at peak
├─ Consistency: eventual OK (resume position can lag a few seconds)
└─ Global: serve 190+ countries
```

## High-Level Architecture

```
Client Devices (TV, Phone, Browser)
          │
          ▼
   ┌─────────────────┐
   │   Zuul API      │  ← API Gateway (auth, routing, rate limiting)
   │   Gateway       │
   └────────┬────────┘
            │
    ┌───────┼────────────────────────────────┐
    ▼       ▼                ▼               ▼
 Account  Metadata        Streaming       Recommendations
 Service  Service         Service         Service
    │       │                │               │
    ▼       ▼                ▼               ▼
 Users   Cassandra       CDN / Open      ML Models
  DB      (titles,       Connect         (offline)
          episodes)      Appliances

Separate systems for:
  ├─ Video storage & encoding (S3 + Transcoding Pipeline)
  ├─ CDN (Open Connect)
  └─ Data platform (Kafka → Spark → analytics)
```

## Video Storage and Encoding Pipeline

### Upload to Encode

```
Content team uploads a raw master file:
  ├─ Resolution: 4K (3840×2160), 10-bit HDR
  ├─ File size: 100GB+ for a 2-hour movie

Netflix must produce dozens of variants:
  ├─ Resolutions: 360p, 480p, 720p, 1080p, 4K
  ├─ Codecs: H.264, H.265/HEVC, AV1
  ├─ Bitrates: 0.5 Mbps → 25 Mbps
  ├─ Audio: 5.1 surround, stereo, mono, 12 languages
  └─ Subtitles: 50+ languages

Result: 1 movie = 1,200+ encoded files stored in S3
```

### Encoding Pipeline

```mermaid
flowchart TD
    UPLOAD[Raw Master\n100GB .mov] --> S3RAW[(S3\nRaw Storage)]
    S3RAW --> INGEST[Ingest Service\nValidation + Metadata]
    INGEST --> QUEUE[Encoding Queue\nKafka]
    QUEUE --> EW1[Encoding Worker 1\n4K H.265]
    QUEUE --> EW2[Encoding Worker 2\n1080p H.264]
    QUEUE --> EW3[Encoding Worker 3\n720p AV1]
    QUEUE --> EWN[Encoding Worker N\n... 1200 variants]
    EW1 --> S3ENC[(S3\nEncoded Storage)]
    EW2 --> S3ENC
    EW3 --> S3ENC
    EWN --> S3ENC
    S3ENC --> VALID[Quality Validation\nAutomated + Human]
    VALID -->|approved| CDN[Open Connect CDN\nPush to edge nodes]
    VALID -->|rejected| ALERT[Alert: Re-encode]

    style UPLOAD fill:#374151,color:#fff
    style S3RAW fill:#2563eb,color:#fff
    style INGEST fill:#7c3aed,color:#fff
    style QUEUE fill:#2563eb,color:#fff
    style EW1 fill:#7c3aed,color:#fff
    style EW2 fill:#7c3aed,color:#fff
    style EW3 fill:#7c3aed,color:#fff
    style EWN fill:#7c3aed,color:#fff
    style S3ENC fill:#2563eb,color:#fff
    style VALID fill:#f59e0b,color:#fff
    style CDN fill:#059669,color:#fff
    style ALERT fill:#ef4444,color:#fff
```

## CDN: Open Connect

```
Netflix built its own CDN — "Open Connect Appliances" (OCA)

Why build your own CDN?
├─ Saves $1B+/year in CDN costs vs. using Akamai/Cloudflare
├─ More control over cache policies
└─ ISP partnerships: OCAs placed inside ISP data centers

How it works:
─────────────
1. Netflix places OCAs (dedicated servers with 100TB+ SSD)
   inside ISP data centers worldwide

2. Off-peak hours (2AM–5AM): Netflix proactively pushes
   popular content to OCAs near users

3. User presses play:
   ├─ Steering service finds nearest OCA
   ├─ If OCA has the file: stream directly from OCA
   └─ If not: fallback to S3 origin

Result:
├─ 95%+ of traffic served from OCAs (not S3)
├─ Last-mile latency: <10ms (OCA is inside user's ISP)
└─ Massive S3 egress cost savings
```

## Streaming: Adaptive Bitrate (ABR)

```
Problem:
  ├─ User on fiber: can handle 25 Mbps (4K HDR)
  ├─ User on mobile: can handle 2 Mbps (720p)
  ├─ User on train: bandwidth fluctuates constantly

Solution: MPEG-DASH (Dynamic Adaptive Streaming over HTTP)

MPEG-DASH:
───────────
Each video is segmented into 4-second chunks.
A manifest file (.mpd) lists all available representations.

Manifest:
  <Representation bandwidth="500000"  height="360"  codec="avc1" />
  <Representation bandwidth="1500000" height="720"  codec="avc1" />
  <Representation bandwidth="4000000" height="1080" codec="avc1" />
  <Representation bandwidth="16000000" height="2160" codec="hvc1" />

ABR Algorithm (client-side):
  1. Download first segment at lowest quality (fast start)
  2. Measure actual throughput
  3. Predict available bandwidth for next segment
  4. Select highest quality segment that fits in buffer
  5. Repeat for every 4-second chunk

Buffer management:
  ├─ Target: 30 seconds ahead in buffer
  ├─ If buffer < 5s: drop to lowest quality immediately
  └─ If buffer > 30s: try to upgrade quality
```

### Video Delivery Pipeline

```mermaid
flowchart LR
    CLIENT[Client Player\nTV / Phone / Browser] -->|1. Request manifest| STEER[Steering Service\nFind nearest OCA]
    STEER -->|2. Return OCA IP| CLIENT
    CLIENT -->|3. Fetch .mpd manifest| OCA[Open Connect\nAppliance OCA]
    OCA -->|4. Return manifest| CLIENT
    CLIENT -->|5. Select quality| ABR[ABR Algorithm\nIn-device]
    ABR -->|6. Fetch 4s chunk at chosen bitrate| OCA
    OCA -->|chunk| CLIENT
    CLIENT -->|7. Decode & play| SCREEN[Display]
    OCA -->|cache miss| S3[(S3\nOrigin)]
    S3 -->|fill cache| OCA

    style CLIENT fill:#374151,color:#fff
    style STEER fill:#7c3aed,color:#fff
    style OCA fill:#2563eb,color:#fff
    style ABR fill:#7c3aed,color:#fff
    style SCREEN fill:#059669,color:#fff
    style S3 fill:#2563eb,color:#fff
```

## Microservice Architecture

### Key Services

```
Zuul (API Gateway):
  ├─ Routes all incoming requests
  ├─ Authentication / authorization
  ├─ Rate limiting
  └─ A/B testing header injection

Eureka (Service Discovery):
  ├─ Services register themselves on startup
  ├─ Services query Eureka for other service locations
  └─ Handles auto-scaling (new instances register automatically)

Hystrix (Circuit Breaker):
  ├─ Wraps all inter-service calls
  ├─ Opens circuit if failure rate > threshold
  └─ Fallback: serve stale data or default response
     (e.g., if recommendations fail → show "Popular on Netflix")

EVCache (Distributed Cache):
  ├─ Netflix's in-house Memcached layer
  ├─ Replicated across availability zones
  └─ Caches: user preferences, title metadata, playback state
```

### Microservice Architecture Diagram

```mermaid
flowchart TD
    CLIENT[Client Apps\niOS / Android / TV / Web] --> ZUUL[Zuul\nAPI Gateway]
    ZUUL --> ACCOUNT[Account\nService]
    ZUUL --> META[Metadata\nService]
    ZUUL --> PLAY[Playback\nService]
    ZUUL --> REC[Recommendation\nService]

    ACCOUNT --> EVCACHE[EVCache\nMemcached]
    META --> CASS[(Cassandra\nTitle Metadata)]
    PLAY --> STEER[Steering\nService CDN]
    REC --> MLSTORE[(Offline ML\nModel Store)]

    ZUUL --> EUREKA[Eureka\nService Discovery]
    ACCOUNT <-.->|circuit\nbreaker| HYSTRIX[Hystrix]
    META <-.->|circuit\nbreaker| HYSTRIX
    PLAY <-.->|circuit\nbreaker| HYSTRIX

    STEER --> OCA[Open Connect\nCDN Nodes]

    style CLIENT fill:#374151,color:#fff
    style ZUUL fill:#7c3aed,color:#fff
    style EUREKA fill:#7c3aed,color:#fff
    style HYSTRIX fill:#f59e0b,color:#fff
    style ACCOUNT fill:#2563eb,color:#fff
    style META fill:#2563eb,color:#fff
    style PLAY fill:#2563eb,color:#fff
    style REC fill:#2563eb,color:#fff
    style EVCACHE fill:#059669,color:#fff
    style CASS fill:#374151,color:#fff
    style MLSTORE fill:#374151,color:#fff
    style STEER fill:#059669,color:#fff
    style OCA fill:#059669,color:#fff
```

## Recommendation System

```
Netflix's "North Star" metric: time spent watching
Recommendations drive ~80% of content discovered

How it works:
─────────────
1. Data collection (real-time):
   ├─ What you watched
   ├─ How long you watched it
   ├─ Did you pause, rewind, abandon?
   ├─ Time of day, device type
   └─ What you searched but didn't watch

2. Offline ML training (batch, nightly):
   ├─ Collaborative filtering:
   │   "Users similar to you also liked..."
   ├─ Content-based filtering:
   │   "You liked Sci-Fi thrillers, here are more"
   └─ Matrix factorization (embedding-based)

3. Serving (real-time, < 20ms):
   ├─ Pre-computed recommendation lists in EVCache
   ├─ Re-rank for context (time of day, device, recent activity)
   └─ A/B test different algorithms continuously

Thumbnail optimization:
  ├─ Same movie, 20+ different thumbnail images
  ├─ Netflix selects different thumbnails per user
  └─ A/B tested: right thumbnail → 30% more clicks
```

## Chaos Engineering

```
Netflix Chaos Monkey (2010, origin of Chaos Engineering):

The problem:
  "We can't know if our system is resilient until production breaks."
  Traditional testing doesn't catch distributed system failures.

Solution: randomly terminate production instances during work hours

Chaos Tools ("Simian Army"):
  Chaos Monkey   → terminates random EC2 instances
  Chaos Gorilla  → kills an entire Availability Zone
  Latency Monkey → injects artificial latency
  Conformity Monkey → checks services violate best practices
  Security Monkey → checks for security policy violations

What it forces:
  ├─ No single points of failure
  ├─ All services must handle dependency failures gracefully
  ├─ Fallbacks must be tested, not theoretical
  └─ "Failure is normal" culture

Result:
  Netflix is more resilient than most because they
  continuously prove it in production, not just in tests.

Modern adoption:
  ├─ GameDays: planned chaos experiments
  ├─ Chaos Engineering tools: Gremlin, Litmus, Chaos Mesh
  └─ AWS Fault Injection Simulator (FIS)
```

## Data Storage Choices

```
User accounts / billing:
  MySQL (ACID transactions)

Video metadata (titles, descriptions, cast):
  Cassandra (distributed, low-latency reads, 100M+ rows)

User watch history / resume points:
  Cassandra (high write volume, eventual consistency OK)

Session / playback state:
  EVCache (Memcached, low-latency reads)

Search:
  Elasticsearch (full-text, faceted filtering)

Analytics / data pipeline:
  Kafka → Apache Spark → Amazon S3 (data lake)
  Druid for real-time analytics dashboards

ML feature store:
  S3 (offline) + Redis (online, low-latency serving)
```

## Handling Scale: Key Decisions

```
1. Stateless services:
   All services are stateless → horizontal scaling is trivial
   State lives in Cassandra, EVCache, not in service memory

2. Regionalized architecture:
   AWS regions: us-east-1, eu-west-1, ap-southeast-1
   Each region is independent; traffic routed by geo-DNS
   A region failure doesn't take down other regions

3. Graceful degradation:
   If recommendations fail → show "Popular titles"
   If metadata slow → show cached stale titles
   If playback service down → show "unavailable" message
   Never show a white error page

4. Async everywhere:
   User presses play → immediate response
   Analytics, billing, "continue watching" update → async queue
   Only the critical path is synchronous

5. Pre-computation:
   Recommendations computed offline, stored in cache
   Thumbnails pre-rendered for likely viewers
   CDN populated during off-peak hours
```

## Interview: Design Questions

**Q: How do you handle a user resuming their show on a different device?**

```
Resume position stored in Cassandra:
  Key: (userId, titleId)
  Value: { positionMs, deviceId, timestamp }

On play:
  1. Fetch resume position from Cassandra via Playback Service
  2. If found: send seek command to player at position
  3. Player requests chunks starting from that timestamp

Write-back strategy:
  ├─ Client sends playback heartbeat every 10 seconds
  ├─ Heartbeat written to Kafka first (high throughput)
  └─ Kafka consumer writes to Cassandra (async)

Consistency tradeoff:
  ├─ Eventual: resume point may lag by ~10 seconds
  └─ Acceptable: user won't notice 10 second difference
```

**Q: What happens when a CDN node is overloaded?**

```
Steering service tracks OCA health in real time:
  ├─ If OCA connection rate > threshold: redirect to next closest OCA
  ├─ Multiple OCAs in same city / ISP for redundancy
  └─ Fallback path: serve from S3 origin (slower but works)
```

## Summary

- **Encoding pipeline**: one raw file → 1,200+ variants; S3 for storage, Kafka for encoding job queue
- **Open Connect CDN**: Netflix's own CDN inside ISPs, proactively filled with popular content off-peak
- **MPEG-DASH + ABR**: video split into 4-second chunks; client adapts quality every chunk based on bandwidth
- **Microservices**: Zuul (gateway), Eureka (discovery), Hystrix (circuit breaker), EVCache (distributed cache)
- **Cassandra**: powers metadata and user watch history at global scale (eventual consistency is acceptable)
- **Recommendations**: offline ML (collaborative filtering) + online re-ranking, A/B tested thumbnails
- **Chaos Monkey**: randomly kills production instances to prove resilience and build a culture of reliability
- **Graceful degradation**: every service has a fallback; never a hard failure to the user

## Next Steps

Continue to [Design Uber](../28-design-uber/README.md) to see how real-time geospatial systems are architected.

---

**Key Takeaway**: Netflix's architecture is built around stateless services, aggressive caching at the edge, and the assumption that any component can fail at any time. Resilience is continuously proven in production, not assumed.
