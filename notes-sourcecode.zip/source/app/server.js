const express = require('express');
const path = require('path');

// Configuration
const { PORT } = require('./config');

// Services
const { initializeNavigation } = require('./services/navigation');
const { buildSearchIndex } = require('./services/search');

// Routes
const { getLandingPage } = require('./routes/landing');
const { searchAPI } = require('./routes/search');
const { getContent } = require('./routes/content');

// Initialize Express app
const app = express();

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use('/static', express.static(path.join(__dirname, 'public')));

// Build navigation tree and search index on startup
const { navTree, flatFiles } = initializeNavigation();
buildSearchIndex(flatFiles);

// Routes
app.get('/', getLandingPage(navTree));
app.get('/api/search', searchAPI);
app.get('/*', getContent(navTree, flatFiles));

// Start server (local development)
if (process.env.NODE_ENV !== 'production') {
  app.listen(PORT, () => {
    console.log(`Tutorial viewer running at http://localhost:${PORT}`);
  });
}

// Export for Vercel serverless
module.exports = app;
