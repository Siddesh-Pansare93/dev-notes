# Event-Driven Architecture

## What Is Event-Driven Architecture?

```
Traditional (Request/Response):
────────────────────────────────
Service A  →  Service B  →  Service C
           wait            wait
           ← response      ← response

Problems:
├─ Tight coupling: A must know B's address
├─ Synchronous: A waits for B to finish
└─ Brittle: if B is down, A fails

Event-Driven:
─────────────
Service A → Event Bus → Service B
                      → Service C
                      → Service D

Benefits:
├─ Loose coupling: A just emits events
├─ Asynchronous: A doesn't wait
└─ Resilient: B can be down, catches up later
```

## Events vs Commands vs Queries

```
Three communication patterns:
──────────────────────────────

EVENT:
  "Something happened" (past tense, immutable fact)
  ├─ OrderPlaced, UserRegistered, PaymentFailed
  ├─ Publisher doesn't care who listens
  ├─ One-to-many (broadcast)
  └─ Example: "order.placed" { orderId, amount, time }

COMMAND:
  "Do something" (imperative, directed)
  ├─ PlaceOrder, SendEmail, ChargeCard
  ├─ Sent to specific recipient
  ├─ One-to-one (targeted)
  └─ Expects exactly one handler

QUERY:
  "Give me data" (request/response)
  ├─ GetOrderById, ListUserOrders
  ├─ Read-only, no side effects
  ├─ One-to-one (synchronous)
  └─ Returns a result immediately

Rule of thumb:
──────────────
Events  → "notify that X happened"
Commands → "tell a service to do X"
Queries  → "ask a service about X"
```

## Event Sourcing

### Storing Events as the Source of Truth

```
Traditional Approach (State Stored):
──────────────────────────────────────
users table:
id  | name  | balance | status
123 | Alice | $150    | active

Problem:
├─ We only know current state
├─ No history: how did balance reach $150?
└─ Can't replay or audit

Event Sourcing Approach (Events Stored):
─────────────────────────────────────────
events table:
seq | aggregate_id | event_type          | data
 1  | user:123     | UserRegistered      | {name: "Alice"}
 2  | user:123     | MoneyDeposited      | {amount: 200}
 3  | user:123     | MoneyWithdrawn      | {amount: 100}
 4  | user:123     | MoneyDeposited      | {amount: 50}

Current state = replay all events:
  start: balance = 0
  → UserRegistered      balance = 0
  → MoneyDeposited $200 balance = 200
  → MoneyWithdrawn $100 balance = 100
  → MoneyDeposited $50  balance = 150  ← current!

Benefits:
✅ Full audit trail (who changed what, when, why)
✅ Time travel: replay to any point in time
✅ Bug recovery: replay events with a bug fix applied
✅ Analytics: derive any view from raw events

Drawbacks:
❌ Query complexity: must rebuild state to read
❌ Storage: events accumulate forever
❌ Eventual consistency: rebuilding takes time
❌ Schema evolution: changing event structure is hard
```

### Snapshots: Performance Optimization

```
Problem: replaying 1 million events is slow!

Snapshot Solution:
──────────────────
Every N events, save a snapshot of current state:

events table:
seq | aggregate_id | event_type      | data
 1  | order:99     | OrderCreated    | {...}
...
500 | order:99     | ItemAdded       | {...}
[SNAPSHOT saved at seq=500: state = {...}]
501 | order:99     | AddressUpdated  | {...}
502 | order:99     | OrderShipped    | {...}

To rebuild current state:
1. Load latest snapshot (seq 500)
2. Replay only events AFTER seq 500 (just 2 events!)
3. Result: O(snapshot_gap) instead of O(all events)

Snapshot frequency:
├─ Every 100 events: low overhead
├─ Every 1000 events: moderate
└─ Time-based (hourly): predictable latency
```

### Event Sourcing Diagram

```mermaid
flowchart TD
    CMD[Command\nPlaceOrder] -->|validated| AGG[Order Aggregate]
    AGG -->|emit| E1[OrderCreated\nevent]
    AGG -->|emit| E2[PaymentPending\nevent]
    E1 --> ES[(Event Store)]
    E2 --> ES
    ES -->|publish| EB[Event Bus]
    EB --> P1[Projection:\nOrder Read Model]
    EB --> P2[Projection:\nAnalytics]
    EB --> P3[Projection:\nNotification Service]
    ES -->|replay| REBUILD[Rebuild State\nfor any point-in-time]

    style CMD fill:#7c3aed,color:#fff
    style AGG fill:#7c3aed,color:#fff
    style ES fill:#2563eb,color:#fff
    style EB fill:#2563eb,color:#fff
    style P1 fill:#059669,color:#fff
    style P2 fill:#059669,color:#fff
    style P3 fill:#059669,color:#fff
    style REBUILD fill:#f59e0b,color:#fff
    style E1 fill:#374151,color:#fff
    style E2 fill:#374151,color:#fff
```

## CQRS: Command Query Responsibility Segregation

```
The Core Idea:
──────────────
Separate your read model from your write model.

Traditional (Single Model):
─────────────────────────────
                  ┌────────────────┐
Read/Write ──────►│  Users Service │──► Database
                  └────────────────┘

Problem: Optimizing reads hurts write performance and vice versa

CQRS (Two Models):
───────────────────
Commands (writes)         Queries (reads)
PlaceOrder ─────────►  Write Model        Read Model  ◄──── GetOrderSummary
CancelOrder ─────────►  (normalized)  →→→  (denormalized) ◄── ListUserOrders
                         (ACID)            (fast reads)
                         ↕ relational DB   ↕ read-optimized store
                         Postgres          Elasticsearch / Redis

Write Model:
├─ Handles commands
├─ Validates business rules
├─ Emits domain events
└─ Normalized: no redundancy

Read Model (Projection):
├─ Handles queries
├─ Denormalized: precomputed joins
├─ No business logic
└─ Can have multiple projections (different shapes)
```

### CQRS Read/Write Split

```mermaid
flowchart LR
    subgraph WRITE ["Write Side"]
        CMD[Command\nHandler] --> BL[Business\nLogic]
        BL --> WDB[(Write DB\nPostgreSQL)]
        BL --> EVT[Domain\nEvents]
    end

    subgraph SYNC ["Sync Layer"]
        EVT --> EB[Event Bus\nKafka]
    end

    subgraph READ ["Read Side"]
        EB --> PROJ1[Projector:\nOrder View]
        EB --> PROJ2[Projector:\nDashboard]
        PROJ1 --> RDB1[(Read Store\nRedis)]
        PROJ2 --> RDB2[(Read Store\nElasticsearch)]
    end

    CLIENT[Client] -->|command| CMD
    CLIENT -->|query| QH[Query Handler]
    QH --> RDB1
    QH --> RDB2

    style CMD fill:#7c3aed,color:#fff
    style BL fill:#7c3aed,color:#fff
    style CLIENT fill:#374151,color:#fff
    style EVT fill:#2563eb,color:#fff
    style EB fill:#2563eb,color:#fff
    style PROJ1 fill:#059669,color:#fff
    style PROJ2 fill:#059669,color:#fff
    style QH fill:#059669,color:#fff
    style WDB fill:#374151,color:#fff
    style RDB1 fill:#374151,color:#fff
    style RDB2 fill:#374151,color:#fff
```

### When to Use CQRS

```
Good fit:
✅ Read/write traffic is very different (e.g., 100:1 reads to writes)
✅ Read model needs different shape from write model
✅ Combined with Event Sourcing
✅ Multiple read projections needed (mobile app, analytics, web)

Bad fit:
❌ Simple CRUD with balanced read/write
❌ Small teams (operational overhead is high)
❌ Strong consistency required everywhere
❌ Simple domain with few business rules
```

## Event Streaming vs Message Queues

```
Message Queue (e.g., RabbitMQ, SQS):
──────────────────────────────────────
Producer → [Queue] → Consumer
               │
               └── Message deleted after consumed

Properties:
├─ Point-to-point or pub/sub
├─ Message deleted after acknowledgment
├─ Good for task distribution / work queues
├─ Typically short retention (hours/days)
└─ Designed for: process this one task once

Example use: send email, resize image, process payment

Event Stream (e.g., Kafka, Kinesis):
──────────────────────────────────────
Producer → [Topic Log] → Consumer Group A
                       → Consumer Group B
                       → Consumer Group C

Properties:
├─ Log-based: events appended, never deleted
├─ Multiple independent consumers at different offsets
├─ Long retention (days, weeks, forever)
├─ Replay: consumer can re-read from any point
└─ Designed for: broadcast this event to many subscribers

Example use: audit logs, analytics, event sourcing

Comparison:
───────────
Feature           | RabbitMQ      | Kafka
──────────────────┼───────────────┼──────────────
Model             | Queue         | Log
Message retention | Deleted       | Configurable
Multiple consumers| Fan-out       | Independent
Ordering          | Per queue     | Per partition
Throughput        | ~50K msg/s    | ~1M msg/s
Replay            | No            | Yes
Best for          | Task queues   | Event streams
```

## Saga Pattern: Distributed Transactions

```
Problem: How to keep data consistent across services?

Example: Order placement requires:
  1. Reserve inventory (Inventory Service)
  2. Charge customer (Payment Service)
  3. Create shipment (Shipping Service)

Can't use a single ACID transaction across services!

Solution: Saga = sequence of local transactions
          with compensating transactions on failure
```

### Choreography Saga

```
Each service reacts to events and emits new events.
No central coordinator.

Happy path:
───────────
Order Service    → emits: OrderCreated
                          ↓
Inventory Service → reserves stock → emits: StockReserved
                                             ↓
Payment Service  → charges card → emits: PaymentSucceeded
                                         ↓
Shipping Service → creates shipment → emits: ShipmentCreated ✅

Failure path (payment fails):
──────────────────────────────
Order Service    → emits: OrderCreated
                          ↓
Inventory Service → reserves stock → emits: StockReserved
                                             ↓
Payment Service  → charge fails → emits: PaymentFailed
                                         ↓
Inventory Service → hears PaymentFailed → releases stock ↩️ (compensate)
Order Service    → hears PaymentFailed → cancels order ↩️ (compensate)
```

### Orchestration Saga

```
A central Saga Orchestrator directs each step.

Happy path:
───────────
Orchestrator → PlaceOrder command → Inventory Service
             ← StockReserved
Orchestrator → ChargeCard command → Payment Service
             ← PaymentSucceeded
Orchestrator → CreateShipment command → Shipping Service
             ← ShipmentCreated
Orchestrator: saga complete ✅

Failure path (payment fails):
──────────────────────────────
Orchestrator → ChargeCard command → Payment Service
             ← PaymentFailed
Orchestrator → ReleaseStock command → Inventory Service (compensate)
             ← StockReleased
Orchestrator → CancelOrder command → Order Service (compensate)
             ← OrderCancelled ✅
```

### Choreography vs Orchestration

```
Choreography:
✅ Fully decoupled: services don't know about each other
✅ No single point of failure
❌ Hard to follow the flow: "what happens when X?"
❌ Debugging is difficult (distributed event chain)
❌ Risk of circular events

Orchestration:
✅ Clear flow: one place defines the whole saga
✅ Easier to debug and monitor
✅ Handles complex compensation logic cleanly
❌ Orchestrator becomes a coupling point
❌ Orchestrator must be highly available
```

### Saga Choreography Sequence

```mermaid
sequenceDiagram
    participant OS as Order Service
    participant EB as Event Bus
    participant IS as Inventory Service
    participant PS as Payment Service
    participant SS as Shipping Service

    OS->>EB: OrderCreated {orderId, items, amount}
    EB->>IS: OrderCreated event
    IS->>IS: Reserve stock
    IS->>EB: StockReserved {orderId}
    EB->>PS: StockReserved event
    PS->>PS: Charge card

    alt Payment succeeds
        PS->>EB: PaymentSucceeded {orderId}
        EB->>SS: PaymentSucceeded event
        SS->>SS: Create shipment
        SS->>EB: ShipmentCreated {orderId, trackingId}
        Note over OS,SS: Order complete ✅
    else Payment fails
        PS->>EB: PaymentFailed {orderId, reason}
        EB->>IS: PaymentFailed event
        IS->>IS: Release stock (compensate)
        IS->>EB: StockReleased {orderId}
        EB->>OS: PaymentFailed event
        OS->>OS: Cancel order (compensate)
        Note over OS,SS: Order cancelled ❌
    end
```

## Outbox Pattern: Reliable Event Publishing

```
Problem: Dual-write failure
────────────────────────────
update database → ✅ success
publish event  → ❌ CRASH!

Result: DB updated but downstream services never notified!
This causes data inconsistency.

Naive solution: publish first, then write
publish event  → ✅ success
update database → ❌ CRASH!

Result: Event published but DB not updated!
Still inconsistent!

Outbox Pattern Solution:
─────────────────────────
Step 1: Write to DB and outbox table in ONE transaction

BEGIN TRANSACTION;
  UPDATE orders SET status = 'placed' WHERE id = 99;
  INSERT INTO outbox (event_type, payload, published)
    VALUES ('OrderPlaced', '{...}', false);
COMMIT;  ← Atomic! Both succeed or both fail.

Step 2: A relay process polls outbox and publishes events

outbox_relay:
  LOOP:
    rows = SELECT * FROM outbox WHERE published = false
    FOR row IN rows:
      publish(row.event_type, row.payload) → Kafka
      UPDATE outbox SET published = true WHERE id = row.id
    SLEEP 100ms
```

### Outbox Pattern Flow

```
Outbox Table:
─────────────
id | aggregate_id | event_type   | payload  | published | created_at
 1 | order:99     | OrderPlaced  | {...}    | false     | 10:00:01
 2 | order:99     | OrderPaid    | {...}    | false     | 10:00:05

Relay reads unpublished rows:
  → Publishes to Kafka
  → Marks as published=true

Guarantees:
✅ At-least-once delivery (retry on crash)
✅ No dual-write inconsistency
✅ Transactional consistency between DB write and event

Caveats:
⚠️  Consumers must be idempotent (may receive duplicates)
⚠️  Slight delay in event delivery (poll interval)
⚠️  Outbox table needs cleanup of old rows
```

## Real Example: Order Processing System

```
Actors:
  - Customer places order on web frontend
  - Order Service, Inventory Service, Payment Service, Notification Service

Architecture:
─────────────
                     ┌──────────────────────────────────────────┐
                     │            Kafka Event Bus               │
                     └──────────────────────────────────────────┘
                          ▲        ▲        ▲         ▲
                     emit │    emit│    emit│      emit│
                          │        │        │          │
         ┌────────────────┤  ┌─────┤  ┌────┤  ┌───────┤
         │ Order Service  │  │ Inv │  │Pay │  │ Ship  │
         │ (+ outbox)     │  │ Svc │  │Svc │  │ Svc   │
         └────────────────┘  └─────┘  └────┘  └───────┘

Event flow:
───────────
1. Customer POSTs /orders → Order Service
2. Order Service:
   BEGIN TRANSACTION
     INSERT orders (status=pending)
     INSERT outbox (OrderCreated)
   COMMIT
3. Outbox relay → publishes OrderCreated to Kafka

4. Inventory Service subscribes to OrderCreated
   → Reserves stock
   → Publishes StockReserved

5. Payment Service subscribes to StockReserved
   → Charges card via Stripe
   → Publishes PaymentSucceeded

6. Order Service subscribes to PaymentSucceeded
   → Updates order status = confirmed
   → Publishes OrderConfirmed

7. Notification Service subscribes to OrderConfirmed
   → Sends confirmation email

8. Shipping Service subscribes to OrderConfirmed
   → Creates shipment record

Entire flow is async, decoupled, and resilient!
Any service can be restarted without losing events.
```

## Summary

- **Events** are immutable facts; commands tell a service to act; queries ask for data
- **Event Sourcing** stores events as the source of truth — state is rebuilt by replaying events
- **CQRS** separates the write model (commands) from the read model (queries), allowing each to be optimized independently
- **Kafka** is best for event streaming (log-based, replayable, high throughput); **RabbitMQ** is best for task queues (point-to-point, message deleted after processing)
- **Sagas** manage distributed transactions using local transactions + compensating actions
- **Choreography** is decoupled but hard to trace; **orchestration** is explicit but creates a coordinator dependency
- **Outbox pattern** solves the dual-write problem: write to DB and outbox in one transaction, relay publishes events asynchronously

## Next Steps

Continue to [Monitoring & Observability](../26-monitoring/README.md) to learn how to observe and debug distributed systems.

---

**Key Takeaway**: Event-driven architecture enables loose coupling and resilience at the cost of eventual consistency and debugging complexity. Start with simpler patterns (queues, outbox) before adopting full event sourcing.
