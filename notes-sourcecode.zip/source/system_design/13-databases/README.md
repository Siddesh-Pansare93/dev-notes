# Databases Deep Dive

## Why Database Internals Matter

```
Problem: Your app is slow
──────────────────────────
SELECT * FROM orders WHERE user_id = 123 → 4 seconds

Why?
────
- Table has 50 million rows
- No index on user_id
- Database scans every row (full table scan)

After adding index:
───────────────────
Same query → 2ms

Understanding internals helps you:
✅ Write faster queries
✅ Choose the right indexes
✅ Pick the right database for the job
✅ Diagnose performance bottlenecks
```

## ACID Properties Explained

**The four guarantees of a reliable database transaction:**

```
BEGIN;
  UPDATE accounts SET balance = balance - 100 WHERE id = 1;
  UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT;
```

### Atomicity

```
Definition: All operations in a transaction succeed, or none do.
────────────────────────────────────────────────────────────────

Scenario: Transfer $100 from Alice to Bob
Step 1: Deduct $100 from Alice  ✅
Step 2: Add $100 to Bob         ❌ (crash!)

Without atomicity: Alice lost $100, Bob got nothing.
With atomicity: Both operations roll back. Money preserved.

Implementation: Write-Ahead Log (WAL)
  - Every change written to log BEFORE data pages
  - On crash, replay log to undo incomplete transactions
  - "undo log" tracks what to reverse
```

### Consistency

```
Definition: Transaction moves database from one valid state to another.
────────────────────────────────────────────────────────────────────────
Constraints, foreign keys, and check constraints are always satisfied.

Example constraints:
  - account.balance >= 0       (check constraint)
  - order.user_id must exist   (foreign key)
  - email is UNIQUE            (unique constraint)

If a transaction would violate any constraint:
  → Transaction is rejected and rolled back
  → Database stays in valid state
```

### Isolation

```
Definition: Concurrent transactions don't interfere with each other.
────────────────────────────────────────────────────────────────────

Isolation Levels (weakest to strongest):
──────────────────────────────────────────

READ UNCOMMITTED:
  Can read data from uncommitted transactions.
  Risk: Dirty reads (reading data that gets rolled back).
  Rarely used.

READ COMMITTED (PostgreSQL default):
  Only read committed data.
  Prevents dirty reads.
  Risk: Non-repeatable reads (same query returns different rows
        if another transaction commits between your two reads).

REPEATABLE READ (MySQL default):
  Rows read in a transaction don't change until commit.
  Prevents dirty reads and non-repeatable reads.
  Risk: Phantom reads (new rows can appear from INSERT by others).

SERIALIZABLE (strongest):
  Transactions execute as if they ran one at a time.
  No anomalies possible.
  Cost: Lowest throughput, most locks held.
```

### Durability

```
Definition: Committed transactions survive crashes.
────────────────────────────────────────────────────

Mechanism:
──────────
1. Transaction commits
2. WAL record flushed to disk (fsync)
3. "Commit confirmed" returned to client
4. Data pages updated in background

If server crashes after step 2 but before step 4:
  → On restart, replay WAL → data is recovered ✅

If server crashes before step 2:
  → Transaction not committed → rolled back ✅

Cost: fsync is the bottleneck for write throughput.
      Group commit (batch multiple transactions into one fsync)
      is used to improve throughput.
```

## Storage Engines

### B-Tree (PostgreSQL, MySQL InnoDB)

**The standard for read-heavy OLTP workloads**

```mermaid
flowchart TB
    Root["Root Node<br/>[50 | 75]<br/>#7c3aed background"]
    L1["Internal Node<br/>[25 | 37]"]
    L2["Internal Node<br/>[60 | 68]"]
    L3["Internal Node<br/>[80 | 90]"]

    Leaf1["Leaf: [10,15,20]<br/>→ row data"]
    Leaf2["Leaf: [25,30,35]<br/>→ row data"]
    Leaf3["Leaf: [37,40,45]<br/>→ row data"]
    Leaf4["Leaf: [50,55,58]<br/>→ row data"]
    Leaf5["Leaf: [60,65,67]<br/>→ row data"]
    Leaf6["Leaf: [75,77,79]<br/>→ row data"]

    Root --> L1
    Root --> L2
    Root --> L3
    L1 --> Leaf1
    L1 --> Leaf2
    L1 --> Leaf3
    L2 --> Leaf4
    L2 --> Leaf5
    L3 --> Leaf6

    style Root fill:#7c3aed,color:#fff
    style L1 fill:#2563eb,color:#fff
    style L2 fill:#2563eb,color:#fff
    style L3 fill:#2563eb,color:#fff
    style Leaf1 fill:#374151,color:#fff
    style Leaf2 fill:#374151,color:#fff
    style Leaf3 fill:#374151,color:#fff
    style Leaf4 fill:#374151,color:#fff
    style Leaf5 fill:#374151,color:#fff
    style Leaf6 fill:#374151,color:#fff
```


### LSM-Tree (Cassandra, RocksDB, LevelDB)

**Optimized for write-heavy workloads**

```mermaid
flowchart TD
    W["Incoming Writes"]

    subgraph Memory["In-Memory (Fast)"]
        WAL2["Write-Ahead Log<br/>(disk, for durability)"]
        MEM["MemTable<br/>(sorted in-memory)"]
    end

    subgraph Disk["On Disk (Sorted String Tables)"]
        L0["Level 0 SSTables<br/>(recently flushed)"]
        L1["Level 1 SSTables<br/>(compacted)"]
        L2["Level 2 SSTables<br/>(larger, compacted)"]
    end

    W --> WAL2
    W --> MEM
    MEM -->|"flush when full"| L0
    L0 -->|"compaction"| L1
    L1 -->|"compaction"| L2

    style W fill:#7c3aed,color:#fff
    style WAL2 fill:#f59e0b,color:#fff
    style MEM fill:#059669,color:#fff
    style L0 fill:#2563eb,color:#fff
    style L1 fill:#2563eb,color:#fff
    style L2 fill:#2563eb,color:#fff
```

```
LSM-Tree Characteristics:
──────────────────────────
Write path:
  1. Append to WAL (sequential disk write, fast)
  2. Insert into MemTable (sorted in-memory structure)
  3. When MemTable full, flush to immutable SSTable on disk
  4. Background compaction merges SSTables

Why writes are fast:
  No random disk seeks — always append to log or flush sequentially.
  Sequential I/O is 100× faster than random I/O on HDDs.
  Even on SSDs, sequential writes are more efficient.

Read path (slower):
  1. Check MemTable (latest writes)
  2. Check each SSTable from newest to oldest
  3. Use Bloom filters to skip SSTables that can't have the key
  4. Merge results

Compaction:
  Background process merges overlapping SSTables.
  Removes deleted keys (tombstones).
  Keeps read performance acceptable.
  Causes "write amplification" — data written multiple times.

Used by: Cassandra, HBase, LevelDB, RocksDB, ScyllaDB
```

### B-Tree vs LSM-Tree Comparison

| Property | B-Tree | LSM-Tree |
|---|---|---|
| **Write performance** | Moderate (random I/O) | Excellent (sequential I/O) |
| **Read performance** | Excellent (O(log n)) | Moderate (multiple SSTables) |
| **Range queries** | Excellent | Good |
| **Space amplification** | Low (in-place updates) | High (multiple copies during compaction) |
| **Write amplification** | Low | High (compaction rewrites data) |
| **Best for** | OLTP, read-heavy | Write-heavy, time-series, event logging |

## Row-Oriented vs Column-Oriented Storage

### Row-Oriented (OLTP)

```
Table: orders
───────────────────────────────────────
id  | user_id | amount | status  | date
────┼─────────┼────────┼─────────┼──────────
1   | 101     | 29.99  | shipped | 2024-01-01
2   | 102     | 149.00 | pending | 2024-01-02
3   | 101     | 9.99   | shipped | 2024-01-03

On disk (row-oriented):
  [1, 101, 29.99, 'shipped', '2024-01-01'][2, 102, 149.00, 'pending', '2024-01-02']...

Query: SELECT * FROM orders WHERE id = 1
  → Read one page, find row 1, return all columns ✅ Fast!

Query: SELECT SUM(amount) FROM orders
  → Must read EVERY row to get the amount column ❌ Slow for analytics!
```

### Column-Oriented (OLAP)

```
On disk (column-oriented):
  id column:      [1][2][3][4][5]...
  user_id column: [101][102][101][103][102]...
  amount column:  [29.99][149.00][9.99][89.50][199.00]...
  status column:  [shipped][pending][shipped][shipped][pending]...

Query: SELECT SUM(amount) FROM orders
  → Read only the amount column file ✅ 4× less data read!
  → Column data compresses extremely well (same type, similar values)
  → SIMD CPU instructions can process many values at once ✅

Query: SELECT * FROM orders WHERE id = 1
  → Must read all column files and reconstruct the row ❌ Slower!
```

```
Use column-oriented when:
──────────────────────────
✅ Aggregations: SUM, AVG, MAX over millions of rows
✅ Analytics queries: Read a few columns, many rows
✅ Data warehouses, BI tools, dashboards

Use row-oriented when:
──────────────────────
✅ OLTP: Frequent reads/writes of individual rows
✅ CRUD operations
✅ Point queries: "fetch user 123's full profile"

Examples:
──────────
Row-oriented:  PostgreSQL, MySQL, SQLite
Column-oriented: BigQuery, Redshift, ClickHouse, Parquet files
Hybrid:        DuckDB (column for analytics, row for OLTP)
```

## Indexes

**Indexes trade storage and write overhead for faster reads.**

### B-Tree Index

```sql
-- Without index
EXPLAIN SELECT * FROM users WHERE email = 'alice@example.com';
-- Seq Scan on users (cost=0.00..2500.00 rows=1)
-- Scans all 100,000 rows!

-- Create index
CREATE INDEX idx_users_email ON users (email);

-- With index
EXPLAIN SELECT * FROM users WHERE email = 'alice@example.com';
-- Index Scan on idx_users_email (cost=0.29..8.31 rows=1)
-- Looks up 1 row directly!
```

### Hash Index

```
Structure: Hash table mapping key → row location

hash(email) → bucket → row pointer

Pros:
✅ O(1) exact match lookups (faster than B-tree for point lookups)

Cons:
❌ Cannot do range queries (no ordering)
❌ Not crash-safe in all implementations

Used for: Exact equality lookups only
PostgreSQL: Hash indexes supported but rarely preferred over B-tree
```

### Composite Index

```sql
-- Query pattern: filter by user_id AND status
SELECT * FROM orders WHERE user_id = 101 AND status = 'shipped';

-- Good composite index (column order matters!)
CREATE INDEX idx_orders_user_status ON orders (user_id, status);

-- Index stores rows sorted by (user_id, status):
-- (101, 'pending'), (101, 'shipped'), (101, 'shipped'),
-- (102, 'delivered'), (102, 'pending'), ...

-- This query uses the index ✅
SELECT * FROM orders WHERE user_id = 101 AND status = 'shipped';

-- This ALSO uses the index (leftmost prefix rule) ✅
SELECT * FROM orders WHERE user_id = 101;

-- This does NOT use the composite index ❌
-- (Can't use index without the leading column)
SELECT * FROM orders WHERE status = 'shipped';
```

### Covering Index

```sql
-- Query only needs columns: user_id, amount, status
SELECT user_id, amount, status FROM orders WHERE user_id = 101;

-- Covering index includes all needed columns
CREATE INDEX idx_orders_covering ON orders (user_id, amount, status);

-- Database can answer query from index alone — never touches the table!
-- Called "index-only scan" in PostgreSQL
-- Massive performance boost for frequently run queries
```

### When NOT to Index

```
❌ Low-cardinality columns:
   CREATE INDEX ON users (is_active);  -- only 2 values (true/false)
   50% of rows are true — faster to scan than use index!
   Rule of thumb: index useful when < 10-15% of rows match.

❌ Small tables:
   Tables with < 1000 rows are faster with full scan than index lookup.

❌ Write-heavy columns:
   Each INSERT/UPDATE/DELETE must also update all indexes.
   Table with 10 indexes: every write updates 11 structures.
   Benchmark before adding indexes to high-write tables.
```

## Query Execution Pipeline

```mermaid
flowchart TD
    SQL["SQL Query<br/>SELECT * FROM orders WHERE user_id = 101"]

    Parse["1. Parser<br/>Validate syntax<br/>Build parse tree"]
    Analyze["2. Analyzer<br/>Resolve table/column names<br/>Check permissions"]
    Plan["3. Query Planner / Optimizer<br/>Generate candidate execution plans<br/>Estimate costs using statistics"]
    BestPlan["4. Select Best Plan<br/>Index scan vs seq scan<br/>Join order optimization"]
    Execute["5. Executor<br/>Fetch pages from buffer pool<br/>Apply filters, joins, sorts"]
    Result["6. Return Results<br/>to client"]

    SQL --> Parse
    Parse --> Analyze
    Analyze --> Plan
    Plan --> BestPlan
    BestPlan --> Execute
    Execute --> Result

    style SQL fill:#7c3aed,color:#fff
    style Parse fill:#2563eb,color:#fff
    style Analyze fill:#2563eb,color:#fff
    style Plan fill:#f59e0b,color:#fff
    style BestPlan fill:#059669,color:#fff
    style Execute fill:#059669,color:#fff
    style Result fill:#374151,color:#fff
```

### Query Planner / Optimizer

```
The optimizer is the most critical part of the database.
It chooses HOW to execute your query.

Inputs to optimizer:
────────────────────
- Table row counts (from ANALYZE / VACUUM)
- Column cardinality statistics (histogram of values)
- Available indexes
- Join order possibilities (for multi-table queries)

What it decides:
────────────────
- Seq Scan: Read entire table (good for small tables or many rows match)
- Index Scan: Use B-tree index (good for selective queries)
- Index Only Scan: Use covering index (never touches table)
- Bitmap Heap Scan: Use index to collect row locations, then fetch pages
- Hash Join vs Nested Loop vs Merge Join: for joining tables

Reading EXPLAIN ANALYZE:
─────────────────────────
EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 101;

Index Scan using idx_orders_user on orders
  (cost=0.56..16.58 rows=5 width=72)
  (actual time=0.042..0.088 rows=4 loops=1)
  Index Cond: (user_id = 101)

  cost=X..Y : estimated startup cost .. total cost
  actual time: measured milliseconds
  rows: how many rows were actually returned
```

## Connection Pooling

```
Problem: Database connections are expensive
────────────────────────────────────────────
Each connection:
- TCP handshake: ~1ms
- TLS handshake: ~5ms
- PostgreSQL auth: ~5ms
- Memory per connection: ~5-10MB

10,000 web requests/sec × 1 connection each = 10,000 connections
PostgreSQL recommended max: 100-300 connections
Result: Database overwhelmed! ❌

Solution: Connection pool
──────────────────────────
Pool of persistent connections, shared across application threads.
App borrows a connection, uses it, returns it to pool.
```

```mermaid
flowchart LR
    subgraph AppServers["Application Servers"]
        AS1["App Server 1<br/>(50 threads)"]
        AS2["App Server 2<br/>(50 threads)"]
        AS3["App Server 3<br/>(50 threads)"]
    end

    subgraph Pool["PgBouncer Connection Pool"]
        PB["PgBouncer<br/>150 incoming connections<br/>20 actual DB connections"]
    end

    subgraph DB["PostgreSQL"]
        PG["PostgreSQL<br/>(20 connections)"]
    end

    AS1 --> PB
    AS2 --> PB
    AS3 --> PB
    PB --> PG

    style AS1 fill:#374151,color:#fff
    style AS2 fill:#374151,color:#fff
    style AS3 fill:#374151,color:#fff
    style PB fill:#7c3aed,color:#fff
    style PG fill:#2563eb,color:#fff
```


## The N+1 Query Problem

**One of the most common database performance bugs**

```
Scenario: Fetch 100 posts and their authors

Bad code (N+1):
───────────────
posts = db.query("SELECT * FROM posts LIMIT 100")    -- 1 query

for post in posts:
    author = db.query(                                -- 100 queries!
        "SELECT * FROM users WHERE id = ?", post.author_id
    )
    post.author = author

Total: 1 + 100 = 101 queries 😱

Each query: ~5ms
Total time: 101 × 5ms = 505ms

Fix 1: JOIN
────────────
posts_with_authors = db.query("""
    SELECT posts.*, users.name, users.avatar
    FROM posts
    JOIN users ON posts.author_id = users.id
    LIMIT 100
""")
Total: 1 query, ~5ms ✅

Fix 2: Batch fetch (eager loading)
────────────────────────────────────
posts = db.query("SELECT * FROM posts LIMIT 100")    -- 1 query

author_ids = [p.author_id for p in posts]
authors = db.query(
    "SELECT * FROM users WHERE id = ANY(?)", author_ids
)                                                    -- 1 query!

author_map = {a.id: a for a in authors}
for post in posts:
    post.author = author_map[post.author_id]

Total: 2 queries ✅

ORM solutions:
──────────────
Rails:    Post.includes(:author).limit(100)
Django:   Post.objects.select_related('author')[:100]
Hibernate: @ManyToOne(fetch = FetchType.EAGER)
Prisma:   prisma.post.findMany({ include: { author: true } })
```

## Buffer Pool / Page Cache

```
All databases cache disk pages in memory:
──────────────────────────────────────────

PostgreSQL shared_buffers: Default 128MB, recommend 25% of RAM
                           Caches 8KB pages in memory.

Working set: The "hot" data that's frequently accessed.
             If hot data fits in buffer pool: most reads = RAM reads (fast!)
             If hot data > buffer pool: frequent disk reads (slow!)

Key insight:
   Adding RAM can be cheaper and simpler than query optimization.
   A 64GB server with 16GB shared_buffers can keep entire
   databases in memory for most applications.

Monitoring:
   SELECT * FROM pg_statio_user_tables;  -- hit vs disk reads
   Cache hit ratio should be > 99% for OLTP workloads.
```

## Database Performance Trade-off Table

| Technique | Read Speed | Write Speed | Storage | Complexity |
|---|---|---|---|---|
| **B-Tree index** | Fast | Slower | +10-30% | Low |
| **No index** | Slow (full scan) | Fast | Baseline | None |
| **Covering index** | Fastest | Slowest | +20-50% | Medium |
| **Composite index** | Fast (multi-col) | Slower | +15-35% | Medium |
| **Partitioning** | Fast (if pruned) | Same | Same | High |
| **Connection pooling** | No change | No change | No change | Low |
| **Read replicas** | Scales out | Primary only | 2× | Medium |

## Interview Tips

```
Common database internals interview questions:
──────────────────────────────────────────────

Q: "What is a B-tree index and when would you use it?"
A: A balanced tree structure where leaf nodes contain sorted row data
   or pointers. Use for equality and range queries. Maintains
   O(log n) read performance. Adds overhead to every write.
   Most common index type in OLTP databases.

Q: "What's the difference between B-tree and LSM-tree?"
A: B-tree is optimized for reads — in-place updates, great for OLTP.
   LSM-tree is optimized for writes — append-only, sequential I/O.
   Used in Cassandra/RocksDB. Reads are slower due to multiple SSTables.
   Background compaction periodically merges them.

Q: "What is the N+1 problem and how do you fix it?"
A: Loading N records, then querying the database once per record to
   fetch related data — resulting in N+1 total queries.
   Fix: Use a JOIN to load everything in one query, or batch-fetch
   related records with WHERE id IN (...) and join in memory.

Q: "Why is connection pooling important?"
A: Each database connection consumes significant resources (memory,
   TCP socket). Without pooling, a spike of 10,000 requests creates
   10,000 connections and overwhelms the database.
   Pooling reuses a small set of connections (e.g., 20) across
   thousands of application threads.

Q: "What is ACID and why does it matter?"
A: Atomicity (all-or-nothing), Consistency (valid state transitions),
   Isolation (concurrent tx don't interfere), Durability (committed
   data survives crashes). Matters for correctness in financial,
   inventory, and any transactional system where partial writes
   would cause data corruption.
```

## Practice Exercise

**Diagnose and fix this slow query:**

```sql
-- Users table: 1,000,000 rows
-- Orders table: 10,000,000 rows
-- This query takes 45 seconds:

SELECT
    u.name,
    COUNT(o.id) as order_count,
    SUM(o.amount) as total_spent
FROM users u
JOIN orders o ON o.user_id = u.id
WHERE u.country = 'US'
  AND o.created_at > '2024-01-01'
GROUP BY u.id, u.name
ORDER BY total_spent DESC
LIMIT 20;
```

<details>
<summary>Solution (Click to Expand)</summary>

```
Diagnose:
─────────
1. Run EXPLAIN ANALYZE on the query
2. Look for Seq Scan on large tables
3. Identify missing indexes

Likely issues:
  - No index on users.country (full scan of 1M users)
  - No index on orders.created_at (full scan of 10M orders)
  - No composite index on orders (user_id, created_at, amount)

Fixes:
──────
-- Index for filtering users by country
CREATE INDEX idx_users_country ON users (country);

-- Composite index for orders: filter by date, join by user_id,
-- aggregate amount — this is a covering index for the query
CREATE INDEX idx_orders_user_date_amount
  ON orders (user_id, created_at, amount)
  WHERE created_at > '2024-01-01';  -- partial index (even smaller!)

-- Covering index on users for the columns we need
CREATE INDEX idx_users_country_covering ON users (country, id, name);

After indexes:
  Expected time: ~50ms (from 45 seconds)
  Improvement: ~900×
```

</details>

## Summary

- **ACID** provides the four pillars of reliable transactions — atomicity, consistency, isolation, durability
- **B-Trees** are the standard for OLTP — balanced, sorted, excellent for reads and range queries
- **LSM-Trees** (Cassandra, RocksDB) are optimized for write-heavy workloads via sequential I/O
- **Column-oriented storage** (BigQuery, Redshift) dramatically speeds up analytics aggregations
- **Indexes** are the most impactful optimization — always explain queries before adding them blindly
- **Query planner** uses statistics to choose execution plans — keep statistics fresh with ANALYZE
- **Connection pooling** (PgBouncer, HikariCP) is mandatory in production to prevent connection exhaustion
- **N+1 queries** are the most common ORM bug — use JOINs or batch fetching

## Next Steps

Continue to [SQL vs NoSQL](../14-sql-nosql/README.md) to learn when to choose relational vs non-relational databases.

---

**Key Takeaway**: Understanding how databases store, index, and retrieve data transforms you from someone who guesses at performance to someone who diagnoses and solves problems systematically.
