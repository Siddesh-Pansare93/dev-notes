# Consistency Models

## Why Consistency Matters

```
Problem: Multiple servers, same data
──────────────────────────────────────
User writes $100 → $150 to Node A
User reads balance from Node B

What does Node B return?
├─ Strong consistency: $150 (correct)
├─ Eventual consistency: $100 (stale, will update soon)
└─ Weak consistency: unknown

The consistency model defines the guarantee.
```

## The Consistency Spectrum

```mermaid
flowchart LR
    S["**Strong**<br/>Linearizability<br/>All reads see latest write"]
    Seq["**Sequential**<br/>Operations appear in<br/>some sequential order"]
    Cau["**Causal**<br/>Causally related ops<br/>seen in order"]
    Ev["**Eventual**<br/>All replicas converge<br/>given enough time"]

    S -->|"weaker"| Seq
    Seq -->|"weaker"| Cau
    Cau -->|"weaker"| Ev

    style S fill:#7c3aed,color:#fff
    style Seq fill:#2563eb,color:#fff
    style Cau fill:#059669,color:#fff
    style Ev fill:#f59e0b,color:#fff
```


## Strong Consistency (Linearizability)

**The gold standard: every read reflects the most recent write**

```
Definition:
───────────
Operations appear to execute atomically at a single point in time.
Once a write completes, all subsequent reads return that value.

Timeline example:
─────────────────

Time:    0    1    2    3    4    5
         │    │    │    │    │    │
Client A │──Write(x=1)──┤    │    │
Client B │         │    ├──Read(x)─→ Returns 1
Client C │         │    │    ├──Read(x)─→ Returns 1

All clients agree on the value after the write completes.
No client can ever observe a "rewind" in time.
```

**What linearizability guarantees:**

```
✅ Read-after-write: You always read your own writes
✅ No stale reads: Once a value is written, it's visible everywhere
✅ Single-copy illusion: Distributed system feels like one machine
✅ No anomalies: No "lost" or "duplicated" writes visible to clients

Cost:
─────
❌ Latency: Must coordinate across replicas before returning
❌ Availability: Cannot serve reads/writes during network partition (CP)
❌ Throughput: Synchronous replication limits write rate
```

### How Strong Consistency is Achieved

```mermaid
sequenceDiagram
    participant C as Client
    participant L as Leader Node
    participant R1 as Replica 1
    participant R2 as Replica 2

    C->>L: Write(balance=150)
    L->>R1: Replicate(balance=150)
    L->>R2: Replicate(balance=150)
    R1-->>L: ACK
    R2-->>L: ACK
    L-->>C: Write confirmed

    Note over L,R2: Only after ALL replicas confirm<br/>does the write return to client

    C->>L: Read(balance)
    L-->>C: Returns 150 (guaranteed latest)
```

**Real systems using strong consistency:**
- HBase (synchronous HDFS writes)
- Zookeeper / etcd (Raft consensus)
- Spanner (TrueTime + Paxos)
- PostgreSQL with synchronous replication

## Sequential Consistency

**Weaker than linearizability, but preserves program order**

```
Definition:
───────────
Operations from each process appear in their program order,
but operations from different processes can be interleaved.

Does NOT guarantee real-time ordering across clients.

Example:
────────
Thread 1: Write(x=1), Write(y=1)
Thread 2: Read(y), Read(x)

Valid under sequential consistency:
  Thread 2 reads y=1, x=1    ✅
  Thread 2 reads y=0, x=0    ✅ (both reads before Thread 1 writes)
  Thread 2 reads y=0, x=1    ❌ (impossible — x written before y)

Not valid: Thread 2 sees y=1 but x=0
   (y was written after x, so if y is visible, x must be too)
```

**Used in:** CPU memory models, some distributed databases with relaxed guarantees.

## Causal Consistency

**"If A caused B, everyone sees A before B"**

```
Definition:
───────────
Operations that are causally related must be seen in the same order
by all processes. Concurrent (causally unrelated) operations may
be seen in different orders on different nodes.

Example:
────────
User A posts: "What time is it?"
User B replies: "It's 3pm"

Causal consistency guarantees:
  Everyone who sees the reply also sees the question.
  You can never see the reply without seeing the question first.

Unlike sequential, concurrent unrelated posts can appear in any order.
```

```mermaid
flowchart TB
    subgraph Causal["Causal Dependency Chain"]
        P["Post: 'What time is it?'<br/>#7c3aed background"]
        R["Reply: 'It's 3pm'<br/>(causally depends on post)"]
        L["Like on reply<br/>(causally depends on reply)"]

        P -->|"causes"| R
        R -->|"causes"| L
    end

    subgraph Guarantee["System Guarantee"]
        G1["If you see the Like,<br/>you also see the Reply"]
        G2["If you see the Reply,<br/>you also see the Post"]
    end

    L --> G1
    R --> G2

    style P fill:#7c3aed,color:#fff
    style R fill:#2563eb,color:#fff
    style L fill:#059669,color:#fff
    style G1 fill:#374151,color:#fff
    style G2 fill:#374151,color:#fff
```

**Used in:** MongoDB (causal sessions), some distributed databases, version control systems.

## Eventual Consistency

**"All replicas will agree... eventually"**

```
Definition:
───────────
If no new updates are made, all replicas will eventually
converge to the same value. No guarantee on when.

Timeline:
─────────

Time:    0    1    2    3    4    5    6    7
         │    │    │    │    │    │    │    │
Write    ├──W(x=1)──┤                      │
Node A   │    x=1   │    x=1   x=1   x=1   │
Node B   │    x=0   │    x=0   x=1   x=1   │ (replication lag)
Node C   │    x=0   │    x=0   x=0   x=1   │ (longer lag)

After time 6: all nodes agree on x=1  ✅
Before then: inconsistent reads possible
```

**What you might observe under eventual consistency:**

```
Anomaly 1: Stale Read
──────────────────────
You write x=2, then immediately read x from a different replica.
You might read x=1 (the old value).
→ Fix: Read-your-writes guarantee (see below)

Anomaly 2: Monotonic Reads Violation
──────────────────────────────────────
Request 1 hits Node A: sees x=2
Request 2 hits Node B: sees x=1 (Node B hasn't caught up yet)
Time appears to go backwards.
→ Fix: Monotonic reads guarantee

Anomaly 3: Write Conflicts
───────────────────────────
Two users update the same record concurrently on different replicas.
Both writes succeed. Now replicas disagree.
→ Fix: Conflict resolution strategies
```

### Conflict Resolution

When two replicas diverge, the system must reconcile them:

```mermaid
flowchart TB
    W1["Node A: user.name='Alice'<br/>timestamp: 10:00:01"]
    W2["Node B: user.name='Bob'<br/>timestamp: 10:00:03"]
    Conflict["Conflict Detected<br/>on sync"]

    W1 --> Conflict
    W2 --> Conflict

    LWW["Last-Write-Wins (LWW)<br/>Keep 'Bob' (newer timestamp)<br/>Alice's write is lost"]
    CRDT["CRDT (Merge)<br/>Both values merged<br/>without data loss"]
    App["Application-Level<br/>Present conflict to user<br/>for manual resolution"]

    Conflict --> LWW
    Conflict --> CRDT
    Conflict --> App

    style W1 fill:#2563eb,color:#fff
    style W2 fill:#2563eb,color:#fff
    style Conflict fill:#ef4444,color:#fff
    style LWW fill:#f59e0b,color:#fff
    style CRDT fill:#059669,color:#fff
    style App fill:#374151,color:#fff
```

**Last-Write-Wins (LWW):**

```
Mechanism:
──────────
Each write carries a timestamp (or logical clock).
When replicas sync, the higher timestamp wins.

Pros:
✅ Simple to implement
✅ Works for non-overlapping writes

Cons:
❌ Concurrent writes silently lost
❌ Clock skew can cause wrong winner
❌ Not suitable for counters, sets, lists

Used by: DynamoDB (default), Cassandra (default)
```

**CRDTs (Conflict-free Replicated Data Types):**

```
Mechanism:
──────────
Data structures designed so all concurrent operations
can be merged without conflict — mathematically.

Examples:
─────────
G-Counter (Grow-Only Counter):
  Node A: increments by 3
  Node B: increments by 2
  Merge: total = 3 + 2 = 5 ✅ (never lost)

OR-Set (Observed-Remove Set):
  Node A: add("apple"), add("banana")
  Node B: remove("apple"), add("cherry")
  Merge: {"banana", "cherry"} ✅ (semantically correct)

Used by: Redis (some types), Riak, collaborative editors (Google Docs)
```

## Session Guarantees

Consistency models for a single user's session:

### Read-Your-Writes

```
Guarantee:
──────────
After you write a value, your subsequent reads always return
that value or a more recent one (never the old one).

Without it:
───────────
POST /profile (name="Alice")  → 201 OK on Node A
GET /profile                  → reads from Node B → returns name="Bob" 😱

With it:
────────
Client tracks "read-your-writes token" (version number / timestamp)
GET request includes token → system routes to a node that has caught up

Used by: MongoDB (causal consistency sessions), most well-designed APIs
```

### Monotonic Reads

```
Guarantee:
──────────
If you read a value X, you will never subsequently read an older value.
Time only moves forward.

Without it:
───────────
Read 1: user.follower_count = 1000  (from up-to-date replica)
Read 2: user.follower_count = 980   (from lagging replica)
User sees count go backwards — confusing!

With it:
────────
System tracks which replica version client has observed.
Routes subsequent reads to replicas at least as up-to-date.
```

### Causal Consistency (Session Level)

```
Guarantee:
──────────
Operations that are causally related are observed in order.
"You posted a comment — you can always see your own comment
 and anyone who replies to it must also see it."

Tracked via: vector clocks, hybrid logical clocks (HLC)
```

## ACID vs BASE

| Property | ACID | BASE |
|---|---|---|
| **Stands for** | Atomicity, Consistency, Isolation, Durability | Basically Available, Soft state, Eventual consistency |
| **Consistency model** | Strong (linearizable) | Eventual |
| **Availability** | Sacrificed during partition | Prioritized |
| **CAP choice** | CP | AP |
| **Typical systems** | PostgreSQL, MySQL, Oracle | DynamoDB, Cassandra, Couchbase |
| **Use case** | Financial transactions, inventory | Social feeds, carts, analytics |
| **Failure mode** | Return error (refuse bad state) | Accept writes, reconcile later |

```
ACID Deep Dive:
───────────────
Atomicity:    All operations in a transaction succeed or all fail.
              No partial writes. (BEGIN; UPDATE; ROLLBACK works)

Consistency:  Database moves from one valid state to another.
              Constraints, foreign keys always satisfied.

Isolation:    Concurrent transactions don't interfere.
              Levels: Read Uncommitted → Read Committed → Repeatable Read → Serializable

Durability:   Committed transactions survive crashes.
              Written to disk (WAL, fsync) before confirming.
```

```
BASE Deep Dive:
───────────────
Basically Available:  System responds to every request (might be stale).
Soft State:          State may change over time even without new input
                     (due to eventual consistency propagation).
Eventual Consistency: Given no new updates, all replicas converge.
```

## Replication Lag Visualization

```mermaid
flowchart LR
    subgraph Write["Write Path"]
        W["Client Write<br/>balance=150"]
        P["Primary<br/>balance=150<br/>(t=0ms)"]
    end

    subgraph Async["Async Replication"]
        R1["Replica 1<br/>balance=150<br/>(t=50ms)"]
        R2["Replica 2<br/>balance=150<br/>(t=200ms)"]
        R3["Replica 3<br/>balance=150<br/>(t=1000ms)"]
    end

    subgraph Reads["Client Reads"]
        C1["Read at t=100ms<br/>→ Replica 1: 150 ✅"]
        C2["Read at t=100ms<br/>→ Replica 2: 100 ⚠️"]
        C3["Read at t=100ms<br/>→ Replica 3: 100 ⚠️"]
    end

    W --> P
    P -->|"async"| R1
    P -->|"async"| R2
    P -->|"async"| R3
    R1 --> C1
    R2 --> C2
    R3 --> C3

    style P fill:#7c3aed,color:#fff
    style R1 fill:#059669,color:#fff
    style R2 fill:#f59e0b,color:#fff
    style R3 fill:#ef4444,color:#fff
    style C1 fill:#059669,color:#fff
    style C2 fill:#f59e0b,color:#fff
    style C3 fill:#ef4444,color:#fff
```

## Tunable Consistency (Cassandra / DynamoDB)

**Pick your consistency level per operation**

```
Cassandra Consistency Levels:
──────────────────────────────

ONE:    Write to 1 replica. Read from 1 replica.
        Fastest. Weakest guarantee.

QUORUM: Write/read from majority of replicas (N/2 + 1).
        Balance of speed and consistency.

ALL:    Write/read must succeed on ALL replicas.
        Slowest. Strongest guarantee.

LOCAL_QUORUM: Quorum within local datacenter only.
              Good for multi-region deployments.

Formula for strong consistency:
    W + R > N
    Where W = write replicas, R = read replicas, N = total replicas

Example with N=3:
    W=2, R=2: 2+2=4 > 3  ✅ strong consistency
    W=1, R=1: 1+1=2 = 3  ❌ eventual consistency only
```

```mermaid
flowchart TB
    subgraph Quorum["N=3 Quorum Write (W=2)"]
        Client["Client Write"]
        N1["Node 1 ✅"]
        N2["Node 2 ✅"]
        N3["Node 3 (slow)"]

        Client --> N1
        Client --> N2
        Client --> N3

        Ack["Return to client<br/>(2 of 3 confirmed)"]
        N1 --> Ack
        N2 --> Ack
    end

    style Client fill:#7c3aed,color:#fff
    style N1 fill:#059669,color:#fff
    style N2 fill:#059669,color:#fff
    style N3 fill:#f59e0b,color:#fff
    style Ack fill:#2563eb,color:#fff
```

## Real Systems Compared

| System | Consistency Model | Mechanism | Trade-off |
|---|---|---|---|
| **HBase** | Strong (linearizable) | Single region master, HDFS sync | Low availability during failures |
| **Zookeeper** | Sequential consistency | Zab protocol (like Paxos) | Slower writes, high consistency |
| **DynamoDB** | Eventual (default) / Strong (opt-in) | Quorum reads/writes | Strong reads cost 2x |
| **Cassandra** | Tunable (ONE to ALL) | Configurable W+R quorum | You choose the trade-off |
| **MongoDB** | Causal (sessions) / Strong (w:majority) | Raft-based replica sets | Strong = slower writes |
| **Spanner** | External consistency (linearizable) | TrueTime + Paxos | Complex, expensive infra |
| **Redis** | Eventual (async replication) | Async primary→replica | Data loss possible on failover |

## Consistency Trade-off Table

| Model | Latency | Availability | Data Freshness | Complexity |
|---|---|---|---|---|
| Linearizable | High | Low | Always fresh | High |
| Sequential | Medium | Medium | Slightly stale | Medium |
| Causal | Low-Medium | Medium-High | Causally fresh | Medium |
| Eventual | Low | High | May be stale | Low-Medium |

## Interview Tips

```
Common interview questions on consistency:
──────────────────────────────────────────

Q: "What consistency model would you use for a bank?"
A: Strong consistency (linearizable). Money requires accurate
   balances. Use synchronous replication and ACID transactions.
   Accept higher latency for correctness.

Q: "What about a social media feed?"
A: Eventual consistency is fine. Users tolerate seeing a post
   a few seconds late. Prioritize availability and low latency.
   Use async replication.

Q: "How does Cassandra achieve tunable consistency?"
A: By configuring write quorum (W) and read quorum (R) such that
   W + R > N guarantees at least one replica has the latest value.
   E.g., N=3, W=2, R=2: any read overlaps with at least one
   confirmed write.

Q: "What is a CRDT?"
A: A Conflict-free Replicated Data Type — a data structure with
   a merge function that is commutative, associative, and idempotent.
   Any two replicas can merge independently and reach the same result.
   Used for counters, sets, and collaborative editing.

Q: "What's the difference between eventual and strong consistency?"
A: Strong: reads always return the latest write. Requires coordination.
   Eventual: reads may return stale data, but replicas converge over time.
   Eventual is faster and more available; strong is safer for financial data.
```

## Practice Exercise

**Choose a consistency model for these scenarios:**

1. **Inventory counter** — decrement stock when a product is purchased
2. **User profile update** — change display name
3. **Collaborative document editing** — multiple users edit simultaneously
4. **Ride-sharing GPS location** — driver position updates every second

<details>
<summary>Solutions (Click to Expand)</summary>

```
1. Inventory counter: Strong consistency
   ─────────────────────────────────────
   Overselling is catastrophic (sell 10 items you only have 5 of).
   Use serializable transactions or compare-and-swap.
   Cost: lower throughput during flash sales.

2. User profile update: Read-your-writes + eventual
   ──────────────────────────────────────────────────
   User must see their own change immediately.
   Others can see it slightly delayed (seconds is fine).
   Session-level guarantee sufficient.

3. Collaborative document: CRDTs
   ───────────────────────────────
   Concurrent edits from many users must merge without data loss.
   CRDTs (like those in Google Docs / Yjs) handle this elegantly.
   No single point of coordination needed.

4. GPS location: Eventual consistency
   ─────────────────────────────────────
   Stale by 1-2 seconds is acceptable — driver is still near that spot.
   Prioritize write throughput (millions of location updates/sec).
   Eventual consistency + last-write-wins is perfect here.
```

</details>

## Summary

- **Linearizability** is the strongest model — reads always see the latest write, at the cost of latency and availability
- **Eventual consistency** is the most available — replicas converge over time, enabling AP systems
- **Causal consistency** is a practical middle ground — preserves cause-and-effect ordering without full sync
- **Session guarantees** (read-your-writes, monotonic reads) improve UX without requiring global strong consistency
- **ACID = strong consistency** for transactional systems; **BASE = eventual consistency** for scalable systems
- **Tunable consistency** (Cassandra, DynamoDB) lets you pick the right trade-off per operation
- **CRDTs** solve the conflict problem mathematically — concurrent writes merge without data loss

## Next Steps

Continue to [Load Balancing](../09-load-balancing/README.md) to learn how traffic is distributed across servers.

---

**Key Takeaway**: There is no universally "correct" consistency model. Match the model to your business requirements — use strong consistency where correctness is critical, and embrace eventual consistency where availability and speed matter more.
