import os
import re

for root, _, files in os.walk('system_design'):
    for file in files:
        if file.endswith('.md'):
            path = os.path.join(root, file)
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Find ``` blocks
            blocks = re.findall(r'```([^\n]*)\n(.*?)```', content, re.DOTALL)
            for lang, block in blocks:
                if lang.strip() not in ['mermaid', 'python', 'java', 'js', 'javascript', 'json', 'yaml', 'bash', 'sh']:
                    # check for ascii art indicators
                    if any(x in block for x in ['┌', '├', '│', '+---', '--->', '    |', '---|']):
                        print(f"{path}")
                        break
