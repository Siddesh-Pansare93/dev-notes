"""
Automated script to remove ASCII diagrams that appear immediately after Mermaid diagrams.
"""

import re


def remove_ascii_after_mermaid_in_file(filepath):
    """
    Remove ASCII diagram blocks that appear immediately after Mermaid blocks.
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        original_content = content

        # Find and remove ASCII blocks that appear after Mermaid
        # Pattern: ```mermaid ... ``` followed by whitespace and then ``` ... ``` with ASCII
        lines = content.split("\n")
        new_lines = []
        skip_until = -1
        mermaid_just_ended = False
        mermaid_end_line = -1

        i = 0
        while i < len(lines):
            line = lines[i]

            # Track if we just ended a Mermaid block
            if mermaid_just_ended and line.strip() == "":
                # Empty line after Mermaid, keep it
                new_lines.append(line)
                i += 1
                continue

            # Check for start of Mermaid block
            if "```mermaid" in line:
                new_lines.append(line)
                i += 1
                # Copy the mermaid block
                while i < len(lines) and lines[i].strip() != "```":
                    new_lines.append(lines[i])
                    i += 1
                if i < len(lines):
                    new_lines.append(lines[i])  # Add closing ```
                    mermaid_just_ended = True
                    mermaid_end_line = i
                    i += 1
                continue

            # Check if this starts an ASCII diagram block after Mermaid
            if (
                mermaid_just_ended
                and i - mermaid_end_line <= 3  # Within 3 lines of Mermaid end
                and line.strip() == "```"
            ):
                # Look ahead to see if this is an ASCII diagram
                has_ascii = False
                block_end = i + 1
                while block_end < len(lines) and lines[block_end].strip() != "```":
                    if re.search(r"[┌└├│→▼▲►◄↓]", lines[block_end]):
                        has_ascii = True
                    block_end += 1

                if has_ascii and block_end < len(lines):
                    # Skip this entire ASCII block
                    i = block_end + 1
                    mermaid_just_ended = False
                    continue

            # Reset mermaid_just_ended if we've moved past the immediate vicinity
            if mermaid_just_ended and i - mermaid_end_line > 3:
                mermaid_just_ended = False

            new_lines.append(line)
            i += 1

        new_content = "\n".join(new_lines)

        if new_content != original_content:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(new_content)
            return True, "Modified successfully"
        else:
            return False, "No changes needed"

    except Exception as e:
        return False, f"Error: {str(e)}"


# Files to process
files = [
    "system_design/05-networking/README.md",
    "system_design/08-consistency/README.md",
    "system_design/12-cdn/README.md",
    "system_design/13-databases/README.md",
    "system_design/15-sharding/README.md",
    "system_design/16-replication/README.md",
    "system_design/17-microservices/README.md",
    "system_design/18-message-queues/README.md",
    "system_design/19-api-gateway/README.md",
    "system_design/20-rate-limiting/README.md",
    "system_design/21-circuit-breaker/README.md",
    "system_design/22-real-time/README.md",
    "system_design/23-url-shortener/README.md",
    "system_design/24-design-twitter/README.md",
    "system_design/25-event-driven/README.md",
    "system_design/26-monitoring/README.md",
    "system_design/27-design-netflix/README.md",
    "system_design/28-design-uber/README.md",
    "system_design/29-consensus-algorithms/README.md",
    "system_design/33-auth/README.md",
]

print("Processing files...\n")
modified_count = 0

for filepath in files:
    success, message = remove_ascii_after_mermaid_in_file(filepath)
    if success:
        print(f"[OK] {filepath}")
        modified_count += 1
    else:
        print(f"  {filepath}: {message}")

print(f"\nProcessed {len(files)} files, modified {modified_count} files")
