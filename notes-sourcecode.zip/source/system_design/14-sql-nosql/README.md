# SQL vs NoSQL

## The Core Question

```
When should you use a relational database?
When should you use NoSQL?

Short answer:
─────────────
SQL:    When you need ACID transactions, complex joins, and a
        well-defined schema. Most applications should start here.

NoSQL:  When you need to scale horizontally, have flexible/nested
        data, or a specific access pattern that relational models
        handle poorly (graphs, time-series, key-value caching).
```

## SQL Databases: The Relational Model

**Data is stored in tables (relations) with rows and columns.**

```
Table: users
─────────────────────────────────────────────
id  | name    | email              | country
────┼─────────┼────────────────────┼─────────
1   | Alice   | alice@example.com  | US
2   | Bob     | bob@example.com    | UK
3   | Charlie | charlie@example.com| US

Table: orders
─────────────────────────────────────────────────────────
id  | user_id | amount | status   | created_at
────┼─────────┼────────┼──────────┼────────────
1   | 1       | 29.99  | shipped  | 2024-01-15
2   | 1       | 149.00 | pending  | 2024-01-20
3   | 2       | 9.99   | shipped  | 2024-01-18

Relationship: orders.user_id → users.id (foreign key)
```

### Joins

```sql
-- Fetch all orders with the user's name:
SELECT u.name, o.amount, o.status
FROM orders o
JOIN users u ON o.user_id = u.id
WHERE u.country = 'US';

-- Result:
-- name  | amount | status
-- ──────┼────────┼────────
-- Alice | 29.99  | shipped
-- Alice | 149.00 | pending

Joins are SQL's superpower:
  - INNER JOIN: only rows that match in both tables
  - LEFT JOIN:  all rows from left, matching from right (nulls if no match)
  - RIGHT JOIN: all rows from right, matching from left
  - FULL JOIN:  all rows from both, nulls where no match
```

### Schema Enforcement

```
SQL databases enforce schema at write time:
────────────────────────────────────────────

CREATE TABLE users (
  id      SERIAL PRIMARY KEY,
  name    TEXT NOT NULL,
  email   TEXT UNIQUE NOT NULL,
  country CHAR(2),
  age     INT CHECK (age >= 0 AND age <= 150)
);

Attempting invalid insert:
  INSERT INTO users (name, email, age) VALUES ('Dave', 'dave@x.com', -5);
  ERROR: new row violates check constraint "users_age_check"

Benefits:
✅ Data integrity guaranteed by database
✅ Applications can trust data they read
✅ Schema is documentation

Drawbacks:
❌ Schema changes (migrations) require ALTER TABLE — can lock tables
❌ Schema must be known upfront — harder for exploratory/evolving data
```

### Transactions

```sql
-- Transfer $100 from Alice to Bob:
BEGIN;
  UPDATE accounts SET balance = balance - 100 WHERE id = 1;
  UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT;

-- If anything fails, ROLLBACK — no partial state ✅

-- Multi-table operations:
BEGIN;
  INSERT INTO orders (user_id, amount, status)
    VALUES (1, 99.99, 'pending') RETURNING id INTO order_id;
  INSERT INTO order_items (order_id, product_id, qty)
    VALUES (order_id, 42, 2);
  UPDATE inventory SET stock = stock - 2 WHERE product_id = 42;
COMMIT;
```

## NoSQL Categories

```mermaid
flowchart TB
    NoSQL["NoSQL Databases"]

    KV["Key-Value Stores<br/>────────────────<br/>Redis, DynamoDB, Memcached<br/><br/>Simple map: key → value<br/>Sub-millisecond lookups<br/>Best: caching, sessions, leaderboards"]

    Doc["Document Stores<br/>──────────────────<br/>MongoDB, Firestore, CouchDB<br/><br/>Stores JSON/BSON documents<br/>Flexible schema per document<br/>Best: user profiles, catalogs, CMS"]

    Wide["Wide-Column Stores<br/>──────────────────────<br/>Cassandra, HBase, ScyllaDB<br/><br/>Rows with many dynamic columns<br/>Excellent write throughput<br/>Best: time-series, IoT, logs"]

    Graph["Graph Databases<br/>────────────────────<br/>Neo4j, Amazon Neptune<br/><br/>Nodes and edges (relationships)<br/>Traversal is first-class<br/>Best: social graphs, recommendations"]

    NoSQL --> KV
    NoSQL --> Doc
    NoSQL --> Wide
    NoSQL --> Graph

    style NoSQL fill:#7c3aed,color:#fff
    style KV fill:#2563eb,color:#fff
    style Doc fill:#059669,color:#fff
    style Wide fill:#f59e0b,color:#fff
    style Graph fill:#ef4444,color:#fff
```

### Key-Value Stores (Redis)

```
Data model: dictionary / hash map
─────────────────────────────────
SET user:session:abc123  '{"user_id": 1, "role": "admin"}'  EX 3600
GET user:session:abc123  → '{"user_id": 1, "role": "admin"}'
DEL user:session:abc123

Redis data types:
──────────────────
String:      SET key value                          (any binary data)
List:        LPUSH / RPUSH / LRANGE                (ordered list)
Set:         SADD / SMEMBERS / SINTERSTORE          (unordered unique)
Sorted Set:  ZADD leaderboard 1000 alice            (sorted by score)
Hash:        HSET user:1 name Alice age 30          (nested fields)
Stream:      XADD events * type click url /home     (append-only log)

Use cases:
──────────
✅ Session storage (TTL = automatic expiry)
✅ Leaderboards (sorted sets)
✅ Rate limiting (INCR + EXPIRE)
✅ Pub/Sub messaging
✅ Caching layer in front of any database
✅ Job queues (LIST as queue, BRPOP as consumer)

Limitations:
❌ No joins
❌ Data must fit in RAM
❌ No complex queries
❌ Not primary store for relational data
```

### Document Stores (MongoDB)

```
Data model: JSON documents grouped in collections
──────────────────────────────────────────────────

// Document in "users" collection:
{
  "_id": "ObjectId('64a1b2c3d4e5f6a7b8c9d0e1')",
  "name": "Alice",
  "email": "alice@example.com",
  "address": {
    "street": "123 Main St",
    "city": "New York",
    "zip": "10001"
  },
  "orders": [                     // embedded array
    { "id": 1, "amount": 29.99, "status": "shipped" },
    { "id": 2, "amount": 149.00, "status": "pending" }
  ],
  "tags": ["premium", "us-east"]
}

Queries:
─────────
db.users.find({ "address.city": "New York" })
db.users.find({ "orders.status": "pending" })
db.users.aggregate([
  { $unwind: "$orders" },
  { $group: { _id: "$_id", total: { $sum: "$orders.amount" } } }
])

Use cases:
──────────
✅ Product catalogs (varied attributes per product)
✅ User profiles (nested addresses, preferences)
✅ CMS content (articles with flexible fields)
✅ Event logging (each event has different fields)

Limitations:
❌ No joins (must embed or do multiple queries)
❌ No multi-document ACID (MongoDB 4.0+ added it, but it's slower)
❌ Schema flexibility = risk of inconsistent data
❌ Large documents fetched even when only one field needed
```

### Wide-Column Stores (Cassandra)

```
Data model: rows with dynamic columns per partition
────────────────────────────────────────────────────

Table: sensor_readings
──────────────────────────────────────────────────────────────────────
sensor_id (partition) │ timestamp (clustering) │ temperature │ humidity
──────────────────────┼────────────────────────┼─────────────┼──────────
sensor-001            │ 2024-01-15T10:00:00    │ 22.5        │ 65.3
sensor-001            │ 2024-01-15T10:01:00    │ 22.7        │ 64.8
sensor-001            │ 2024-01-15T10:02:00    │ 22.4        │ 65.1
sensor-002            │ 2024-01-15T10:00:00    │ 18.2        │ 70.1

Query (CQL):
  SELECT * FROM sensor_readings
  WHERE sensor_id = 'sensor-001'
    AND timestamp > '2024-01-15T10:00:00';

Cassandra design rules:
────────────────────────
1. Design tables around query patterns, not entity relationships
2. Partition key determines which node stores the data (must be in WHERE)
3. Clustering key determines order within a partition
4. Denormalization is expected — duplicate data to avoid joins

Use cases:
──────────
✅ IoT / time-series data (billions of rows, write-heavy)
✅ User activity logs
✅ Product recommendation data
✅ Multi-region writes (Cassandra is natively multi-master)

Limitations:
❌ No joins — queries must match table design
❌ No aggregations (must be pre-computed)
❌ Schema design is hard — wrong partition key = hotspot
❌ Eventual consistency by default (tunable)
```

### Graph Databases (Neo4j)

```
Data model: nodes and edges (relationships)
────────────────────────────────────────────

Nodes:  (Alice:Person), (Bob:Person), (Inception:Movie)
Edges:  (Alice)-[:FOLLOWS]->(Bob)
        (Alice)-[:WATCHED {rating: 5}]->(Inception)
        (Bob)-[:WATCHED {rating: 4}]->(Inception)

Cypher query (Neo4j):
──────────────────────
// Find movies that Alice's friends liked but Alice hasn't seen:
MATCH (alice:Person {name: "Alice"})-[:FOLLOWS]->(friend:Person)
      -[:WATCHED]->(movie:Movie)
WHERE NOT (alice)-[:WATCHED]->(movie)
RETURN movie.title, count(friend) as friend_count
ORDER BY friend_count DESC
LIMIT 10;

// In SQL: This requires 4+ JOIN operations and is extremely slow
// In Neo4j: Traversal is O(edges touched) not O(total data size)

Use cases:
──────────
✅ Social networks (followers, friends, connections)
✅ Recommendation engines
✅ Fraud detection (unusual transaction patterns)
✅ Knowledge graphs
✅ Organizational hierarchies

Limitations:
❌ Poor for large aggregations or simple tabular queries
❌ Not horizontally scalable like Cassandra
❌ High learning curve (graph thinking is different)
```

## NoSQL Data Modeling

### Denormalization

```
SQL (normalized):
─────────────────
orders table: user_id (FK)
users table:  id, name, email

To get order with user name: JOIN ← extra work

NoSQL (denormalized — MongoDB):
────────────────────────────────
{
  "order_id": 1,
  "amount": 29.99,
  "user": {                    ← embedded, no join needed
    "id": 1,
    "name": "Alice",
    "email": "alice@example.com"
  }
}

Reads are faster (no join).
Writes are more complex (update user name = update all orders!).
```

### Embedding vs Referencing

```
Rule: Embed when the data is "owned by" the parent and
      mostly accessed together.
      Reference when the data is shared across many documents.

Embed (good):
─────────────
User → addresses (user's own addresses, accessed with user)
Post → comments (comments belong to one post)
Order → line items (line items belong to one order)

Reference (good):
─────────────────
Post → author (user exists independently, has many posts)
Product → category (category shared across thousands of products)
Comment → author (user exists independently)

Rule of thumb:
  One-to-few: embed
  One-to-many (large): reference
  Many-to-many: reference
```

## Decision Framework: SQL vs NoSQL

```mermaid
flowchart TD
    Start["New database choice needed"]

    Q1{"Do you need complex\nJOINs across entities?"}
    Q2{"Do you need\nACID transactions?"}
    Q3{"Is your schema\nflexible/evolving?"}
    Q4{"Do you need\nhorizontal scaling?"}
    Q5{"What is your\nprimary access pattern?"}

    SQL["Use SQL\n(PostgreSQL, MySQL)"]

    KV2["Key-Value\n(Redis, DynamoDB)"]
    Doc2["Document\n(MongoDB, Firestore)"]
    Wide2["Wide-Column\n(Cassandra, HBase)"]
    Graph2["Graph\n(Neo4j, Neptune)"]

    Start --> Q1
    Q1 -->|"Yes"| SQL
    Q1 -->|"No"| Q2
    Q2 -->|"Yes, critical"| SQL
    Q2 -->|"No / eventual OK"| Q3
    Q3 -->|"Yes, varies a lot"| Q4
    Q3 -->|"No, stable schema"| SQL
    Q4 -->|"Massive scale writes"| Q5
    Q4 -->|"Moderate scale"| Doc2
    Q5 -->|"Simple key lookup"| KV2
    Q5 -->|"Time-series / logs"| Wide2
    Q5 -->|"Relationship traversal"| Graph2

    style SQL fill:#7c3aed,color:#fff
    style KV2 fill:#2563eb,color:#fff
    style Doc2 fill:#059669,color:#fff
    style Wide2 fill:#f59e0b,color:#fff
    style Graph2 fill:#ef4444,color:#fff
```

### When to Definitely Use SQL

```
✅ Financial applications (banking, payments, accounting)
   Reason: ACID transactions are mandatory.

✅ Inventory management
   Reason: Overselling = losing money. Strong consistency required.

✅ User authentication / identity
   Reason: Unique emails, consistent login state.

✅ Most CRUD applications
   Reason: Relational model maps naturally to most business domains.
   PostgreSQL handles millions of rows on a single node effortlessly.

✅ Reporting and analytics (moderate scale)
   Reason: SQL is a powerful query language; JOINs simplify reports.

✅ When you don't know your query patterns yet
   Reason: SQL allows ad-hoc queries; NoSQL requires upfront design.
```

### When NoSQL Makes Sense

```
✅ Caching layer (Redis)
   Any app can benefit from caching hot data in Redis.
   Not a replacement for primary storage.

✅ User-generated content with varied structure (MongoDB)
   Product attributes vary per category (shoes have size, TVs have resolution).
   Document model handles this naturally.

✅ IoT / telemetry at extreme scale (Cassandra)
   100,000 sensors, each writing once per second = 100M writes/min.
   Cassandra is designed for exactly this.

✅ Social graph features (Neo4j)
   "Suggest friends" queries are 10-100× faster in graph databases
   vs equivalent JOINs in SQL at scale.

✅ Full-text search (Elasticsearch — a special case)
   Not quite a NoSQL database, but often grouped with them.
   Search across millions of documents with relevance ranking.
```

## NewSQL: The Best of Both Worlds

```
Problem:
────────
SQL: Great consistency, hard to scale horizontally.
NoSQL: Easy to scale, but gives up ACID.

NewSQL solution:
─────────────────
Distributed SQL — scale horizontally while preserving ACID.

How it works:
─────────────
Data sharded across many nodes (like NoSQL).
Each shard participates in distributed transactions (unlike NoSQL).
Uses consensus protocols (Raft/Paxos) to coordinate.

Systems:
────────
CockroachDB: PostgreSQL-compatible, distributed ACID.
             Named after cockroaches — survives node failures.

TiDB:        MySQL-compatible, separates compute and storage.
             TiKV for storage (RocksDB + Raft).
             TiFlash for columnar OLAP queries.

Google Spanner: Global-scale relational database.
                Uses TrueTime (GPS + atomic clocks) for linearizability.
                Powers Google's ads, payments infrastructure.
                Available via Cloud Spanner.

Trade-offs:
────────────
✅ Horizontal scaling like NoSQL
✅ ACID transactions like SQL
✅ SQL interface — no application changes
❌ Higher latency than single-node SQL (consensus overhead)
❌ More complex to operate than single-node PostgreSQL
❌ Expensive (Cloud Spanner starts at ~$0.90/node/hour)
```

## Migration Considerations

```
SQL → NoSQL migration:
───────────────────────
1. Identify query patterns: What queries need to be fast?
2. Design NoSQL schema around those queries (denormalize!)
3. Dual-write: Write to both SQL and NoSQL during transition.
4. Validate: Compare reads from both until confident.
5. Switch reads to NoSQL, then stop writing to SQL.

Common pitfalls:
  ❌ Porting SQL schema directly to NoSQL — you lose all benefits.
  ❌ Forgetting about transactions — losing ACID silently causes bugs.
  ❌ Underestimating complexity of conflict resolution at scale.

NoSQL → SQL migration:
───────────────────────
Harder! Unstructured data must be normalized.
Steps:
  1. Audit existing data — find schema inconsistencies.
  2. Define SQL schema.
  3. Write migration script to transform documents to rows.
  4. Handle missing/null fields.
  5. Add constraints carefully (existing bad data will fail).

Polyglot persistence (realistic approach):
───────────────────────────────────────────
Most mature systems use multiple databases:
  PostgreSQL: core business data (users, orders, inventory)
  Redis:      caching, sessions, rate limiting
  Elasticsearch: full-text search
  Cassandra:  event log, analytics events
  (optional) Neo4j: recommendations

Each database does what it's best at.
```

## Comprehensive Comparison Table

| | **PostgreSQL** | **MongoDB** | **Cassandra** | **Redis** |
|---|---|---|---|---|
| **Type** | Relational (SQL) | Document | Wide-Column | Key-Value |
| **ACID** | Full ACID | Multi-doc ACID (v4+) | Eventual (tunable) | Single-op atomic |
| **Schema** | Strict | Flexible | Flexible columns | None |
| **Joins** | Excellent | Limited ($lookup) | None | None |
| **Horizontal scale** | Hard (sharding complex) | Moderate | Excellent | Good |
| **Write throughput** | Moderate | High | Very high | Extreme |
| **Read throughput** | High | High | Moderate | Extreme |
| **Query flexibility** | Highest (any SQL) | Good (aggregation pipeline) | Low (query = table design) | Minimal |
| **Data size sweet spot** | GB to ~1TB/node | GB to ~TB/node | TB to PB | GB (RAM-limited) |
| **Consistency** | Strong | Tunable | Tunable | Strong (single key) |
| **Best for** | OLTP, reporting, most apps | Catalogs, profiles, CMS | IoT, logs, time-series | Caching, sessions, queues |
| **Managed cloud** | RDS, Cloud SQL, Neon | Atlas | Astra, Amazon Keyspaces | ElastiCache, Upstash |

## Interview Tips

```
Common SQL vs NoSQL interview questions:
─────────────────────────────────────────

Q: "Should you use SQL or NoSQL for a social media app?"
A: Both. PostgreSQL for core data (users, posts, follows — ACID needed).
   Redis for caching feeds and sessions. Cassandra or DynamoDB for
   activity logs/notifications (high write volume). Search via
   Elasticsearch. It's polyglot persistence.

Q: "What is denormalization and when do you use it?"
A: Storing redundant data to avoid joins. Used in NoSQL because joins
   are not supported, and in SQL when join performance becomes a
   bottleneck at extreme scale. Trade-off: faster reads, harder writes
   (must update all copies when data changes).

Q: "What is eventual consistency and which databases use it?"
A: Replicas converge to the same value over time, but reads may
   temporarily return stale data. Used by DynamoDB (default),
   Cassandra (default), Redis (async replication). Acceptable for
   social feeds, shopping carts; unacceptable for bank balances.

Q: "How does Cassandra scale horizontally?"
A: Data is hash-partitioned across nodes using consistent hashing.
   The partition key determines which node owns each row.
   Adding nodes redistributes data automatically (vnodes).
   All nodes are equal (masterless) — no single point of failure.
   Replication factor (e.g., 3) copies each partition to 3 nodes.

Q: "What is NewSQL?"
A: Databases that combine SQL's ACID guarantees with NoSQL's
   horizontal scalability. CockroachDB, TiDB, Google Spanner.
   Use distributed consensus (Raft/Paxos) to maintain consistency
   across shards. Higher latency than single-node SQL, but scales
   to petabytes while preserving transactions.
```

## Practice Exercise

**Design the database stack for a ride-sharing app (like Uber)**

```
Requirements:
─────────────
- User accounts and driver profiles
- Real-time driver location (GPS, every 4 seconds per driver)
- Ride matching and booking (must not double-book a driver)
- Trip history for users
- Surge pricing calculation (count of active drivers/riders per zone)
- Driver earnings and payouts (financial data)
- Reviews and ratings

Design the database choices.
```

<details>
<summary>Solution (Click to Expand)</summary>

```
PostgreSQL (core relational data):
───────────────────────────────────
- users, drivers, vehicles tables
- rides table (booking must be ACID — no double-booking)
- payments, earnings, payouts (financial = must be ACID)
- reviews, ratings
- Use transactions for ride state machine (requested → accepted → completed)

Redis:
──────
- Driver sessions and auth tokens (TTL = auto-expire)
- Rate limiting (prevent abuse of booking endpoint)
- Pub/Sub for real-time ride status updates to client
- Short-TTL cache for surge pricing zones (recompute every 30s)

Cassandra / DynamoDB:
──────────────────────
- Driver location history:
    partition_key = driver_id, clustering_key = timestamp
    Billions of rows. Cassandra handles this perfectly.
    TTL data after 30 days (Cassandra has built-in TTL per row).

- Trip event log:
    Every state change of every trip (for audit, debugging, analytics).
    Append-only, massive scale.

Elasticsearch:
──────────────
- Driver search by geo (find drivers near pickup location)
- Actually: Redis Geo commands or PostGIS (PostgreSQL extension)
  might be simpler for this use case.

Geospatial:
────────────
- PostGIS extension on PostgreSQL
- Or Redis GEO commands (GEOADD, GEORADIUS)
  Simple enough for finding nearby drivers.

Summary:
─────────
PostgreSQL: users, rides, payments, reviews
Redis:      sessions, caching, pub/sub, geo search
Cassandra:  location history, event logs
```

</details>

## Summary

- **SQL** (PostgreSQL, MySQL) remains the right default for most applications — ACID, flexible queries, joins
- **Key-Value** stores (Redis) are for caching, sessions, and sub-millisecond lookups — complement SQL, not replace
- **Document stores** (MongoDB) suit flexible-schema data like catalogs, profiles, and CMS content
- **Wide-column** stores (Cassandra) handle write-heavy, time-series and IoT workloads at massive scale
- **Graph databases** (Neo4j) shine for relationship traversal — social graphs, recommendations, fraud detection
- **NewSQL** (CockroachDB, Spanner) brings horizontal scaling to ACID transactions — complex but powerful
- **Polyglot persistence** — most production systems combine multiple database types
- **Denormalization** is the key NoSQL data modeling pattern — design tables around queries, not entities
- **Don't prematurely switch** to NoSQL — PostgreSQL scales further than most people expect

---

**Key Takeaway**: SQL vs NoSQL is not about which is "better" — it's about matching the data model and consistency requirements to your specific access patterns. When in doubt, start with PostgreSQL. Add specialized databases only when you have a proven need.
