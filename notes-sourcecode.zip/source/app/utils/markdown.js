const path = require('path');
const MarkdownIt = require('markdown-it');
const taskLists = require('markdown-it-task-lists');
const mdAnchor = require('markdown-it-anchor');
const hljs = require('highlight.js');
const { CONTENT_ROOT } = require('../config');

// --- Markdown Configuration ---

const markdownConfig = {
  html: true,
  linkify: true,
  typographer: true,
  highlight(str, lang) {
    if (lang && hljs.getLanguage(lang)) {
      try {
        return `<pre class="hljs"><code class="language-${lang}">${hljs.highlight(str, { language: lang }).value}</code></pre>`;
      } catch (_) { }
    }
    const md = new MarkdownIt();
    const className = lang ? ` class="language-${lang}"` : '';
    return `<pre class="hljs"><code${className}>${md.utils.escapeHtml(str)}</code></pre>`;
  },
};

// Custom plugin: rewrite relative .md links to absolute app URLs
function rewriteLinks(currentDir) {
  return function linkRewritePlugin(mdInstance) {
    const defaultRender = mdInstance.renderer.rules.link_open ||
      function (tokens, idx, options, env, self) {
        return self.renderToken(tokens, idx, options);
      };

    mdInstance.renderer.rules.link_open = function (tokens, idx, options, env, self) {
      const hrefIdx = tokens[idx].attrIndex('href');
      if (hrefIdx >= 0) {
        let href = tokens[idx].attrs[hrefIdx][1];

        // Only rewrite relative links (not http://, mailto:, #anchors, etc.)
        if (href && !href.match(/^(https?:|mailto:|#)/) && !href.startsWith('/')) {
          // Resolve relative to current file's directory
          const resolved = path.posix.normalize(path.posix.join(currentDir, href));

          // If it ends with .md, keep it; if it ends with /, it'll be handled by the directory route
          tokens[idx].attrs[hrefIdx][1] = '/' + resolved;
        }
      }
      return defaultRender(tokens, idx, options, env, self);
    };
  };
}

/**
 * Renders markdown content with link rewriting for the current file
 * @param {string} content - Markdown content to render
 * @param {string} filePath - Absolute path to the file being rendered
 * @returns {string} Rendered HTML
 */
function renderMarkdown(content, filePath) {
  // Get the directory of the current file relative to CONTENT_ROOT
  const relDir = path.relative(CONTENT_ROOT, path.dirname(filePath)).replace(/\\/g, '/');

  // Create a new instance with the link rewriter for this specific file
  const renderer = new MarkdownIt(markdownConfig);
  renderer.use(taskLists, { enabled: true });
  renderer.use(mdAnchor, {
    permalink: mdAnchor.permalink.ariaHidden({
      placement: 'before',
      class: 'header-anchor',
      symbol: '#'
    })
  });
  renderer.use(rewriteLinks(relDir));

  return renderer.render(content);
}

/**
 * Strips markdown formatting from text
 * @param {string} text - Markdown text
 * @returns {string} Plain text
 */
function stripMarkdown(text) {
  return text
    .replace(/```[\s\S]*?```/g, ' ')           // remove fenced code blocks
    .replace(/`[^`\n]+`/g, ' ')                 // remove inline code
    .replace(/^---[\s\S]*?---/m, '')             // remove frontmatter
    .replace(/!\[.*?\]\(.*?\)/g, '')             // remove images
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')    // links → text
    .replace(/^#{1,6}\s+/gm, '')                // remove heading markers
    .replace(/[*_~>|\\]/g, ' ')                 // remove markdown symbols
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extracts headings from markdown text
 * @param {string} text - Markdown text
 * @returns {string[]} Array of heading text
 */
function extractHeadings(text) {
  const matches = text.match(/^#{1,3}\s+(.+)$/gm) || [];
  return matches.map(h => h.replace(/^#+\s+/, '').trim());
}

module.exports = {
  renderMarkdown,
  stripMarkdown,
  extractHeadings,
};
