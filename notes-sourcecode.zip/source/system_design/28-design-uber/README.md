# Case Study: Design Uber

## Scale and Context

```
Uber by the numbers (2024):
─────────────────────────────
Monthly trips:       2 billion+ (peak years)
Monthly active users: 137 million riders and drivers
Cities:              10,000+ cities in 70+ countries
Location updates:    Drivers send GPS ping every 5 seconds
Peak QPS (matching): 100,000+ match requests/sec
Driver locations tracked: 5+ million active drivers
Latency target:      Match driver to rider in < 5 seconds
```

## Functional Requirements

```
Core features to design:
─────────────────────────
1. Request a ride
   ├─ Rider opens app, sees nearby drivers on map
   ├─ Rider requests pickup
   └─ System matches rider to nearest available driver

2. Driver matching
   ├─ Find drivers within radius of rider
   ├─ Select best driver (distance, rating, driver preference)
   └─ Driver accepts/rejects (timeout → try next driver)

3. Real-time tracking
   ├─ Driver's location streamed to rider in real time
   ├─ ETA updates continuously
   └─ Route displayed on map

4. Fare calculation
   ├─ Base fare + time + distance
   ├─ Surge pricing: dynamic multiplier when supply < demand
   └─ Final fare shown before and after trip

5. Trip completion and payment
   ├─ End trip, calculate final fare
   └─ Charge stored payment method, send receipt

Non-functional requirements:
─────────────────────────────
├─ Low latency: driver match < 5s, location update < 1s on screen
├─ High availability: 99.99% (no one can get a ride if Uber is down)
├─ Consistency: fare calculation must be exact (financial)
├─ Scalability: handle city-level surge events (New Year's Eve)
└─ Geo-aware: all queries are inherently spatial
```

## Location Service: Geospatial Indexing

### The Core Problem

```
Naive approach:
  "Find all drivers within 5km of rider at (40.7128, -74.0060)"

SELECT driver_id, lat, lng FROM drivers
WHERE lat BETWEEN 40.668 AND 40.757
  AND lng BETWEEN -74.069 AND -73.943;

Problems:
├─ Full table scan if no index
├─ 2D index (lat, lng) doesn't compress well
└─ Can't shard by lat/lng easily
```

### Geohash

```
Geohash converts 2D coordinates into a 1D string:

New York City: 40.7128° N, 74.0060° W
Geohash: "dr5ru"  (5 characters = ~5km × 5km cell)
         "dr5ruj" (6 characters = ~1.2km × 0.6km cell)
         "dr5rujn" (7 characters = ~150m × 150m cell)

Key property: nearby locations share a prefix!
  Times Square: "dr5ruj"
  Central Park:  "dr5ru7"
  Both start with "dr5ru" → same 5km cell

How Uber uses it:
──────────────────
1. Divide city into geohash cells (precision 6 = ~1km²)
2. Index drivers by their current geohash
3. To find nearby drivers:
   ├─ Hash rider's location → "dr5ruj"
   ├─ Get 8 surrounding cells (neighbors of "dr5ruj")
   └─ Query: SELECT drivers WHERE geohash IN ('dr5ruj',
               'dr5ruh', 'dr5run', ...) -- 9 cells total

Geohash precision guide:
  Precision 4:  ~40km × 20km
  Precision 5:  ~5km × 5km
  Precision 6:  ~1.2km × 0.6km  ← good for Uber matching
  Precision 7:  ~150m × 150m
```

### Geohash Grid for Location Search

```mermaid
flowchart TD
    RIDER[Rider Location\n40.7128, -74.0060] -->|hash| HASH[Geohash: dr5ruj\nPrecision 6]
    HASH --> NEIGHBORS[Calculate 8\nNeighbor Cells]
    NEIGHBORS --> CELLS["Search cells:\ndr5ruj, dr5ruh, dr5run,\ndr5rum, dr5rue, dr5ruv,\ndr5ruq, dr5rut, dr5ruK"]
    CELLS --> QUERY[Query Driver Index\nWHERE geohash IN ...]
    QUERY --> NEARBY[Nearby Drivers\nList with distance]
    NEARBY --> RANK[Rank by:\nDistance + Rating\n+ Acceptance Rate]
    RANK --> MATCH[Best Matched\nDriver]

    style RIDER fill:#374151,color:#fff
    style HASH fill:#7c3aed,color:#fff
    style NEIGHBORS fill:#7c3aed,color:#fff
    style CELLS fill:#2563eb,color:#fff
    style QUERY fill:#2563eb,color:#fff
    style NEARBY fill:#059669,color:#fff
    style RANK fill:#059669,color:#fff
    style MATCH fill:#059669,color:#fff
```

### Quadtree (Alternative to Geohash)

```
Quadtree: recursively subdivides 2D space into 4 quadrants

Level 0: [entire world]
Level 1: [NW] [NE] [SW] [SE]
Level 2: Each quadrant divided again into 4
...

Uber uses quadtrees for:
  ├─ Areas with very uneven driver density:
  │   Dense city (Manhattan): subdivide to level 15
  │   Rural area: only subdivide to level 8
  └─ Dynamic re-partitioning as density changes

Geohash vs Quadtree:
  Geohash:   fixed grid size, simple, good for uniform density
  Quadtree:  adaptive, better for uneven density, more complex
```

## Driver Location Storage

```
Requirements:
  ├─ 5 million active drivers
  ├─ Each sends GPS update every 5 seconds
  ├─ Write rate: 5M / 5s = 1,000,000 writes/sec!
  ├─ Each write: { driver_id, lat, lng, timestamp, geohash }
  └─ Read: find drivers in a set of geohash cells (< 100ms)

Storage choice: Redis with Geospatial index

Redis GEO commands:
  # Driver sends location update
  GEOADD drivers:active 74.0060 40.7128 "driver:456"

  # Find all drivers within 5km of a point
  GEORADIUS drivers:active -74.0060 40.7128 5 km

Redis advantages for location:
  ✅ Sub-millisecond reads
  ✅ Native GEO commands (radius search, distance)
  ✅ High write throughput
  ✅ In-memory: no disk I/O on critical path
  ❌ Not durable: if Redis crashes, recent location lost
     (OK: driver sends new update in 5 seconds anyway)

Architecture:
  ├─ Redis cluster sharded by city or geohash prefix
  ├─ Location updates also written to Kafka (async)
  └─ Kafka → Cassandra for trip history and analytics
```

## Ride Request Flow

```mermaid
sequenceDiagram
    participant R as Rider App
    participant AG as API Gateway
    participant RS as Ride Service
    participant LS as Location Service
    participant MS as Match Service
    participant D as Driver App
    participant N as Notification Service

    R->>AG: POST /rides {pickup: ..., dropoff: ...}
    AG->>RS: Create ride request
    RS->>RS: Validate request, calculate estimate
    RS->>LS: Get nearby drivers (geohash search)
    LS-->>RS: [driver:456, driver:789, ...] sorted by distance

    loop For each candidate driver (timeout 30s)
        RS->>MS: Attempt match with driver:456
        MS->>N: Push notification to driver:456
        N->>D: "New ride request nearby"

        alt Driver accepts (within 15s)
            D->>AG: PATCH /rides/{rideId}/accept
            AG->>RS: Driver accepted
            RS-->>R: Driver matched! ETA: 4 min
            Note over R,D: Ride begins
        else Driver rejects or timeout
            RS->>MS: Try next driver (driver:789)
        end
    end

    alt No driver found after 30s
        RS-->>R: No drivers available. Try again.
    end
```

## Real-Time Tracking: WebSockets

```
Problem: Show driver's location moving on rider's map in real time

Options:
  Short polling (bad):
    Rider app: GET /driver/456/location every 2s
    ├─ 10 million riders × 1 req/2s = 5M req/s
    └─ Mostly wasted (no new data most of the time)

  Long polling (ok):
    Rider holds connection open; server responds when data changes
    ├─ Better: only responds when location actually changes
    └─ But: still creates new connection per response

  WebSockets (best):
    ├─ Persistent bidirectional connection
    ├─ Server pushes updates when available
    ├─ Much less overhead than HTTP per message
    └─ Ideal for real-time location

WebSocket flow:
───────────────
1. Rider opens app → WebSocket connection to Location Streaming Service
2. Driver sends GPS update → Location Service
3. Location Service publishes to Kafka topic: "location.driver.456"
4. Location Streaming Service subscribes to Kafka topic
5. Streams new location to all riders watching that driver

Scaling WebSocket servers:
  ├─ Sticky sessions: rider always connects to same WS server
  ├─ Or: Pub/Sub via Redis to fan out to all WS servers
  └─ Horizontal scaling: more riders = more WS server instances
```

## Surge Pricing

```
Dynamic pricing = base fare × surge multiplier

When does surge happen?
  ├─ Demand (ride requests) >> Supply (available drivers)
  └─ Common: concerts, storms, New Year's Eve, rush hour

How it's calculated:
  surge_multiplier = f(demand / supply)

  demand/supply ratio → multiplier
  1.0 – 1.5          → 1.0x (no surge)
  1.5 – 2.0          → 1.5x
  2.0 – 3.0          → 2.0x
  3.0+               → 2.5x (cap)

Per-geohash surge:
  Each geohash cell (1km²) has its own surge multiplier
  Times Square may be 2.5x while Central Park is 1.0x

Supply/demand calculation:
  Every 30 seconds:
    FOR each active geohash cell:
      demand = count(ride_requests last 5min)
      supply = count(available_drivers in cell)
      ratio  = demand / supply
      surge  = lookup_surge_table(ratio)
      store in Redis: surge:{geohash} = 2.5

Transparency (regulations):
  ├─ Show surge multiplier before rider confirms
  ├─ Allow opt-out (cancel if too expensive)
  └─ Some cities cap maximum surge multiplier
```

## Fare Calculation

```
Trip fare formula:
──────────────────
fare = base_fare
     + (per_km_rate × distance_km)
     + (per_min_rate × duration_min)
     + surge_multiplier
     + tolls
     - promotions

Distance calculation:
  ├─ GPS track from driver during trip
  ├─ Polyline snapped to road network (map matching)
  └─ Haversine formula: great-circle distance between GPS points

Precision matters:
  ├─ Financial calculation: use integer cents, not floating point
  └─ 2.50 + 1.80 = 4.30 in cents: 250 + 180 = 430 ✅
     (never: 2.50 + 1.80 = 4.299999999 as float ❌)

Fare stored in:
  ├─ Trip table (MySQL / PostgreSQL for ACID)
  └─ Also events to Kafka for analytics
```

## Payment: Async Processing with Idempotency

```
Problem: Charge rider after trip ends

Naive approach (dangerous):
  POST /charge {amount: 1250, card: "tok_xxx"}
  → Network timeout → did charge go through?
  → Retry → charge twice!

Solution: Idempotency keys
  POST /charge
  Headers: Idempotency-Key: trip-456-v1
  Body: {amount: 1250, card: "tok_xxx"}

Server behavior:
  First call:
    ├─ Store: idempotency_key="trip-456-v1" → charging
    ├─ Call Stripe
    └─ Store result: → "charged $12.50"

  Duplicate call (same key):
    ├─ Found "trip-456-v1" → already charged
    └─ Return stored result (don't charge again!)

Async payment flow:
  1. Trip ends → emit TripCompleted event to Kafka
  2. Payment Worker consumes event
  3. Payment Worker calls Stripe with idempotency key
  4. On success → emit PaymentSucceeded to Kafka
  5. Email Service sends receipt
  6. Accounting Service records revenue

Benefits of async:
  ├─ Trip end is instant for rider (don't wait for payment)
  ├─ Payment can retry on failure independently
  └─ Failures don't block other trips
```

## System Architecture

```mermaid
flowchart TD
    subgraph CLIENTS ["Client Apps"]
        RIDER[Rider App]
        DRIVER[Driver App]
    end

    subgraph GATEWAY ["API Layer"]
        AG[API Gateway\nAuth + Rate Limiting]
    end

    subgraph SERVICES ["Core Services"]
        RIDE[Ride Service\nTrip lifecycle]
        LOCATION[Location Service\nGeohash + Redis]
        MATCH[Match Service\nDriver selection]
        PRICE[Pricing Service\nSurge + Fare]
        NOTIF[Notification\nService]
        PAYMENT[Payment\nService]
        STREAM[Location Streaming\nWebSocket Service]
    end

    subgraph STORAGE ["Storage Layer"]
        REDIS[(Redis\nLive locations)]
        MYSQL[(MySQL\nTrips + Users)]
        CASS[(Cassandra\nLocation history)]
        KAFKA[Kafka\nEvent stream]
    end

    RIDER -->|HTTPS| AG
    DRIVER -->|HTTPS| AG
    RIDER -->|WebSocket| STREAM

    AG --> RIDE
    AG --> LOCATION
    AG --> PRICE
    AG --> PAYMENT

    RIDE --> MATCH
    RIDE --> PRICE
    RIDE --> KAFKA

    MATCH --> LOCATION
    MATCH --> NOTIF

    LOCATION --> REDIS
    LOCATION --> KAFKA

    STREAM --> KAFKA

    KAFKA --> CASS
    KAFKA --> PAYMENT

    RIDE --> MYSQL
    PAYMENT --> MYSQL

    style RIDER fill:#374151,color:#fff
    style DRIVER fill:#374151,color:#fff
    style AG fill:#7c3aed,color:#fff
    style RIDE fill:#2563eb,color:#fff
    style LOCATION fill:#2563eb,color:#fff
    style MATCH fill:#2563eb,color:#fff
    style PRICE fill:#2563eb,color:#fff
    style NOTIF fill:#2563eb,color:#fff
    style PAYMENT fill:#2563eb,color:#fff
    style STREAM fill:#2563eb,color:#fff
    style REDIS fill:#059669,color:#fff
    style MYSQL fill:#059669,color:#fff
    style CASS fill:#059669,color:#fff
    style KAFKA fill:#f59e0b,color:#fff
```

## Trip Data and Analytics

```
Every event in a trip is streamed to Kafka:
  ├─ RideRequested
  ├─ DriverMatched
  ├─ DriverEnRoute
  ├─ PickupCompleted
  ├─ TripStarted
  ├─ TripCompleted
  └─ PaymentProcessed

Kafka consumers:
  ├─ Cassandra: store full location history (GPS trail)
  ├─ Spark Streaming: real-time city-level supply/demand heatmap
  ├─ Data Lake (S3): analytics, ML training data
  └─ Fraud detection: flag unusual patterns in real time

Analytics use cases:
  ├─ Surge pricing calibration
  ├─ Driver supply forecasting (will there be enough drivers at 5PM?)
  ├─ Route optimization for drivers
  └─ City operations: where to incentivize driver supply
```

## Interview: Design Discussion Points

**Q: How do you handle the location service at 1M writes/sec?**

```
Sharding strategy:
  Shard Redis by geohash prefix (first 2 chars):
  dr → Redis cluster 1 (eastern US)
  9q → Redis cluster 2 (western US)
  u1 → Redis cluster 3 (Europe)

  Each cluster handles ~100K writes/sec
  (manageable for Redis with replication)

Write path:
  Driver app → Load Balancer → Location API servers (stateless)
  Location API servers → Consistent hash → Correct Redis shard
  (no hot spots; drivers spread across geohash cells)
```

**Q: What happens if the Match Service is down?**

```
Ride requests are stored in Kafka first:
  POST /ride → Ride Service → Kafka (RideRequested event)
  Match Service consumes from Kafka

If Match Service restarts:
  ├─ Picks up from Kafka offset (no requests lost)
  ├─ Processes queued requests in order
  └─ Rider sees "Finding your driver..." (a few seconds delay)

Timeout handling:
  ├─ Rides have 30-second matching timeout in Kafka message
  ├─ Expired messages (unmatched after 30s) → "No driver found"
  └─ Rider is notified to retry
```

**Q: How do you prevent double-charging?**

```
Idempotency key = trip_id + attempt_number
  First attempt:   key = "trip-456-attempt-1"
  Retry on timeout: key = "trip-456-attempt-1" (same key!)

Stripe (or internal payment store) deduplicates by key.
Even if payment service crashes mid-charge, retry is safe.
```

## Summary

- **Geohash** converts 2D coordinates to a 1D string; nearby points share a prefix, enabling fast nearest-driver queries by geohash cell lookup
- **Redis GEO commands** store live driver locations in memory for sub-millisecond radius searches; handles 1M+ writes/sec with sharding by geohash prefix
- **WebSockets** push driver location updates to the rider app in real time without polling overhead
- **Surge pricing** is calculated per geohash cell every 30 seconds based on demand/supply ratio; stored in Redis and shown to rider before confirming
- **Idempotency keys** prevent double-charging: the same key returns the stored result instead of reprocessing the payment
- **Kafka** decouples the entire system: trip events fan out to matching, payment, analytics, and fraud detection services independently
- **Async matching**: ride requests published to Kafka, Match Service consumes and tries drivers sequentially until acceptance or 30-second timeout

## Next Steps

You have now covered the full system design curriculum. Review the [Interview Guide](../INTERVIEW_GUIDE.md) for a structured approach to system design interviews, or revisit the [Quick Reference](../QUICK_REFERENCE.md) for a condensed cheat sheet.

---

**Key Takeaway**: Uber's hardest problems are inherently spatial and real-time. Geohash makes 2D proximity queries tractable at scale. Kafka decouples every service so any component can fail and recover without losing a trip.
