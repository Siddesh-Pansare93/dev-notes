# Monitoring & Observability

## Why Observability?

```
Without monitoring:
────────────────────
User: "Your app is slow!"
Engineer: "Uh... let me SSH into the server..."

With monitoring:
─────────────────
Alert fires at 3AM: p99 latency > 2s for /checkout
Dashboard shows: DB connection pool exhausted
Logs show: "Too many connections" errors since 2:47AM
Trace shows: query taking 8s due to missing index
Engineer: Fixed in 10 minutes

The Three Pillars of Observability:
─────────────────────────────────────
Metrics  → "Is something wrong?"   (numbers over time)
Logs     → "What happened?"        (timestamped records)
Traces   → "Where did it go wrong?" (request path)
```

## The 4 Golden Signals

```
From Google's SRE book — the minimum you must monitor:

1. LATENCY — How long do requests take?
   ├─ p50 (median): typical user experience
   ├─ p95: 1 in 20 users has this experience
   ├─ p99: 1 in 100 users (often your worst customers!)
   └─ Always track percentiles, not averages!
      Average hides tail latency: [1ms, 1ms, 1ms, 400ms] → avg=100ms but p99=400ms

2. TRAFFIC — How much demand is the system receiving?
   ├─ Requests per second (RPS)
   ├─ Queries per second (QPS)
   └─ Bytes in/out per second

3. ERRORS — What fraction of requests are failing?
   ├─ HTTP 5xx error rate
   ├─ Application-level errors (not just HTTP)
   └─ Silent failures (wrong data, no error returned)

4. SATURATION — How "full" is the system?
   ├─ CPU utilization (alert at 80%, not 100%)
   ├─ Memory usage
   ├─ Disk I/O wait
   ├─ Connection pool usage
   └─ Queue depth / backlog length
```

## Metrics: Types and Uses

### Counter

```
Always increasing. Resets to 0 on restart.

Examples:
  http_requests_total{method="GET", status="200"}  → 1,482,392
  errors_total{type="timeout"}                      → 47

Use for:
  ├─ Request counts
  ├─ Error counts
  └─ Bytes processed

Rate calculation (per second over 5 min window):
  rate(http_requests_total[5m])  → 342 req/s
```

### Gauge

```
Can go up or down. Current value at a point in time.

Examples:
  active_connections           → 312
  memory_usage_bytes           → 2,147,483,648
  queue_depth{queue="orders"}  → 44

Use for:
  ├─ Current resource utilization
  ├─ Queue lengths
  └─ Active sessions
```

### Histogram

```
Samples observations and counts them in configurable buckets.

Example: http_request_duration_seconds
  bucket{le="0.1"}   → 8420   (requests ≤ 100ms)
  bucket{le="0.5"}   → 9812   (requests ≤ 500ms)
  bucket{le="1.0"}   → 9950   (requests ≤ 1s)
  bucket{le="+Inf"}  → 10000  (all requests)
  sum                → 1832.4 seconds
  count              → 10000 requests

Calculate p99:
  histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))

Use for:
  ├─ Request latency distributions
  ├─ Response sizes
  └─ Database query durations
```

### Summary

```
Similar to histogram but quantiles computed on the client side.

Example:
  rpc_duration_seconds{quantile="0.5"}   → 0.047
  rpc_duration_seconds{quantile="0.9"}   → 0.213
  rpc_duration_seconds{quantile="0.99"}  → 0.847

When to use summary vs histogram:
  Histogram:
  ✅ Aggregatable across instances (use this most of the time)
  ✅ Can calculate any quantile after the fact
  ❌ Less accurate at extremes

  Summary:
  ✅ More accurate for specific quantiles
  ❌ Cannot aggregate across instances
  ❌ Quantiles must be defined upfront
```

## Structured Logging

### JSON Logs

```
Unstructured (bad):
────────────────────
2024-01-15 10:23:41 ERROR Failed to process order 12345 for user alice@example.com

Problems:
├─ Hard to parse programmatically
├─ No consistent fields to query
└─ Can't filter by order ID easily

Structured JSON (good):
─────────────────────────
{
  "timestamp": "2024-01-15T10:23:41.123Z",
  "level": "error",
  "service": "order-service",
  "version": "2.4.1",
  "trace_id": "abc123def456",
  "span_id": "789xyz",
  "message": "Failed to process order",
  "order_id": "12345",
  "user_email": "alice@example.com",
  "error": "payment_declined",
  "duration_ms": 342
}

Benefits:
✅ Query by any field: level=error AND order_id=12345
✅ Aggregate: count errors by service
✅ Correlate: find all logs with trace_id=abc123
```

### Log Levels

```
TRACE  → Extremely detailed, rarely enabled in production
         "Entering function processPayment with args {...}"

DEBUG  → Developer debugging info
         "Cache miss for key user:123, querying database"

INFO   → Normal operational events
         "Order 12345 placed successfully"

WARN   → Something unexpected but not breaking
         "Retry attempt 2/3 for payment API"

ERROR  → An error occurred, request failed
         "Order 12345 failed: payment declined"

FATAL  → Service is crashing
         "Cannot connect to database, shutting down"

Production guideline:
  Default level: INFO
  Increase to DEBUG temporarily when investigating issues
  Never use TRACE in production
```

### Correlation IDs

```
Problem: Find all logs for one user request across 5 services

Solution: Generate a unique trace_id at the edge, pass it everywhere

Request enters API Gateway:
  trace_id = generate_uuid()  →  "abc-123-def-456"
  Add to header: X-Trace-ID: abc-123-def-456

Order Service receives request:
  trace_id = headers["X-Trace-ID"]
  log.info("Order created", trace_id=trace_id)
  → call Payment Service (pass trace_id in header)

Payment Service receives request:
  trace_id = headers["X-Trace-ID"]
  log.info("Payment processing", trace_id=trace_id)

Now query all logs: trace_id = "abc-123-def-456"
  → See full picture across every service!
```

## Distributed Tracing

### Spans and Traces

```
A TRACE is the full journey of one request across all services.
A SPAN is one unit of work within a trace.

Example: POST /orders

Trace abc-123:
──────────────
Span 1: API Gateway          [0ms ─────────────────── 450ms]
  Span 2: Order Service      [5ms ──────────────── 445ms]
    Span 3: Validate order   [5ms ──── 20ms]
    Span 4: DB: Insert order [25ms ──── 35ms]
    Span 5: Payment Service  [36ms ──────────── 420ms]
      Span 6: Stripe API     [40ms ────────── 415ms]  ← slow!
    Span 7: Kafka publish    [422ms ─── 430ms]

Waterfall diagram shows:
├─ Total request: 450ms
├─ Stripe API call: 375ms (83% of total time)
└─ Root cause found: Stripe latency spike
```

### Trace Context Propagation

```
W3C Trace Context standard (traceparent header):

traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
             │  │                                │                │
             │  trace-id (128-bit)               span-id (64-bit) flags

Each service:
1. Reads traceparent from incoming request
2. Creates a child span with new span-id
3. Passes traceparent forward to downstream calls
4. Sends span data to tracing backend (Jaeger/Zipkin)
```

### Jaeger vs Zipkin

```
Both are open-source distributed tracing systems:

Jaeger (CNCF project, Uber-origin):
✅ Better UI with flamegraph visualization
✅ Native Kubernetes support
✅ Scales to billions of spans
✅ OpenTelemetry native

Zipkin (Twitter-origin, older):
✅ Simpler to set up
✅ Smaller footprint
✅ Good community support

Modern recommendation:
  Use OpenTelemetry SDK in your app
  (vendor-neutral instrumentation)
  Send to Jaeger, Zipkin, or any backend
```

## Alerting: SLI / SLO / SLA

```
SLI (Service Level Indicator):
  A specific metric you measure.
  "The fraction of requests with latency < 200ms"
  "The fraction of requests that returned success (non-5xx)"

SLO (Service Level Objective):
  Your internal target for an SLI.
  "99% of requests should have latency < 200ms"
  "99.9% of requests should succeed"

SLA (Service Level Agreement):
  External contract with customers. Consequences if violated.
  "99.9% uptime per month or we issue credits"

Relationship:
  SLA ≥ SLO > SLI measurement

  SLA:  99.9% (external promise)
  SLO:  99.95% (internal target, some buffer)
  SLI:  actual measured value (e.g., 99.97%)
```

### Error Budgets

```
Error Budget = 1 - SLO

SLO = 99.9%  → Error budget = 0.1%

Monthly error budget:
  30 days × 24 hours × 60 minutes = 43,200 minutes
  0.1% of 43,200 = 43.2 minutes of allowed downtime per month

How error budgets guide decisions:
────────────────────────────────────
Budget remaining = 100%:
  ├─ Plenty of room to experiment
  └─ Ship risky features, run chaos tests

Budget at 50%:
  ├─ Slow down risky deploys
  └─ Prioritize reliability improvements

Budget at 0%:
  ├─ Feature freeze until next period
  ├─ All hands on reliability
  └─ No new releases until budget replenishes

Benefits:
✅ Aligns product (features) vs engineering (reliability)
✅ Makes risk tolerance objective, not political
✅ Incentivizes both reliability AND shipping
```

## Dashboard Design: RED Method

```
RED (per service, per endpoint):

R — Rate      : How many requests/sec is this service handling?
E — Errors    : How many of those requests are failing?
D — Duration  : How long do those requests take (p50/p95/p99)?

Example Grafana panel layout:
────────────────────────────────

┌─────────────────────────────────────────────┐
│  Order Service — Last 1 hour                │
├───────────────┬───────────────┬─────────────┤
│  Rate         │  Error Rate   │  Duration   │
│  342 req/s    │  0.12%        │  p50: 45ms  │
│  [graph]      │  [graph]      │  p99: 312ms │
│               │               │  [graph]    │
├───────────────┴───────────────┴─────────────┤
│  Saturation                                 │
│  CPU: 34%  Memory: 61%  DB Pool: 28/100     │
└─────────────────────────────────────────────┘

Add these panels for every service:
├─ Rate: rate(http_requests_total[1m])
├─ Errors: rate(http_requests_total{status=~"5.."}[1m]) / rate(http_requests_total[1m])
├─ p50: histogram_quantile(0.50, ...)
├─ p99: histogram_quantile(0.99, ...)
└─ CPU: process_cpu_seconds_total
```

## Open-Source Observability Stack

```
Prometheus + Grafana + Loki + Jaeger (PGLJ Stack):

Prometheus:
  ├─ Scrapes metrics from services via HTTP /metrics endpoint
  ├─ Stores time-series data
  ├─ PromQL for querying
  └─ Fires alerts via Alertmanager

Grafana:
  ├─ Dashboards: visualize Prometheus, Loki, Jaeger data
  ├─ Alerting: visual alert rules
  └─ Single pane of glass

Loki:
  ├─ Log aggregation (like Elasticsearch but cheaper)
  ├─ LogQL query language (similar to PromQL)
  └─ Integrates with Grafana natively

Jaeger:
  ├─ Distributed tracing backend
  ├─ Stores and queries spans
  └─ UI: service dependency map + trace waterfall
```

### Observability Pillars Flowchart

```mermaid
flowchart TD
    SVC[Your Service] -->|exposes /metrics| PROM[Prometheus\nMetrics Scraper]
    SVC -->|writes logs| PROMTAIL[Promtail\nLog Collector]
    SVC -->|sends spans| JAEGER[Jaeger\nTracing Backend]

    PROM --> GRAFANA[Grafana\nDashboards]
    PROMTAIL --> LOKI[Loki\nLog Store]
    LOKI --> GRAFANA
    JAEGER --> GRAFANA

    PROM --> ALERT[Alertmanager]
    ALERT -->|notify| ONCALL[PagerDuty\nSlack\nEmail]

    GRAFANA --> ENG[On-Call Engineer]
    ONCALL --> ENG

    style SVC fill:#374151,color:#fff
    style PROM fill:#2563eb,color:#fff
    style PROMTAIL fill:#2563eb,color:#fff
    style JAEGER fill:#2563eb,color:#fff
    style LOKI fill:#2563eb,color:#fff
    style GRAFANA fill:#7c3aed,color:#fff
    style ALERT fill:#f59e0b,color:#fff
    style ONCALL fill:#ef4444,color:#fff
    style ENG fill:#059669,color:#fff
```

### Alerting Pipeline

```mermaid
flowchart LR
    METRIC[Metric Crosses\nThreshold] --> PROM[Prometheus\nAlert Rule Fires]
    PROM -->|pending for 5m| ALERT[Alertmanager]
    ALERT --> ROUTE{Route\nby severity}
    ROUTE -->|critical| PAGE[PagerDuty\nPage On-Call]
    ROUTE -->|warning| SLACK[Slack\nChannel Alert]
    ROUTE -->|info| EMAIL[Email\nDigest]

    PAGE --> ONCALL[On-Call\nEngineer]
    SLACK --> ONCALL
    ONCALL --> RB[Open Runbook]
    RB --> ACK[Acknowledge\nAlert]
    ACK --> FIX[Investigate\n& Fix]
    FIX --> RESOLVE[Resolve\nAlert]

    style METRIC fill:#ef4444,color:#fff
    style PROM fill:#2563eb,color:#fff
    style ALERT fill:#f59e0b,color:#fff
    style ROUTE fill:#7c3aed,color:#fff
    style PAGE fill:#ef4444,color:#fff
    style SLACK fill:#f59e0b,color:#fff
    style EMAIL fill:#374151,color:#fff
    style ONCALL fill:#059669,color:#fff
    style RB fill:#059669,color:#fff
    style ACK fill:#059669,color:#fff
    style FIX fill:#059669,color:#fff
    style RESOLVE fill:#059669,color:#fff
```

## On-Call: Runbooks and Incident Response

### Runbooks

```
A runbook is a documented set of steps to diagnose and fix a specific alert.

Good runbook structure:
────────────────────────
# Alert: HighErrorRate — Order Service

## Summary
Error rate for /api/orders exceeded 1% for 5 minutes.

## Impact
Orders are failing. Revenue impact: ~$X/minute.

## Diagnosis Steps
1. Check Grafana: [link] — which endpoint has errors?
2. Check logs: [link to Loki query] — what error message?
3. Check recent deploys: git log --since=1h
4. Check DB connection pool: [link to dashboard]

## Remediation
If DB pool exhausted:
  → Scale up DB pool: kubectl set env deployment/order-service DB_POOL=50
If recent bad deploy:
  → Rollback: kubectl rollout undo deployment/order-service
If upstream API down:
  → Enable fallback mode: feature flag order_fallback=true

## Escalation
If not resolved in 30 minutes: page team lead
```

### Incident Response Process

```
Severity Levels:
─────────────────
SEV-1: Complete outage, all users affected
  ├─ Response: Immediate page, war room, all hands
  └─ Resolution target: 1 hour

SEV-2: Partial outage or severe degradation
  ├─ Response: Page on-call, start investigation
  └─ Resolution target: 4 hours

SEV-3: Minor impact, workaround available
  ├─ Response: Slack notification, fix next business day
  └─ Resolution target: 3 days

Incident timeline:
──────────────────
00:00 Alert fires
00:05 On-call acknowledges
00:10 Incident channel created, status page updated
00:15 Root cause identified (bad deploy)
00:20 Rollback initiated
00:25 Error rate returning to normal
00:30 Incident resolved, status page updated
00:45 Post-mortem scheduled

Post-Mortem (Blameless):
─────────────────────────
├─ What happened? (timeline)
├─ Why did it happen? (5 whys)
├─ What mitigated it?
├─ What can we improve? (action items with owners + deadlines)
└─ Share widely: learning opportunities for the whole team
```

## Prometheus Query Examples

```
# Request rate (req/s over last 5 minutes)
rate(http_requests_total[5m])

# Error rate (percentage)
100 * rate(http_requests_total{status=~"5.."}[5m])
    / rate(http_requests_total[5m])

# p99 latency
histogram_quantile(0.99,
  rate(http_request_duration_seconds_bucket[5m])
)

# CPU usage per pod
rate(container_cpu_usage_seconds_total[5m]) * 100

# Memory usage
container_memory_working_set_bytes / 1024 / 1024

# Alert: error rate > 1% for 5 minutes
alert: HighErrorRate
expr: |
  rate(http_requests_total{status=~"5.."}[5m])
  / rate(http_requests_total[5m]) > 0.01
for: 5m
labels:
  severity: critical
annotations:
  summary: "High error rate on {{ $labels.service }}"
```

## Summary

- **4 Golden Signals**: Latency, Traffic, Errors, Saturation — monitor all four for every service
- **Metrics types**: Counters (only go up), Gauges (current value), Histograms (distributions) — use histograms for latency
- **Structured logging**: JSON with trace IDs so logs are queryable and correlatable across services
- **Distributed tracing**: spans show exactly where time is spent in a multi-service request
- **SLI/SLO/SLA**: measure what matters, set internal targets with buffer above customer commitments
- **Error budgets**: data-driven way to balance feature shipping with reliability work
- **RED method**: Rate, Errors, Duration — the three panels every service dashboard needs
- **Stack**: Prometheus (metrics) + Grafana (dashboards) + Loki (logs) + Jaeger (traces) = full observability

## Next Steps

Continue to [Design Netflix](../27-design-netflix/README.md) to see how a real system at massive scale handles video delivery.

---

**Key Takeaway**: You can't fix what you can't see. Instrument everything from day one. Alerts should be actionable — every alert needs a runbook.
