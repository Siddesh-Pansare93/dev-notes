# Database Replication

## Why Replication?

```
Without Replication:
─────────────────────
Single database server:

  App → Database
            │
            └─ Disk failure → ALL DATA GONE
            └─ Server crash → Service down for hours
            └─ Heavy reads → Queries compete for same CPU
            └─ Maintenance → Must take downtime

With Replication:
──────────────────
Data copied to multiple servers:

  App → Primary DB ──replicates──► Replica 1
                   ──replicates──► Replica 2
                   ──replicates──► Replica 3

  ✅ Replica survives primary failure
  ✅ Reads spread across replicas
  ✅ Replica in another datacenter = disaster recovery
  ✅ Maintenance on replicas without downtime
```

Three core reasons to replicate:
1. **High Availability** — keep serving requests when a node fails
2. **Read Scaling** — distribute read load across replicas
3. **Disaster Recovery** — survive full datacenter outages

## Single-Leader (Primary-Replica) Replication

The most common model. One node accepts all writes; replicas receive a copy.

```
           ┌─────────────────────────────────────────┐
           │             Write Path                   │
           └─────────────────────────────────────────┘
                              │
App (write) ──────────► Primary (Leader)
                              │
               ┌──────────────┼──────────────┐
               │              │              │
               ▼              ▼              ▼
          Replica 1       Replica 2       Replica 3
               │
App (read) ────┘  (reads can go to any replica)
```

### Synchronous vs Asynchronous Replication

```
Synchronous Replication:
─────────────────────────
App → Primary: "Write data X"
Primary → Replica 1: "Write X"
Replica 1 → Primary: "Acknowledged" ← Primary waits for this
Primary → App: "Write successful"

✅ Replica is always up to date
✅ If primary dies, zero data loss
❌ Write latency = primary latency + replica latency
❌ If replica is slow/dead, primary BLOCKS!

Asynchronous Replication:
──────────────────────────
App → Primary: "Write data X"
Primary → App: "Write successful" ← Returns immediately
Primary → Replica 1: "Write X" (background, best-effort)

✅ Write latency = only primary latency
✅ Primary not blocked by replica issues
❌ Replica may be seconds/minutes behind
❌ If primary dies before replicating → data loss!

Semi-Synchronous (compromise):
──────────────────────────────
At least ONE replica must confirm before primary acknowledges.
- Primary waits for 1 replica (not all)
- Other replicas can lag
✅ At most one replica behind
✅ Lower latency than full-sync
✅ Tolerate losing primary with no data loss
```

### Replication Lag and Read-Your-Writes

```
Replication lag problem:
─────────────────────────
t=0: User updates profile photo (written to primary)
t=0: Primary replicates change to replicas (async, takes 1 second)
t=0.1: User immediately refreshes page
t=0.1: Read load-balanced to Replica 2
t=0.1: Replica 2 hasn't received update yet!
t=0.1: User sees old profile photo 😕

Solutions — Read-Your-Writes Consistency:
──────────────────────────────────────────
Option 1: Read your own writes from primary
  - After any write, next read goes to primary
  - All other reads can use replicas
  - ✅ User always sees their own writes
  - ❌ Primary gets extra read load

Option 2: Track write timestamp
  - Client stores timestamp of last write
  - Router sends reads to replicas only if replica is "caught up enough"
  - If replica is behind, route to primary
  - ✅ Better distribution   ❌ More complex

Option 3: Sticky routing per session
  - After a write, all reads in that session go to same replica
  - If that replica dies, fall back to primary
  - ✅ Simple   ❌ Limits replica balancing
```

```mermaid
sequenceDiagram
    participant App
    participant Primary
    participant Replica

    App->>Primary: WRITE: update user profile
    Primary-->>App: OK (write confirmed)
    Note over Primary,Replica: Async replication (1s lag)
    App->>Replica: READ: get user profile
    Replica-->>App: OLD data (not yet replicated!)
    Note over App: User sees stale profile 😕

    Note over Primary,Replica: After replication completes...
    App->>Replica: READ: get user profile
    Replica-->>App: NEW data (now in sync)
    Note over App: User sees correct profile ✅
```

## Multi-Leader Replication

Multiple nodes can accept writes simultaneously.

```
Use cases for multi-leader:
─────────────────────────────
1. Multi-datacenter (writes accepted locally in each DC)
2. Offline-capable apps (phone writes offline, syncs later)
3. Real-time collaborative editing (Google Docs style)

Setup:
──────
                US-East DC              EU-West DC
                ───────────             ──────────
  App (US)  →  Leader 1               Leader 2  ← App (EU)
                    │                      │
              Replica A             Replica B
                    │◄──────────────────►│
                    │  Replication both  │
                    │  directions        │
```

### Write Conflicts

```
The big problem with multi-leader: WRITE CONFLICTS

t=0: User A (US) sets title = "Hello"     → writes to Leader 1
t=0: User B (EU) sets title = "Bonjour"   → writes to Leader 2
t=1: Leaders sync — which value wins??

Conflict Resolution Strategies:
────────────────────────────────
1. Last-Write-Wins (LWW)
   - Attach timestamp to each write
   - Higher timestamp wins
   ✅ Simple
   ❌ Clock skew → wrong writes silently discarded
   ❌ Data loss!

2. Merge
   - Combine both values
   - "Hello / Bonjour"
   ✅ No data loss
   ❌ Not always meaningful

3. Explicit Conflict Presentation
   - Store both versions, show conflict to user
   - User decides which is correct
   ✅ No data loss, user in control
   ❌ Bad UX; not practical for most apps

4. CRDTs (Conflict-free Replicated Data Types)
   - Special data structures that merge deterministically
   - Examples: G-Counter, OR-Set, LWW-Register
   - Used in: Riak, Redis CRDT, collaborative editors
   ✅ Automatic, mathematically correct
   ❌ Only works for specific data structures
   ❌ Complex to implement
```

## Leaderless Replication

No single leader. Any node can accept reads and writes. Used in Dynamo-style systems.

```mermaid
graph TD
    App["Application"]

    N1["Node 1"]
    N2["Node 2"]
    N3["Node 3"]
    N4["Node 4"]
    N5["Node 5"]

    App -->|"Write to\nany 3 of 5\n(W=3)"| N1
    App -->|write| N2
    App -->|write| N3
    App -.->|not written| N4
    App -.->|not written| N5

    App -->|"Read from\nany 3 of 5\n(R=3)"| N2
    App -->|read| N3
    App -->|read| N4

    style App fill:#7c3aed,stroke:#5b21b6,color:#fff
    style N1 fill:#059669,stroke:#047857,color:#fff
    style N2 fill:#059669,stroke:#047857,color:#fff
    style N3 fill:#059669,stroke:#047857,color:#fff
    style N4 fill:#374151,stroke:#1f2937,color:#fff
    style N5 fill:#374151,stroke:#1f2937,color:#fff
```

### Quorum Reads and Writes

```
Quorum formula: R + W > N
──────────────────────────
N = total replica count
W = number of nodes that must confirm a write
R = number of nodes that must respond to a read

If R + W > N:
→ At least one node that served the read MUST have the latest write
→ Guaranteed to see up-to-date data

Example (N=5):
───────────────
W=3, R=3 → 3+3=6 > 5 ✅ Strong consistency
W=5, R=1 → 5+1=6 > 5 ✅ Writes expensive, reads cheap
W=1, R=5 → 1+5=6 > 5 ✅ Writes cheap, reads expensive
W=2, R=2 → 2+2=4 < 5 ❌ May read stale data

Tunable consistency:
─────────────────────
High consistency:  W=3, R=3  (slow but accurate)
High availability: W=1, R=1  (fast, eventually consistent)
Write optimized:   W=1, R=5  (fast writes, slow reads)
Read optimized:    W=5, R=1  (slow writes, fast reads)
```

### Sloppy Quorums and Hinted Handoff

```
What if some nodes are temporarily unreachable?

Strict quorum: FAIL the request (can't reach W/R nodes)

Sloppy quorum:
───────────────
Write to any available nodes, even if outside "home" set.
Tag those writes with "intended recipient."
When the home node comes back, transfer the data.
This transfer is called "hinted handoff."

✅ Higher availability (can write during partial failure)
❌ Weaker consistency (R + W > N no longer guaranteed)

Used by: Amazon Dynamo, Cassandra, Riak
```

## Failover

When the primary fails, a replica must be promoted.

```mermaid
graph TD
    subgraph normal["Normal Operation"]
        direction LR
        P1["Primary\n(healthy)"]
        R1["Replica 1"]
        R2["Replica 2"]
        P1 -->|replicate| R1
        P1 -->|replicate| R2
    end

    subgraph failed["Primary Fails"]
        direction LR
        PF["Primary\n(FAILED)"]
        RF1["Replica 1\n← PROMOTED"]
        RF2["Replica 2"]
        PF -. "no replication" .-> RF1
        RF1 -->|replicate| RF2
    end

    normal -->|"crash!"| failed

    style P1 fill:#059669,stroke:#047857,color:#fff
    style R1 fill:#374151,stroke:#1f2937,color:#fff
    style R2 fill:#374151,stroke:#1f2937,color:#fff
    style PF fill:#ef4444,stroke:#b91c1c,color:#fff
    style RF1 fill:#f59e0b,stroke:#d97706,color:#fff
    style RF2 fill:#374151,stroke:#1f2937,color:#fff
```

### Manual vs Automatic Failover

```
Manual Failover:
─────────────────
Human detects failure → Human runs promotion command
✅ No false positives (human confirms it's really dead)
✅ Can investigate before promoting
❌ Minutes to hours of downtime
❌ Requires on-call engineers at 3am

Automatic Failover:
────────────────────
Monitoring detects failure → System promotes replica automatically
✅ Fast recovery (seconds to minutes)
✅ No human required
❌ False positives (network blip triggers unnecessary failover)
❌ Risk of split-brain

Failover checklist:
────────────────────
1. Which replica is most up to date? (least lag)
2. Reconfigure replicas to follow new primary
3. Reconfigure app to point to new primary
4. If old primary comes back → don't let it think it's still primary!
```

### Split-Brain Problem

```
Split-brain: Two nodes both believe they are the primary

Scenario:
──────────
Primary and Replica lose network connection (not crashed!)
Primary: "Replica is dead. I'm still primary."
Replica: "Primary is dead. I'm the new primary."

Both accept writes independently.
Network recovers.
Two conflicting versions of truth → data corruption!

Prevention strategies:
───────────────────────
1. STONITH (Shoot The Other Node In The Head)
   - New primary sends "kill" signal to old primary
   - Ensures old primary is actually dead before proceeding
   - ✅ Works   ❌ Requires out-of-band control plane (IPMI, etc.)

2. Quorum / Consensus
   - Requires majority vote to become primary
   - With 3 nodes: need 2/3 votes
   - Isolated node (1/3) cannot become primary
   - Used by: etcd, ZooKeeper, Raft-based systems

3. Lease-based locking
   - Primary holds a time-limited lease
   - If lease expires (can't renew), stop accepting writes
   - New primary waits until lease would have expired + buffer
   - ✅ No coordination needed   ❌ Requires synchronized clocks
```

## Real Systems

### PostgreSQL Streaming Replication

```sql
-- On primary: configure replication
-- postgresql.conf
wal_level = replica
max_wal_senders = 5
synchronous_standby_names = 'replica1'  -- for sync replication

-- pg_hba.conf (allow replica connection)
host replication replicator 10.0.0.2/32 md5

-- On replica: configure recovery
-- postgresql.conf (PostgreSQL 12+)
primary_conninfo = 'host=10.0.0.1 port=5432 user=replicator password=secret'
recovery_target_timeline = 'latest'

-- Check replication lag
SELECT
  client_addr,
  state,
  sent_lsn,
  write_lsn,
  flush_lsn,
  replay_lsn,
  (sent_lsn - replay_lsn) AS replication_lag_bytes
FROM pg_stat_replication;
```

### MySQL Binary Log Replication

```sql
-- On primary
-- my.cnf
[mysqld]
log_bin = mysql-bin
server_id = 1
binlog_format = ROW  -- Row-based is safest

-- Create replication user
CREATE USER 'replicator'@'10.0.0.2' IDENTIFIED BY 'password';
GRANT REPLICATION SLAVE ON *.* TO 'replicator'@'10.0.0.2';

-- On replica
CHANGE MASTER TO
  MASTER_HOST='10.0.0.1',
  MASTER_USER='replicator',
  MASTER_PASSWORD='password',
  MASTER_LOG_FILE='mysql-bin.000001',
  MASTER_LOG_POS=4;

START SLAVE;
SHOW SLAVE STATUS\G  -- Check replication lag: Seconds_Behind_Master
```

### Cassandra Gossip Protocol

```
Cassandra uses leaderless replication with gossip:
───────────────────────────────────────────────────
- No single primary: all nodes are equal
- Gossip: each node periodically exchanges state with 3 random peers
- Within seconds, all nodes know the state of all other nodes

Replication factor (RF):
  RF=3 → each row stored on 3 nodes

Consistency levels (per query):
  ONE    — fastest, may be stale
  QUORUM — majority, balanced
  ALL    — slowest, always fresh
  LOCAL_QUORUM — quorum within local datacenter

-- Example CQL
CREATE TABLE users (
  user_id UUID PRIMARY KEY,
  name TEXT
) WITH replication = {'class': 'NetworkTopologyStrategy',
                       'us-east': 3, 'eu-west': 2};
```

## Replication Topologies

```
Primary-Replica (most common):
───────────────────────────────
        Primary
       /   |   \
  Rep1  Rep2  Rep3

Chain Replication:
───────────────────
Primary → Rep1 → Rep2 → Rep3
Write must travel full chain before acknowledging
✅ Consistent  ❌ Any failure halts chain

Star Topology:
───────────────
Rep1 ← Primary → Rep2
            ↓
           Rep3
Single primary fan-out, limited by primary's network bandwidth

Multi-primary (active-active):
───────────────────────────────
Primary1 ⟺ Primary2
   ↓           ↓
Rep1         Rep2
Both DCs accept writes, replicate to each other
```

## Trade-offs Summary

| Model | Write Availability | Consistency | Complexity | Data Loss Risk |
|---|---|---|---|---|
| Single-leader sync | Low (blocked by replica) | Strong | Low | None |
| Single-leader async | High | Eventual | Low | Possible |
| Single-leader semi-sync | Medium | Medium | Low | Minimal |
| Multi-leader | High | Weak (conflicts) | High | Possible |
| Leaderless (quorum) | High (tunable) | Tunable | Medium | Configurable |

## Interview Tips

```
Common interview questions on replication:

Q: "How does read scaling with replicas work? What's the catch?"
A:
  ✅ Route read traffic to replicas → reduces primary load
  ✅ Catch: replication lag → reads may be stale
  ✅ Solution: read-your-writes consistency, or cache

Q: "What is split-brain and how do you prevent it?"
A:
  ✅ Split-brain = two nodes both think they're primary
  ✅ Prevention: quorum-based leader election (need majority vote)
  ✅ Prevention: STONITH — forcibly kill old primary
  ✅ Prevention: Raft/Paxos consensus protocols

Q: "When would you use multi-leader replication?"
A:
  ✅ Multiple datacenters needing local write performance
  ✅ Offline clients that sync later (mobile apps)
  ✅ Collaborative editing (with CRDT for conflict resolution)
  ❌ Avoid for anything requiring strong consistency

Q: "Explain quorum reads/writes"
A:
  ✅ N replicas total, write to W, read from R
  ✅ If R + W > N, at least one read replica has the latest write
  ✅ Trade-off: increase W for durability, increase R for freshness
```

## Practice Exercise

**Design replication for a banking system**

```
Requirements:
- Zero data loss tolerance
- 99.99% availability (< 1 hour downtime/year)
- Reads: 100,000/sec, Writes: 10,000/sec
- Must work across 2 datacenters

Questions:
1. Single-leader or multi-leader? Why?
2. Synchronous or asynchronous? Why?
3. How do you handle failover?
4. How do you route reads without serving stale balances?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Single-leader replication
   ───────────────────────────
   ✅ Banking requires strong consistency
   ✅ Multi-leader write conflicts are unacceptable for money
   ✅ Each DC has its own primary, with cross-DC sync (sync-within-DC)

2. Semi-synchronous replication
   ──────────────────────────────
   ✅ At least one replica confirms before ACK
   ✅ Zero data loss (can survive primary crash)
   ✅ Acceptable write latency (not full-sync to all replicas)
   ✅ Async replication to secondary datacenter (with RPO trade-off)

3. Automatic failover with Raft consensus
   ─────────────────────────────────────
   ✅ etcd/ZooKeeper manages leader election
   ✅ Requires majority vote → prevents split-brain
   ✅ Application updates connection string via service discovery
   ✅ Old primary must be fenced before new primary accepts writes

4. Read routing for strong consistency
   ──────────────────────────────────
   ✅ Balance reads must go to primary (no stale data)
   ✅ Non-critical reads (transaction history) can go to replica
   ✅ Tag read queries by type; router directs accordingly
   ✅ Or: synchronous replication so replicas are always current
```

</details>

## Summary

- **Single-leader** is the most common model: one primary accepts writes, replicas replicate
- **Replication lag** causes stale reads — solve with read-your-writes consistency
- **Synchronous** = no data loss but slower writes; **asynchronous** = fast writes but data loss risk
- **Multi-leader** enables multi-DC writes but introduces write conflicts
- **Leaderless quorums** give tunable consistency — set R + W > N for strong guarantees
- **Split-brain** is the dangerous failure mode — prevent with quorum-based leader election

## Next Steps

Continue to [Microservices](../17-microservices/README.md) to learn how to decompose large systems into independently deployable services.

---

**Key Takeaway**: Replication is not a backup. Replication copies writes in real time — it also copies accidental deletes. Always maintain separate backups for disaster recovery.
