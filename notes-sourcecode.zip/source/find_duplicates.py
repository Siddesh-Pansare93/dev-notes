import re
import glob

files_with_both = []
for pattern in [
    "python/**/*.md",
    "typescript/**/*.md",
    "postgresql/**/*.md",
    "system_design/**/*.md",
]:
    for file in glob.glob(pattern, recursive=True):
        try:
            with open(file, "r", encoding="utf-8") as f:
                content = f.read()
                has_mermaid = "```mermaid" in content
                has_ascii = bool(re.search(r"^[\s]*[┌└├│→]", content, re.MULTILINE))
                if has_mermaid and has_ascii:
                    files_with_both.append(file)
        except Exception as e:
            pass

for f in sorted(set(files_with_both)):
    print(f)
