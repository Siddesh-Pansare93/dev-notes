# Horizontal vs Vertical Scaling

## What is Scaling?

Scaling is increasing system capacity to handle more users, data, or requests.

```
                    Load
                     │
        ┌────────────┼────────────┐
        │            │            │
    Small       Medium          Large
    (10K)      (100K)         (1M+)
    users      users           users
```

## Vertical Scaling (Scale Up)

**Make one server more powerful**

```mermaid
graph LR
    subgraph Before
    S1[Server<br/>2 CPU<br/>8 GB RAM]
    end
    
    subgraph After
    S2[Bigger Server<br/>64 CPU<br/>512 GB RAM]
    end
    
    Before --> |Upgrade Hardware| After
    
    style S1 fill:#1A1D28,stroke:#F5A623,stroke-width:1px
    style S2 fill:#1A1D28,stroke:#F5A623,stroke-width:2px
```

From: $100/month
To:   $1,000/month

### Vertical Scaling Pros & Cons

```
Pros:
─────
✅ Simple: Just upgrade the hardware
✅ No architectural changes: Existing code works
✅ Good for databases: Single server with big resources
✅ Lower latency: No network calls between servers

Cons:
─────
❌ Limited: Hardware has upper limits
❌ Expensive: Each step up costs exponentially more
❌ Single point of failure: One server failure = down
❌ Downtime: Need to restart server to upgrade
❌ Cost-inefficient: Can't utilize idle resources

Limits:
───────
- Max CPU: ~256 cores per server (expensive)
- Max RAM: ~1+ TB (rare, expensive)
- Max disk: ~100 TB (for data centers)
- Economics: Very expensive beyond certain point

When to use:
───────────
✅ Small systems (< 1M users)
✅ Databases (scale up first)
✅ Initial MVP (simpler)
❌ Not suitable for massive scale
```

**Real Example: Vertical Scaling**

```
Reddit 2005-2008:
─────────────────
Started with vertical scaling
Single powerful server
Paul Graham's essay effect (huge traffic spike)
Server couldn't handle it
Had to move to horizontal scaling

Lesson: Vertical scaling only works until it doesn't
```

## Horizontal Scaling (Scale Out)

**Add more servers**

```mermaid
graph LR
    subgraph Before
    S1[Server<br/>2 CPU, 8 GB]
    end
    
    subgraph After
    S2[Server 1<br/>2 CPU, 8 GB]
    S3[Server 2<br/>2 CPU, 8 GB]
    S4[Server 3<br/>2 CPU, 8 GB]
    end
    
    Before --> |Add Servers + Load Balancer| After
    
    style S1 fill:#1A1D28,stroke:#F5A623,stroke-width:1px
    style S2 fill:#1A1D28,stroke:#F5A623,stroke-width:1px
    style S3 fill:#1A1D28,stroke:#F5A623,stroke-width:1px
    style S4 fill:#1A1D28,stroke:#F5A623,stroke-width:1px
```

From: $100/month (1 server)
To:   $300/month (3 servers)

### Horizontal Scaling Pros & Cons

```
Pros:
─────
✅ Unlimited: Add as many servers as needed
✅ Cost-efficient: Use commodity hardware
✅ Redundancy: Server crashes don't take down system
✅ No downtime: Add servers without stopping service
✅ Geographic distribution: Servers in different regions
✅ Flexible: Add/remove servers dynamically

Cons:
─────
❌ Complex: Requires load balancer, caching, etc.
❌ Data consistency: Keeping data in sync is hard
❌ Operational overhead: More servers to manage
❌ Network overhead: Servers talking to each other
❌ Distributed system problems: Harder to debug
❌ Database bottleneck: Data layer still centralized

When to use:
───────────
✅ Large systems (> 1M users)
✅ Applications (easier to parallelize)
✅ Web services (stateless)
✅ Always for production systems
❌ Not good alone (database still bottleneck)
```

**Real Example: Horizontal Scaling**

```
Netflix Growth:
───────────────
- Started with few servers
- As users grew, added more servers
- Used load balancer to distribute traffic
- Now has thousands of servers across regions
- Can handle millions of concurrent users
- Saves money using commodity hardware

Key: Design application to be stateless
```

## The Scaling Journey

```
Stage 1: Vertical Scaling (0-10K users)
─────────────────────────────────────────
Database: Single server
App Servers: 1-2 servers
Cache: Simple in-memory cache
Load Balancer: Single point

Problems when hitting limits:
├─ Database becomes bottleneck
├─ Server can't get much bigger
└─ Need better architecture

Stage 2: Horizontal Application Scaling (10K-100K)
───────────────────────────────────────────────
Database: Single with replicas
App Servers: 5-10 servers
Cache: Redis cluster
Load Balancer: HA load balancer

Problems when hitting limits:
├─ Database writes still bottleneck
├─ Cross-server coordination hard
└─ Need to shard database

Stage 3: Database Sharding (100K-1M)
──────────────────────────────────────
Database: Sharded across multiple primaries
App Servers: 20-50 servers
Cache: Distributed cache
Message Queue: For async operations

Problems when hitting limits:
├─ Multiple databases = complex transactions
├─ Geographic latency issues
├─ Operational complexity high

Stage 4: Global Distribution (1M+)
──────────────────────────────────
Multiple regions with independent systems
CDN for static content
Geo-routing for users
Master-master replication (or eventual consistency)

Result: Can handle any scale
```

## Scaling Database

The hardest part of horizontal scaling is the database.

### Read Scaling (Easy)

```mermaid
graph TD
    WriteRequests(Write Requests) --> Primary[(Primary DB<br/>Master)]
    ReadRequests(Read Requests) --> LB{Load Balancer}
    
    Primary -.->|Async Replication| Replica1[(Read Replica 1)]
    Primary -.->|Async Replication| Replica2[(Read Replica 2)]
    Primary -.->|Async Replication| Replica3[(Read Replica 3)]
    
    LB --> Replica1
    LB --> Replica2
    LB --> Replica3
    
    style Primary fill:#C9580C,stroke:#B8520A,color:#fff
    style Replica1 fill:#1A1D28,stroke:#F5A623
    style Replica2 fill:#1A1D28,stroke:#F5A623
    style Replica3 fill:#1A1D28,stroke:#F5A623
```

Result:
───────
✅ 100 writes/sec (primary capacity)
✅ 10,000 reads/sec (across all replicas)
✅ Linear read scaling
```

### Write Scaling (Hard)

```
Option 1: Sharding
─────────────────
Original: 1 database, 1000 writes/sec

Sharded: 10 databases
├─ Database 0 (users 0-99K): 100 writes/sec
├─ Database 1 (users 100K-199K): 100 writes/sec
├─ ...
└─ Database 9 (users 900K-999K): 100 writes/sec

Total: 1000 writes/sec across 10 shards
Cost: ~10x more resources
Complexity: ⬆️⬆️⬆️

Option 2: Different Data Stores
────────────────────────────────
- Use NoSQL for high-write data (events, logs)
- Use SQL for transactional data
- Use in-memory store for hot data

Option 3: Write Batching
────────────────────────
Instead of:
├─ 1000 individual writes/sec

Do:
├─ Batch writes every 100ms
├─ Write batches in bulk
├─ ~100 writes/sec (but higher latency)
```

## Scaling Checklist

```
Before Scaling Up:
──────────────────
[ ] Have you measured bottlenecks? (Don't guess)
[ ] Is it CPU, Memory, Disk, or Network?
[ ] Is the database the bottleneck?
[ ] Can you optimize existing server?

Vertical Scaling Decision:
──────────────────────────
[ ] Cost/benefit makes sense?
[ ] Hardware limit reached?
[ ] Need lowest latency?

Horizontal Scaling Decision:
────────────────────────────
[ ] Application is stateless?
[ ] Database can handle it?
[ ] Load balancer in place?
[ ] Monitoring in place?

Database Scaling:
─────────────────
[ ] Read replicas for read scaling?
[ ] Sharding plan for write scaling?
[ ] Backup strategy in place?

General:
────────
[ ] Can you handle distributed system complexity?
[ ] Monitoring and alerting in place?
[ ] Auto-scaling configured?
```

## Real-World Examples

### Scaling Path of Twitter

```
2006: Single server
   ├─ Rails app
   └─ MySQL database

2007-2008: Horizontal scaling begins
   ├─ Multiple app servers
   ├─ Read replicas
   ├─ Memcached layer
   └─ Problems: Database still bottleneck

2009-2010: Database sharding
   ├─ Shard by user ID
   ├─ Multiple data centers
   ├─ Gizzard: Custom sharding framework
   └─ Cassandra: For time-series data

2011+: Microservices
   ├─ Timeline service
   ├─ Favorites service
   ├─ Tweet storage service
   └─ Can handle billions of tweets
```

### Scaling Path of Uber

```
2010: MVP
   ├─ Simple web server
   └─ PostgreSQL

2012: Early growth (50K users)
   ├─ Multiple app servers
   ├─ Read replicas
   ├─ Caching layer
   └─ Issues: Location queries slow

2013: Geospatial scaling
   ├─ S2 Geometry library
   ├─ Custom sharding by location
   ├─ Redis for hot data
   └─ Can query drivers nearby efficiently

2015+: Microservices
   ├─ Trip service
   ├─ Matching service
   ├─ Payment service
   ├─ Notification service
   └─ Running at massive scale
```

## Practice Exercise

**Design Scaling Strategy**

You have a web app with current metrics:
```
- 50,000 DAU
- 100 concurrent users
- 1,000 requests/second at peak
- 1 TB database
- Growing 20% month-over-month
```

Questions:
```
1. Is single server enough now?
2. How long until vertical scaling maxes out?
3. When do you need horizontal scaling?
4. When do you shard the database?
5. What's infrastructure after 1 year of growth?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Single server capacity:
   ─────────────────────
   Modern server: 50,000 requests/sec possible
   ✅ 1,000 requests/sec is easy
   ✅ 1 TB storage is manageable
   ✅ Single server sufficient now

2. Vertical scaling limit:
   ──────────────────────
   Growth: 20% per month
   Month 0: 1K req/sec
   Month 6: 1K × 1.2^6 ≈ 2.9K req/sec
   Month 12: 1K × 1.2^12 ≈ 8.9K req/sec
   Month 18: 1K × 1.2^18 ≈ 26K req/sec
   Month 24: 1K × 1.2^24 ≈ 80K req/sec

   Max single server: 50K req/sec
   ✅ Can handle up to month 22
   ❌ After 22 months, need scaling

3. When to scale horizontally:
   ───────────────────────────
   Month 20: Prepare horizontal scaling
   Month 22: Deploy second server
   Month 24: Have 4 servers
   Month 26: Have 8 servers

4. When to shard database:
   ──────────────────────
   Single database handles: 100K req/sec (writes)
   Don't need sharding yet (only 80K peak)

   But with 20% growth:
   Month 36: 80K × 1.2^12 = 2.4M req/sec
   At month 28-30, need sharding

5. Infrastructure after 1 year:
   ───────────────────────────
   Month 12 (1 year later):
   ├─ App Servers: 5-10 (horizontal scaling)
   ├─ Database: Single primary with 2 read replicas
   ├─ Cache: Redis cluster
   ├─ Load Balancer: HA setup
   ├─ CDN: For static assets
   └─ Monitoring: Full observability

   Estimated cost: $5-10K/month

   Path forward (months 12-24):
   ├─ Continue horizontal scaling
   ├─ Add database sharding around month 28
   ├─ Introduce message queues for async tasks
   └─ Plan microservices transition
```

</details>

## Summary

- **Vertical scaling first**: Simpler, cheaper for small systems
- **Know the limits**: Can only upgrade hardware so much
- **Horizontal scaling needed for large systems**: Add more servers
- **Database is the hard part**: Think about sharding early
- **Monitor continuously**: Know when to scale

## Next Steps

Continue to [Load Balancing](../10-load-balancing/README.md) to learn how to distribute load.

---

**Key Takeaway**: Scale horizontally when possible, but understand the complexity it introduces. The database is usually the bottleneck.
