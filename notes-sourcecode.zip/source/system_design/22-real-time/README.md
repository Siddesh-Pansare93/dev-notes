# Real-Time Communication

## The Problem with Regular HTTP

```
Traditional HTTP (Request-Response):
──────────────────────────────────────
Client:  "Any new messages?"  →  Server: "No"
Client:  "Any new messages?"  →  Server: "No"
Client:  "Any new messages?"  →  Server: "No"
Client:  "Any new messages?"  →  Server: "No"
Client:  "Any new messages?"  →  Server: "YES! Here's 1 message"
Client:  "Any new messages?"  →  Server: "No"

Problems:
❌ 99% of requests are wasted
❌ Notifications delayed by poll interval
❌ Server load scales with poll frequency
❌ Network bandwidth wasted
```

Real-time systems need the server to **push** data to clients the moment it arrives.

## Real-Time Options Compared

```
                Short    Long      SSE        WebSocket    WebRTC
                Polling  Polling
─────────────────────────────────────────────────────────────────
Direction       C→S      C→S       S→C        Both         P2P
Connection      New/req  Held      Persistent Persistent   Persistent
Protocol        HTTP     HTTP      HTTP        WS           DTLS/SRTP
Browser support All      All       All         All          Modern
Overhead        High     Medium    Low         Very low     High setup
Auto-reconnect  Manual   Manual    Built-in    Manual       Manual
Use case        Simple   Simple    Feeds       Chat/games   Video/audio
```

## Short Polling

```
Client asks server repeatedly at fixed intervals:

while (true):
  response = GET /api/messages?since=last_id
  if response.data: display(response.data)
  sleep(5_000)  // every 5 seconds

Timeline:
──────────
t=0:   Client polls → "No new data" (wasted request)
t=5:   Client polls → "No new data" (wasted request)
t=7:   Message arrives on server ← 3 seconds of delay!
t=10:  Client polls → "1 new message" (finally!)
```

```
Pros:
✅ Extremely simple to implement
✅ Works everywhere (HTTP/1.1)
✅ Stateless server

Cons:
❌ High server load (even with no updates)
❌ Average delay = half the poll interval
❌ Wasteful bandwidth
```

**When to use**: internal dashboards with low traffic, simple prototypes.

## Long Polling

```
Client holds the connection open until the server has data:

Client: GET /api/messages  (connection stays open)
Server: .....(waiting).....
Server: .....MESSAGE!.....  → flush response immediately
Client: receives data → opens new long-poll immediately

Timeline:
──────────
t=0:  Client opens connection, server holds it
t=7:  Message arrives → server sends immediately
t=7:  Client receives → opens new connection instantly

Delay: ~0ms (message delivered instantly)
```

```
Pros:
✅ Near real-time delivery
✅ Still plain HTTP — works everywhere
✅ No special server infrastructure

Cons:
❌ Connection held open consumes server memory
❌ Thundering herd on timeout (all clients reconnect at once)
❌ Each "push" requires a new HTTP request
❌ Hard to scale (each server holds many open connections)
```

**When to use**: real-time notifications when WebSocket infra is not available.

## Server-Sent Events (SSE)

```
One persistent HTTP connection from server to client:

Client: GET /events  (Accept: text/event-stream)
Server: HTTP 200 OK
        Content-Type: text/event-stream
        ──────────────────────────────
        data: {"type": "price", "value": 42.5}

        data: {"type": "price", "value": 43.1}

        event: alert
        data: {"message": "Price spike!"}
        id: 550

        : heartbeat comment (keeps connection alive)
```

### SSE Wire Format

```
data: simple string message

event: custom-type
data: {"key": "value"}
id: 123
retry: 5000

Fields:
  data:   message payload (can be multi-line with multiple data: lines)
  event:  custom event type (client listens with addEventListener)
  id:     last event ID (sent as Last-Event-ID on reconnect)
  retry:  reconnect delay in milliseconds
  :       comment line (ignored by client, used as heartbeat)
```

### SSE Auto-Reconnect

```
Built-in browser reconnection:
────────────────────────────────
1. Connection drops (network glitch, server restart)
2. Browser waits `retry` ms (default: 3000ms)
3. Browser sends: GET /events
                  Last-Event-ID: 550
4. Server resumes from event 550 → no messages lost

This is why SSE is preferred over WebSocket for one-way feeds:
you get free reconnection logic.
```

```javascript
// Client
const evtSource = new EventSource('/api/events');

evtSource.onmessage = (e) => {
  const data = JSON.parse(e.data);
  updateUI(data);
};

evtSource.addEventListener('alert', (e) => {
  showNotification(e.data);
});

evtSource.onerror = (e) => {
  console.log('SSE error, will auto-reconnect');
};
```

```python
# Server (Python/Flask)
from flask import Response, stream_with_context
import json, time

@app.route('/api/events')
def events():
    def generate():
        last_id = request.headers.get('Last-Event-ID', 0)
        for event in event_stream(since=last_id):
            yield f"id: {event.id}\n"
            yield f"data: {json.dumps(event.data)}\n\n"
            yield ": heartbeat\n\n"
            time.sleep(0.1)
    return Response(stream_with_context(generate()),
                    content_type='text/event-stream')
```

**SSE use cases**: live dashboards, stock tickers, sports scores, notifications, log streaming, CI/CD build progress.

## WebSockets

### The Handshake

```
WebSocket starts as HTTP, then upgrades:

Client → Server:
  GET /chat HTTP/1.1
  Host: example.com
  Upgrade: websocket
  Connection: Upgrade
  Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==
  Sec-WebSocket-Version: 13

Server → Client:
  HTTP/1.1 101 Switching Protocols
  Upgrade: websocket
  Connection: Upgrade
  Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=

After this: full-duplex TCP connection on port 80/443
No more HTTP overhead. Raw framing.
```

### WebSocket Frames

```
Frame structure:
────────────────
FIN | RSV | OPCODE | MASK | Payload Length | Payload

Opcodes:
  0x0  Continuation
  0x1  Text frame
  0x2  Binary frame
  0x8  Close
  0x9  Ping
  0xA  Pong

Ping/Pong: keep-alive mechanism
  Server: sends Ping every 30s
  Client: must respond with Pong
  If no Pong: server closes connection
```

```javascript
// Client
const ws = new WebSocket('wss://chat.example.com/ws');

ws.onopen = () => {
  ws.send(JSON.stringify({ type: 'join', room: 'general' }));
};

ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  displayMessage(msg);
};

ws.onclose = (event) => {
  console.log('Closed:', event.code, event.reason);
  setTimeout(reconnect, 3000);  // manual reconnect
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};
```

```python
# Server (Python/asyncio)
import asyncio, websockets, json

connected = set()

async def handler(websocket):
    connected.add(websocket)
    try:
        async for message in websocket:
            data = json.loads(message)
            # Broadcast to all connected clients
            websockets.broadcast(connected, message)
    finally:
        connected.remove(websocket)

async def main():
    async with websockets.serve(handler, "0.0.0.0", 8765):
        await asyncio.Future()  # run forever
```

**WebSocket use cases**: chat applications, multiplayer games, collaborative editing, trading platforms, live auctions.

## Communication Method Comparison

```mermaid
flowchart TD
    A([Need real-time?]) --> B{Direction?}

    B -- Server to client only --> C{Reconnect\nneeded?}
    B -- Both directions --> D{Latency\ncritical?}
    B -- Neither / simple --> E[Short Polling\nSimple, works everywhere]

    C -- Yes, built-in --> F[SSE\nLive feeds, notifications]
    C -- Manual OK --> G[Long Polling\nSimple fallback]

    D -- Very low latency\nbidirectional --> H[WebSocket\nChat, games, trading]
    D -- Peer-to-peer\naudio/video --> I[WebRTC\nVideo calls, screen share]

    style A fill:#7c3aed,color:#fff
    style B fill:#2563eb,color:#fff
    style D fill:#2563eb,color:#fff
    style C fill:#2563eb,color:#fff
    style E fill:#374151,color:#fff
    style F fill:#059669,color:#fff
    style G fill:#374151,color:#fff
    style H fill:#059669,color:#fff
    style I fill:#059669,color:#fff
```

## Scaling WebSockets

### The Stickiness Problem

```
Problem: WebSocket connections are stateful

User A connects to Server 1:
  Server 1 holds the WebSocket for User A

User B is on Server 2:
  User B sends message to User A
  Server 2 has no connection to User A!

  Server 2 → where is User A?
             Server 2 doesn't know.
```

### Solution 1: Sticky Sessions

```
Load Balancer routes all requests from the same user
to the same server:

User A ──(always)──► Server 1
User B ──(always)──► Server 2
User C ──(always)──► Server 3

Nginx config:
  upstream websocket {
    ip_hash;            # sticky by IP
    server 10.0.0.1:8080;
    server 10.0.0.2:8080;
    server 10.0.0.3:8080;
  }

Pros: ✅ Simple
Cons: ❌ Uneven load if some users are more active
      ❌ If Server 1 dies, User A reconnects — must re-register
```

### Solution 2: Redis Pub/Sub (Recommended)

```mermaid
flowchart LR
    UA[User A\nServer 1] -->|Message to B| S1[Server 1]
    UB[User B\nServer 2] --> S2[Server 2]
    UC[User C\nServer 3] --> S3[Server 3]

    S1 -->|PUBLISH\nchannel:userB\nmsg| RC[(Redis\nPub/Sub)]
    RC -->|SUBSCRIBE\nchannel:userB| S2
    S2 -->|Push to\nUser B| UB

    S1 -.->|SUBSCRIBE\nchannel:userA| RC
    S2 -.->|SUBSCRIBE\nchannel:userC| RC
    S3 -.->|SUBSCRIBE\nchannel:userA,B| RC

    style RC fill:#ef4444,color:#fff
    style S1 fill:#2563eb,color:#fff
    style S2 fill:#2563eb,color:#fff
    style S3 fill:#2563eb,color:#fff
    style UA fill:#374151,color:#fff
    style UB fill:#374151,color:#fff
    style UC fill:#374151,color:#fff
```

```
Flow:
──────
1. User A (on Server 1) sends message to User B
2. Server 1 publishes to Redis channel "user:B"
3. Server 2 subscribed to "user:B" receives the message
4. Server 2 pushes to User B's WebSocket connection

Redis commands:
───────────────
SUBSCRIBE user:B         # Server 2 subscribes when User B connects
PUBLISH user:B "{msg}"   # Server 1 publishes message
UNSUBSCRIBE user:B       # Server 2 unsubscribes when User B disconnects

Pros:
✅ No sticky sessions required
✅ Any server can handle any user's incoming messages
✅ Horizontal scaling: just add servers
✅ Redis handles message routing

Cons:
❌ Redis is a single point of failure (use Redis Cluster)
❌ Extra network hop per message
❌ Redis memory scales with active connections
```

### Solution 3: Dedicated WebSocket Tier

```
Architecture for very large scale:

[Load Balancer]
      │
      ▼
[WS Gateway Tier]          ← stateful, holds connections
  ws-server-1 (10K conns)
  ws-server-2 (10K conns)
  ws-server-3 (10K conns)
      │
      ▼
  [Message Bus: Kafka]
      │
      ▼
[Processing Tier]           ← stateless, business logic
  app-server-1
  app-server-2

Used by: Slack, Discord, WhatsApp
```

## WebRTC (Peer-to-Peer)

```
WebRTC skips the server for media — clients stream directly:

Standard WebSocket:
  User A ──video──► Server ──video──► User B
  Latency: 2 hops, Server bandwidth cost: high

WebRTC:
  User A ──video──────────────────► User B
  (Direct P2P, or via TURN relay if NAT blocks)

Components:
────────────
Signaling:  WebSocket/HTTP to exchange connection info
ICE/STUN:   Discover public IPs behind NAT
TURN:       Relay server when P2P fails (firewall)
DTLS:       Encrypted transport
SRTP:       Encrypted media

Use cases:
──────────
✅ Video calls (Google Meet, Zoom)
✅ Screen sharing
✅ Peer-to-peer file transfer
✅ Live streaming (OBS → browser)
```

```
WebRTC connection setup:
─────────────────────────
1. User A: create offer (SDP)
2. User A → Signaling Server → User B: send offer
3. User B: create answer (SDP)
4. User B → Signaling Server → User A: send answer
5. Both: exchange ICE candidates (network info)
6. P2P connection established → media flows directly
```

## Use Case Matching

| Use Case | Best Choice | Why |
|----------|-------------|-----|
| Chat application | WebSocket | Bidirectional, low latency |
| Live sports scores | SSE | Server-to-client only, auto-reconnect |
| Stock ticker / prices | SSE | Server-to-client, frequent updates |
| Dashboard metrics | SSE | Unidirectional stream |
| Multiplayer game | WebSocket | Ultra-low latency, bidirectional |
| Video call | WebRTC | P2P media, browser-native |
| Push notifications | SSE or WebSocket | Depends on existing infra |
| Collaborative editing | WebSocket | Operational transform needs bidirectional |
| CI/CD log streaming | SSE | Unidirectional text stream |
| Internal admin panel | Short Polling | Simplicity wins at low scale |

## Connection Limits and Capacity Planning

```
Server capacity:
──────────────────
Each WebSocket connection uses ~50 KB memory
Standard Linux: 65,535 ports per IP (use multiple IPs)
With tuning: 1 million concurrent connections per server

Capacity planning:
────────────────────
100,000 concurrent users
× 50 KB per connection
= 5 GB RAM just for connections

Message throughput:
  1M users × 10 msg/sec × 1 KB = 10 GB/sec

Solution: Horizontal scaling + Redis pub/sub
          Keep WS servers "dumb" — route, don't process
```

## Heartbeats and Connection Health

```
WebSocket connections can silently die (middleboxes, NAT timeouts):

Solution: Application-level heartbeat

Server every 30s:
  → send ping frame (or {"type": "ping"})

Client:
  → respond with pong frame (or {"type": "pong"})

If no pong received in 10s:
  → close and reconnect

Client-side reconnection with backoff:
────────────────────────────────────────
reconnect_delay = 1s
on close:
  setTimeout(connect, reconnect_delay)
  reconnect_delay = min(reconnect_delay * 2, 30s)
on open:
  reconnect_delay = 1s  // reset on success
```

## Trade-offs Summary

| Technology | Connection | Direction | Reconnect | Infra Complexity | Best For |
|-----------|-----------|-----------|-----------|-----------------|----------|
| Short Polling | New/req | C→S | N/A | None | Simple use cases |
| Long Polling | Held | S→C | Manual | Low | Fallback |
| SSE | Persistent | S→C | Automatic | Low | Live feeds |
| WebSocket | Persistent | Both | Manual | Medium | Interactive |
| WebRTC | P2P | Both | Complex | High | Media/video |

## Practice Exercise

**Design the notification system for a project management tool**

```
Scenario:
- 2M registered users, 200K daily active
- Notifications: task assigned, comment added, mention, due date
- Users expect notifications within 2 seconds
- Mobile app + web app
- Users can be offline and catch up on reconnect

Questions:
1. Which protocol for web app?
2. How do you handle offline users?
3. How do you scale to 200K concurrent connections?
4. How do you avoid duplicate notifications on reconnect?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Protocol: SSE for web app
   ────────────────────────────
   Notifications are server-to-client only.
   SSE built-in auto-reconnect + Last-Event-ID is perfect.
   No need for bidirectional WebSocket complexity.
   Mobile app: use platform push (APNs/FCM) — more battery efficient.

2. Offline users:
   ────────────────
   Store notifications in DB with read/delivered status.
   On SSE connect, send Last-Event-ID header.
   Server replays all undelivered notifications since that ID.
   User catches up immediately on reconnect.

3. Scaling 200K connections:
   ──────────────────────────
   SSE servers: 10 servers × 20K connections each = 200K
   Each server subscribes to Redis channels for its connected users.
   When notification created:
     → publish to Redis channel for recipient user
     → user's SSE server receives and pushes
   Auto-scale SSE servers based on active connections.

4. Deduplication:
   ────────────────
   Each notification has a stable UUID.
   Client tracks seen notification IDs in localStorage.
   On receive: if already seen → skip (idempotent display).
   Server tracks delivered status per (user, notification) pair.
   TTL on delivery records: 30 days.
```

</details>

## Interview Tips

- **Compare all four approaches first**: show you know the trade-space before committing to one
- **SSE is often the right answer** for server-to-client use cases — interviewers appreciate knowing it exists
- **The sticky session / Redis pub-sub problem** is a favourite follow-up for WebSocket questions
- **Mention heartbeats**: silent connection death is a real production problem
- **WebRTC is niche** — only bring it up for video/audio or explicit P2P use cases
- **Capacity math**: 50 KB per WS connection × 1M users = 50 GB RAM — shows you think about scale

## Summary

- **Short Polling**: simple, wasteful — only for low-scale internal tools
- **Long Polling**: near-real-time over plain HTTP — good fallback
- **SSE**: ideal for server-to-client streams — auto-reconnect is a major advantage
- **WebSockets**: full-duplex persistent connection — best for chat, games, collaborative apps
- **WebRTC**: peer-to-peer media — for video/audio calls only
- **Scaling WebSockets**: sticky sessions or Redis pub/sub; Redis pub/sub is more robust

## Next Steps

Continue to [URL Shortener Case Study](../23-url-shortener/README.md) to apply these concepts in a complete system design.

---

**Key Takeaway**: Match the communication pattern to the data flow. Server-to-client → SSE. Bidirectional → WebSocket. Media → WebRTC.
