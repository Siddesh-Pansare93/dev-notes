# Case Study: Design Twitter

## What We Are Building

```
Core Twitter experience:
─────────────────────────
1. Post a tweet (280 characters, images, videos)
2. Follow / unfollow other users
3. Home timeline (tweets from people you follow)
4. Like, retweet, reply
5. Notifications (likes, follows, mentions)
6. Search (tweet content and users)
```

This is one of the most common system design interview questions because it touches every major distributed systems concept: scale, fan-out, caching, CDN, search, and real-time.

## Step 1: Requirements

### Functional Requirements

```
Must have:
──────────
1. Post tweet (text, images, video)
2. Follow / unfollow users
3. Home timeline (ordered feed of followed users' tweets)
4. Like a tweet
5. Retweet
6. Notifications

Nice to have (discuss, don't design fully):
────────────────────────────────────────────
- Twitter Spaces (audio)
- Twitter DMs
- Trending topics
- Ads
```

### Non-Functional Requirements

```
Scale:
──────
DAU:           150 million daily active users
Tweets/day:    500 million new tweets
Read QPS:      300,000 reads/second (home timeline)
Write QPS:     6,000 tweets/second
Read:Write:    50:1

Availability:
─────────────
99.99% for timeline reads (this is the main product)
99.9%  for tweet posting

Latency:
─────────
Home timeline load: < 200ms p95
Tweet posting:      < 500ms

Consistency:
────────────
Eventually consistent is acceptable:
  User A tweets → User B may see it 1–5 seconds later (OK)
  User cannot see a tweet that was never posted (NO)
```

## Step 2: Capacity Estimation

```
Tweets:
────────
500M tweets/day ÷ 86,400s = ~5,800 tweets/second
Peak: 3× average = ~17,500 tweets/second (major events)

Storage for tweets:
───────────────────
500M tweets/day × 280 chars × 2 bytes = 280 GB text/day
Media: 500M tweets × 20% with image × 100 KB = 10 TB/day
5 years: text = 500 TB, media = 18 PB

Users:
───────
500M registered users
150M DAU
Following relationships: avg 200 follows/user = 100B edges

Timeline:
──────────
150M DAU × 10 timeline loads/day = 1.5B loads/day
= 17,000 timeline loads/second (average)
= 300,000 timeline loads/second (peak, 17× for viral events)

Fan-out:
─────────
Each tweet must be delivered to all followers.
Average followers per user: 200
Celebrity: 100M+ followers
Fan-out writes: 5,800 tweets/sec × 200 followers = 1.16M writes/sec
```

## Step 3: Core Data Models

```sql
-- Users
CREATE TABLE users (
    user_id      BIGSERIAL PRIMARY KEY,
    username     VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100),
    bio          TEXT,
    follower_count  INT DEFAULT 0,
    following_count INT DEFAULT 0,
    tweet_count     INT DEFAULT 0,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Tweets
CREATE TABLE tweets (
    tweet_id     BIGSERIAL PRIMARY KEY,
    user_id      BIGINT NOT NULL REFERENCES users(user_id),
    content      VARCHAR(280),
    media_urls   TEXT[],        -- array of S3/CDN URLs
    reply_to_id  BIGINT,        -- NULL if original tweet
    retweet_of_id BIGINT,       -- NULL if original tweet
    like_count   INT DEFAULT 0,
    retweet_count INT DEFAULT 0,
    reply_count  INT DEFAULT 0,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tweets_user_time ON tweets(user_id, created_at DESC);

-- Follow relationships (graph edge table)
CREATE TABLE follows (
    follower_id  BIGINT NOT NULL,
    followee_id  BIGINT NOT NULL,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (follower_id, followee_id)
);

CREATE INDEX idx_follows_followee ON follows(followee_id);

-- Likes (write-heavy, consider separate DB)
CREATE TABLE likes (
    user_id   BIGINT NOT NULL,
    tweet_id  BIGINT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, tweet_id)
);

-- Home timeline (pre-computed, stored in Redis)
-- Not a DB table — lives in Redis sorted sets
-- ZADD timeline:{user_id} {tweet_timestamp} {tweet_id}
```

**Tweet ID strategy**: Use Twitter's Snowflake ID — 64-bit integer encoding timestamp + datacenter + sequence. Sortable by time, globally unique, no coordination needed.

```
Snowflake ID (64 bits):
  41 bits: millisecond timestamp (since epoch)
  10 bits: machine/datacenter ID
  12 bits: sequence number per millisecond

Result: 4096 unique IDs per machine per millisecond
        Sorted by creation time (time-prefix)
```

## Step 4: The Fan-Out Problem

The home timeline is the hardest part of Twitter's design.

```
When @ElonMusk (100M followers) tweets:
─────────────────────────────────────────
100M writes needed immediately!

At 6,000 tweets/sec average:
  100M followers × 1 tweet = 100M timeline writes
  100M ÷ 6,000 = 16,667 seconds to process
  = 4.6 hours of lag!

This is the core scaling challenge.
```

### Strategy 1: Fan-Out on Write (Push Model)

```
When tweet is posted → immediately push to all followers' timelines

Post tweet:
  1. Save tweet to tweets table
  2. Look up all followers (SELECT FROM follows)
  3. For each follower: ZADD timeline:{follower_id} {score} {tweet_id}

Read timeline:
  1. ZREVRANGE timeline:{user_id} 0 19  (instant, O(log n))
  2. Fetch tweet details by tweet IDs (Redis or DB)

Timeline retrieval: ~1ms (just a Redis read)
```

```
Pros:
✅ Read is extremely fast (pre-computed)
✅ Timeline read is a simple Redis lookup
✅ Handles the 300K reads/second target easily

Cons:
❌ Celebrity problem: 100M writes per tweet from @elonmusk
❌ Write amplification: huge spike on popular accounts
❌ Wasted writes: if follower is inactive, writes are wasted
```

### Strategy 2: Fan-Out on Read (Pull Model)

```
When timeline is requested → pull tweets from followed users

Post tweet:
  1. Save tweet to tweets table (done)
  2. Nothing else.

Read timeline:
  1. SELECT followee_id FROM follows WHERE follower_id = {user_id}
  2. SELECT * FROM tweets WHERE user_id IN (...followees...)
     ORDER BY created_at DESC LIMIT 20

Timeline retrieval: 50–200ms (multiple DB queries + merge/sort)
```

```
Pros:
✅ No fan-out on write — celebrities are no problem
✅ Always fresh (no staleness)
✅ Inactive users waste no resources

Cons:
❌ Slow read: must query N users' tweet tables and merge
❌ Does not scale: 300K requests/sec × N DB queries each
❌ Hard to pre-sort and paginate across multiple sources
```

### Strategy 3: Hybrid (Twitter's Actual Approach)

```mermaid
flowchart TD
    TW[Tweet posted] --> CF{Celebrity\ncheck\n> 1M followers?}

    CF -- Regular user\n< 1M followers --> FW[Fan-out on WRITE\nPush to follower timelines]
    CF -- Celebrity\n> 1M followers --> NO[No fan-out\nStore tweet only]

    FW --> TL[(Timeline Cache\nRedis Sorted Set\nper user)]

    RD[User loads timeline] --> MR[Merge:\n1. Read timeline cache\n2. Pull celebrity tweets]
    TL --> MR
    NO --> MR

    MR --> RESP[Return merged\ntimeline\nto user]

    style CF fill:#2563eb,color:#fff
    style FW fill:#059669,color:#fff
    style NO fill:#f59e0b,color:#fff
    style TL fill:#ef4444,color:#fff
    style MR fill:#7c3aed,color:#fff
    style RESP fill:#059669,color:#fff
```


### Fan-Out Architecture Comparison

```mermaid
flowchart LR
    subgraph WRITE ["Fan-Out on Write"]
        direction TB
        T1[Tweet posted] --> J1[Fan-out job]
        J1 -->|write| UX[User A timeline]
        J1 -->|write| UY[User B timeline]
        J1 -->|write| UZ[User C timeline]
        RW[Read] -->|instant| UX
    end

    subgraph READ ["Fan-Out on Read"]
        direction TB
        T2[Tweet posted] --> ST[Saved only]
        RR[Read timeline] --> Q1[Query User 1 tweets]
        RR --> Q2[Query User 2 tweets]
        RR --> Q3[Query User 3 tweets]
        Q1 --> MG[Merge & sort]
        Q2 --> MG
        Q3 --> MG
    end

    style J1 fill:#7c3aed,color:#fff
    style UX fill:#059669,color:#fff
    style UY fill:#059669,color:#fff
    style UZ fill:#059669,color:#fff
    style RW fill:#2563eb,color:#fff
    style MG fill:#f59e0b,color:#fff
    style RR fill:#ef4444,color:#fff
```

## Step 5: Timeline Architecture

### Redis Sorted Set for Timelines

```
Structure:
──────────
Key:   timeline:{user_id}
Type:  Sorted Set
Score: tweet creation timestamp (Unix ms, enables time ordering)
Value: tweet_id

Operations:
────────────
Fan-out write:
  ZADD timeline:456 1706745600000 tweet_id_789

Read timeline (newest 20):
  ZREVRANGEBYSCORE timeline:456 +inf -inf LIMIT 0 20

Trim old entries (keep last 800):
  ZREMRANGEBYRANK timeline:456 0 -801

Memory estimate:
────────────────
800 tweets × 8 bytes (score) × 8 bytes (tweet_id) = ~13 KB per user
150M active users × 13 KB = 2 TB of Redis memory
→ Use Redis Cluster with many shards
→ Only keep timelines for active users (evict after 30 days inactivity)
```

### Tweet Details Cache

```
Tweets referenced in timelines need content:

Key:    tweet:{tweet_id}
Value:  JSON {user_id, content, media_urls, like_count, ...}
TTL:    1 hour (hot tweets), 24 hours (normal)

On timeline read:
1. ZREVRANGE timeline:456 0 19 → [tweet_id_1, tweet_id_2, ...]
2. MGET tweet:id1 tweet:id2 ... tweet:id20  (batch fetch)
3. For cache misses: SELECT FROM tweets WHERE tweet_id IN (...)
4. Populate cache for misses
5. Return to user

Two-level cache (L1: local, L2: Redis):
  App server L1: last 1000 hot tweet objects in memory
  Redis L2:      millions of tweet objects
  DB:            source of truth
```

## Step 6: Media Storage

```
Scale:
───────
500M tweets/day × 20% with image × 1 photo average
= 100M photos/day at ~100 KB each = 10 TB/day

Architecture:
──────────────
Client → Upload Service → S3/Object Storage
                        → Image Processing Pipeline
                        → CDN (Cloudflare/Akamai)
                        → tweet.media_urls = [CDN URL]

Flow for image upload:
──────────────────────
1. Client requests upload URL:
   POST /api/v1/media/presign → {upload_url, media_id}
2. Client uploads directly to S3 (presigned URL, bypass your servers)
3. S3 triggers Lambda/event:
   → Generate thumbnails (400px, 800px, 1200px)
   → Transcode video to multiple bitrates
   → Store all variants in S3
4. Tweet is posted with media_id reference
5. CDN caches media globally

Why presigned upload:
─────────────────────
Client uploads directly to S3 → your servers never handle media bytes
100K uploads/sec × 100 KB = 10 GB/sec — your app servers cannot handle this
```

```
CDN strategy:
──────────────
Profile pictures:  Cache aggressively (TTL: 7 days)
Tweet images:      Cache long (TTL: 1 year, immutable once posted)
Videos:            CDN with adaptive bitrate (HLS)
Hot media:         Served from edge nodes globally
  → New York, London, Tokyo, Singapore edges
  → User in Tokyo: <20ms latency
  → Without CDN: Tokyo → San Francisco = ~120ms
```

## Step 7: Search

### Tweet Search with Elasticsearch

```
Challenge:
───────────
500M tweets/day × 280 chars
Full-text search across 5 years = 900B tweets

Approach:
──────────
1. Tweet posted → published to Kafka
2. Search indexer consumes Kafka
3. Index tweet in Elasticsearch:
   {
     "tweet_id":  "1234567890",
     "user_id":   "9876",
     "content":   "Just landed on Mars! #SpaceX",
     "hashtags":  ["SpaceX"],
     "mentions":  [],
     "created_at": "2026-03-28T10:00:00Z"
   }
4. Search query: GET /search?q=spacex&sort=latest
   → Elasticsearch full-text query with recency boost

Indexing strategy:
───────────────────
Index recent tweets (last 7 days) in hot Elasticsearch cluster
Older tweets in cold cluster (higher latency, lower cost)
Very old tweets: not indexed (or archived to S3 + Athena)

User search (by @username):
──────────────────────────────
Separate Elasticsearch index for users.
Typeahead: prefix query on username field.
Return top 10 by follower_count DESC.
```

## Step 8: Notifications

```
Notification types:
────────────────────
1. Like on your tweet
2. Retweet of your tweet
3. Reply to your tweet
4. New follower
5. Mention (@username in tweet)

Architecture:
──────────────
Event occurs (like, follow, etc.)
  → Publish to Kafka topic "notifications"
  → Notification Service consumes
  → Check user notification preferences
  → Write to notifications table
  → Push via SSE/WebSocket (if user is online)
  → Push via APNs/FCM (if user has mobile app)

Aggregation (de-spam):
───────────────────────
"John, Sarah, and 3 others liked your tweet"
  → Buffer likes for 5 minutes
  → Aggregate before sending single notification

Notification storage:
──────────────────────
Table: notifications(notification_id, user_id, type, actor_id, entity_id, read, created_at)
Keep last 90 days
Serve from Redis sorted set for fast "unread count"
```

## Step 9: Full Architecture

```mermaid
flowchart TD
    subgraph Clients ["Client Layer"]
        MW[Mobile / Web]
    end

    subgraph Edge ["Edge"]
        CDN[CDN\nMedia & Static]
        LB[Load Balancer]
    end

    subgraph APIs ["API Layer"]
        TW[Tweet Service]
        TL[Timeline Service]
        FW[Fan-out Worker\nKafka Consumer]
        US[User Service]
        NS[Notification Service]
        SS[Search Indexer]
    end

    subgraph Messaging ["Message Bus"]
        KF[Kafka\nTweet events\nNotification events]
    end

    subgraph Cache ["Cache Layer"]
        RC[(Redis Cluster\nTimelines\nTweet objects\nUser sessions)]
    end

    subgraph Storage ["Storage Layer"]
        PG[(PostgreSQL\nUsers, Tweets,\nFollows, Likes)]
        S3[(S3\nImages / Videos)]
        ES[(Elasticsearch\nTweet Search\nUser Search)]
    end

    MW -->|API calls| LB
    MW -->|Media| CDN
    LB --> TW
    LB --> TL
    LB --> US

    TW -->|Store tweet| PG
    TW -->|Publish| KF
    TL -->|Read timeline| RC
    TL -->|Cache miss| PG

    KF --> FW
    KF --> NS
    KF --> SS

    FW -->|ZADD timeline| RC

    SS --> ES
    NS -->|Push| MW

    S3 --> CDN

    TW -->|Presign upload| S3

    style CDN fill:#7c3aed,color:#fff
    style LB fill:#7c3aed,color:#fff
    style KF fill:#f59e0b,color:#fff
    style RC fill:#ef4444,color:#fff
    style PG fill:#2563eb,color:#fff
    style S3 fill:#2563eb,color:#fff
    style ES fill:#2563eb,color:#fff
    style TW fill:#059669,color:#fff
    style TL fill:#059669,color:#fff
    style FW fill:#059669,color:#fff
    style NS fill:#059669,color:#fff
    style SS fill:#374151,color:#fff
```

## Step 10: Handling the Celebrity Problem

```
What makes celebrities special:
─────────────────────────────────
@elonmusk: 100M followers
If he tweets: 100M Redis ZADD operations needed
At 100K writes/sec: takes 1000 seconds = 16 minutes of lag

Solutions:
───────────

Solution 1: Skip fan-out for celebrities (Twitter's approach)
  → Define celebrity threshold (e.g., >1M followers)
  → Don't fan-out their tweets
  → On timeline read: fetch their recent tweets + merge
  → Downside: more complex timeline read path

Solution 2: Async fan-out with priority queues
  → Regular users: fan-out immediately (high-priority queue)
  → Celebrities: fan-out over time (low-priority queue, spread load)
  → Timeline shows "may be delayed up to 5 minutes for some accounts"

Solution 3: Fan-out only to active followers
  → Only write to timelines of users active in last 30 days
  → Inactive users: pull-on-demand when they return
  → Reduces writes by ~60% (many followers are inactive)

Twitter uses a combination of all three.
```

## Step 11: Trending Topics

```
Trending: top hashtags by tweet volume in last 1 hour

Implementation:
────────────────
1. Tweet created → parse hashtags
2. Publish hashtag event to Kafka
3. Consumer: ZINCRBY trending:global {count} {hashtag}
             with sliding 1-hour window
4. Every minute: ZREVRANGE trending:global 0 49 → Top 50
5. Cache trending list for 60 seconds

Per-location trending:
  ZINCRBY trending:us {count} {hashtag}
  ZINCRBY trending:us:ny {count} {hashtag}

Scale note:
  Trending requires counting across 500M tweets/day
  HyperLogLog for unique user counting
  Count-Min Sketch for approximate top-K at scale
```

## Trade-offs Summary

| Design Decision | Option A | Option B | Twitter's Choice |
|----------------|---------|---------|-----------------|
| Timeline generation | Fan-out on write | Fan-out on read | Hybrid |
| Celebrity handling | Fan-out (slow) | No fan-out + merge | No fan-out + merge |
| Tweet IDs | UUID | Snowflake | Snowflake |
| Timeline storage | MySQL | Redis sorted set | Redis sorted set |
| Media storage | Own servers | S3 + CDN | S3 + CDN |
| Search | MySQL LIKE | Elasticsearch | Elasticsearch |
| Consistency | Strong | Eventual | Eventual |

## Scaling Bottlenecks

```
1. Fan-out worker (most critical):
   When: viral tweet, celebrity posts
   Solution: Scale fan-out workers horizontally
             Use multiple Kafka partitions for parallelism
             Fan-out only to active users

2. Redis memory:
   When: 150M active user timelines × 13 KB = 2 TB
   Solution: Redis Cluster (10s of shards)
             LRU eviction for inactive users
             Compress tweet IDs (delta encoding)

3. PostgreSQL at scale:
   When: 500M tweets/day → 100B+ rows over years
   Solution: Partition tweets table by created_at (monthly)
             Read replicas for timeline service
             Archive old data to S3 + Athena for analytics

4. Read hotspots:
   When: Breaking news tweet by celebrity
   Solution: Local L1 cache in app servers for hottest tweets
             CDN for media
             Circuit breaker on DB if overwhelmed
```

## Practice: Interview Walk-Through

**Interviewer**: "Design Twitter's home timeline."

```
Good structure:
────────────────
1. Clarify requirements (2 min):
   "150M DAU, 500M tweets/day, read:write 50:1 — confirm?"
   "Acceptable to see new tweets with 1–5s delay?"

2. Capacity estimation (3 min):
   Write QPS: ~6K, Read QPS: ~300K
   Fan-out math: 6K tweets × 200 followers = 1.2M writes/sec

3. High-level design (5 min):
   Draw: Client → LB → Tweet/Timeline Services → Redis/DB
   Identify: this is a fan-out problem

4. Deep dive: fan-out strategies (10 min):
   Explain push vs pull vs hybrid
   Explain celebrity threshold

5. Deep dive: Redis sorted set timeline (5 min):
   ZADD, ZREVRANGE, memory math

6. Trade-offs and follow-ups (5 min):
   "What if a celebrity with 1B followers posts?"
   "How do you handle eventual consistency?"
```

## Interview Tips

- **Lead with the fan-out problem** — it is the defining challenge and shows you understand Twitter's core difficulty
- **The celebrity problem is always a follow-up** — have the hybrid solution ready
- **Mention Snowflake IDs** — shows real Twitter knowledge and why they are sortable by time
- **Draw the data flow clearly**: tweet post → Kafka → fan-out workers → Redis timelines → timeline read
- **Quantify the Redis memory** — shows you can reason about scale (2 TB is large but manageable)
- **Eventual consistency is acceptable** — explicitly say this and why (users tolerate 1–5s delay)
- **Do not forget media** — it is 99% of the bytes; S3 + CDN is essential

## Summary

- **Fan-out on write** (push) gives fast reads but kills celebrities — use hybrid
- **Redis sorted sets** are the standard for timeline storage: O(log n) insert, O(log n + k) read
- **Snowflake IDs** enable globally unique, time-sortable tweet IDs without coordination
- **Kafka decouples** tweet posting from fan-out, search indexing, and notifications
- **S3 + CDN** is mandatory for media — never store or serve images from your app servers
- **Elasticsearch** powers tweet and user search — full-text at 900B tweet scale
- **Eventual consistency** is the pragmatic choice — users tolerate slight delay

## Next Steps

You have now completed the core system design curriculum. Review the full topic list and revisit areas where you want to go deeper.

---

**Key Takeaway**: Twitter's core challenge is fan-out at scale. The hybrid push/pull model with a celebrity threshold is the canonical solution — know it inside out.
