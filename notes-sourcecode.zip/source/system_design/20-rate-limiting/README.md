# Rate Limiting

## Why Rate Limiting Matters

```
Without rate limiting:
──────────────────────
One angry user sends 100,000 requests/second
├─ Server CPU: 100%
├─ Database overwhelmed
├─ Legitimate users: 503 Service Unavailable
└─ Bill: $10,000 in API costs

With rate limiting:
────────────────────
Same user capped at 1,000 requests/minute
├─ Server: normal load
├─ Database: stable
├─ Legitimate users: happy
└─ Bill: under control
```

Rate limiting protects your system against:

- **Abuse and DDoS attacks** — a single client cannot overwhelm the system
- **Unfair usage** — one power user cannot starve everyone else
- **Cost control** — LLM API calls, SMS, email all cost money per unit
- **Accidental runaway clients** — a buggy polling loop without backoff
- **Scraping and crawlers** — bots harvesting data at machine speed

## Rate Limiting Algorithms

### 1. Fixed Window Counter

```
Time: ──────────────|──────────────|──────────────
       Window 1     |  Window 2    |  Window 3
       (0–60s)      |  (60–120s)   |  (120–180s)

Limit: 100 requests per window

Window 1: 99 requests → OK
Window 1: 100th request → OK
Window 1: 101st request → REJECTED

Window 2 starts: counter resets to 0
```

**The boundary problem:**

```
Window ends at :60, new window starts at :60

User sends:
  :59 → 100 requests (fills window 1)
  :61 → 100 requests (fills window 2)

Result: 200 requests pass in 2 seconds!
(Effective rate = 2x the limit at window boundaries)
```

| Pros | Cons |
|------|------|
| Simple — one counter per key | Boundary burst allows 2x traffic |
| Minimal memory (1 int per client) | Not smooth — spiky behavior |
| Fast Redis INCR + EXPIRE | Restarts can lose state |

### 2. Sliding Window Log

```
Keep a timestamp log of every request:

User log: [10:00:01, 10:00:03, 10:00:05, 10:00:45, 10:00:58, 10:01:02]

At 10:01:10, check last 60 seconds:
├─ Remove entries before 10:00:10
├─ Remaining: [10:00:45, 10:00:58, 10:01:02]
├─ Count = 3 → allow

If limit = 3: reject next request
If limit = 4: allow next request
```

| Pros | Cons |
|------|------|
| Perfectly accurate sliding window | High memory (stores all timestamps) |
| No boundary burst problem | O(n) cleanup on each check |
| Works well for low-volume strict APIs | Not practical for 10M+ users |

### 3. Sliding Window Counter (Hybrid)

```
Approximation using two fixed windows:

Current window (partial): 40 requests (30% through)
Previous window (full):   80 requests

Weighted count = previous × (1 - elapsed%) + current
               = 80 × (1 - 0.30) + 40
               = 80 × 0.70 + 40
               = 56 + 40
               = 96

Limit = 100 → allow (96 < 100)
```

| Pros | Cons |
|------|------|
| Low memory (2 counters per key) | Approximation, not exact |
| Smooth — no boundary bursts | Slight over/under at boundaries |
| Practical for large-scale systems | More complex than fixed window |

### 4. Token Bucket

```
Bucket holds tokens. Each request consumes 1 token.
Tokens refill at a constant rate.

bucket_capacity = 100 tokens
refill_rate     = 10 tokens/second

Timeline:
  t=0:  bucket = 100 (full)
  t=0:  50 requests arrive → bucket = 50
  t=0:  60 more requests → 50 allowed, 10 rejected
  t=5:  5 seconds pass → bucket = 50 + 50 = 100 (capped at max)
  t=5:  30 requests → bucket = 70

Key insight: allows short bursts up to bucket_capacity
             but sustains only refill_rate long-term
```

| Pros | Cons |
|------|------|
| Allows natural bursting | Two parameters to tune |
| Smooth long-term rate enforcement | State must be stored per user |
| Intuitive mental model | Distributed sync is complex |

### 5. Leaky Bucket

```
Requests flow IN at any rate.
Requests flow OUT at a fixed rate (drip).
Overflow is rejected.

Incoming:  ████████████████████ (bursty)
           │
           ▼
          [   queue   ] ← capacity = 10
           │
           ▼ drip rate = 5 req/sec
Outgoing:  ▐▐▐▐▐▐▐▐▐▐ (steady)

If queue fills up: new requests DROPPED
```

| Pros | Cons |
|------|------|
| Perfectly smooth output | Does not allow bursting |
| Great for rate-sensitive downstream | Queue adds latency |
| Protects slow backends | Requests can wait or be dropped |

### Algorithm Comparison

| Algorithm | Memory | Burst | Smooth | Accuracy | Complexity |
|-----------|--------|-------|--------|----------|------------|
| Fixed Window | Low | Yes (2x) | No | Good | Low |
| Sliding Log | High | No | Yes | Perfect | Medium |
| Sliding Counter | Low | Minimal | Yes | ~99% | Medium |
| Token Bucket | Low | Yes (controlled) | Yes | Good | Medium |
| Leaky Bucket | Low | No | Perfect | Good | Medium |

**Rule of thumb:**
- Most APIs: **Token Bucket** (burst-friendly)
- Strict metering: **Sliding Window Counter**
- Even output stream: **Leaky Bucket**

## Token Bucket Algorithm Flowchart

```mermaid
flowchart TD
    A([Request arrives]) --> B[Calculate tokens to add\nbased on elapsed time]
    B --> C[tokens = min&#40;capacity,\nstored_tokens + refill&#41;]
    C --> D{tokens >= 1?}

    D -- Yes --> E[Deduct 1 token\nStore updated count]
    D -- No --> F[Reject request\nReturn 429]

    E --> G[Process request]
    G --> H([Return 200 OK])

    F --> I[Set Retry-After header]
    I --> J([Return 429 Too Many Requests])

    style A fill:#7c3aed,color:#fff
    style D fill:#2563eb,color:#fff
    style E fill:#059669,color:#fff
    style G fill:#059669,color:#fff
    style H fill:#059669,color:#fff
    style F fill:#ef4444,color:#fff
    style I fill:#ef4444,color:#fff
    style J fill:#ef4444,color:#fff
    style B fill:#374151,color:#fff
    style C fill:#374151,color:#fff
```

## Where to Implement Rate Limiting

### Client-Side (SDK / Application)

```
Mobile App / Frontend SDK
├─ Throttle outgoing requests
├─ Retry with backoff on 429
├─ Cache responses to reduce calls
└─ Show user-facing feedback

✅ Reduces wasted requests
❌ Untrustworthy — clients can bypass
❌ Not a substitute for server-side limiting
```

### API Gateway Layer

```
Internet → [API Gateway] → [Service A]
                         → [Service B]
                         → [Service C]

API Gateway (Kong, AWS API Gateway, Nginx, Envoy):
├─ Rate limit before reaching your code
├─ Single enforcement point
├─ Per-route, per-client, per-plan limits
└─ No changes to application code

✅ Language-agnostic
✅ Centralized policy
✅ Low latency enforcement
```

### Application Layer (In-Code)

```python
# Middleware example
def rate_limit_middleware(request):
    key = f"rate:{request.user_id}"
    count = redis.incr(key)
    if count == 1:
        redis.expire(key, 60)  # 60-second window
    if count > 100:
        return Response(429)
    return next_handler(request)
```

```
✅ Business logic access (e.g., rate by subscription tier)
✅ Fine-grained control
❌ Must implement in every service
❌ Bypassed by direct DB/service calls
```

## Distributed Rate Limiting with Redis

Single server rate limiting is easy. Distributed is hard:

```
Without coordination:
─────────────────────
Server 1: user has 80 requests → allow
Server 2: user has 80 requests → allow
Server 3: user has 80 requests → allow

Reality: user sent 240 requests. Limit was 100.
```

### Solution 1: Redis INCR + EXPIRE (Fixed Window)

```
INCR  rate:user:123:1706745600   → 47
EXPIRE rate:user:123:1706745600  60

# Atomicity problem: INCR and EXPIRE are separate commands
# Use MULTI/EXEC or Lua script
```

### Solution 2: Lua Script (Atomic)

```lua
-- Redis Lua script for token bucket
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill_rate = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local requested = tonumber(ARGV[4])

local bucket = redis.call('HMGET', key, 'tokens', 'last_refill')
local tokens = tonumber(bucket[1]) or capacity
local last_refill = tonumber(bucket[2]) or now

-- Refill tokens based on elapsed time
local elapsed = now - last_refill
local new_tokens = math.min(capacity, tokens + elapsed * refill_rate)

if new_tokens >= requested then
    -- Allow: deduct token
    redis.call('HMSET', key, 'tokens', new_tokens - requested, 'last_refill', now)
    redis.call('EXPIRE', key, 3600)
    return 1  -- allowed
else
    -- Reject
    redis.call('HMSET', key, 'tokens', new_tokens, 'last_refill', now)
    return 0  -- rejected
end
```

Lua scripts execute **atomically** in Redis — no race conditions.

### Solution 3: Redis Cell Module (Recommended)

```
CL.THROTTLE user:123  99  100  60  1
             key      max  rate window requested

Returns:
[0, 100, 99, -1, 0]
 ^   ^    ^   ^   ^
 |   |    |   |   └─ retry after (seconds, -1 if allowed)
 |   |    |   └─ time until bucket full (seconds)
 |   |    └─ tokens remaining
 |   └─ total limit
 └─ 0=allowed, 1=rejected
```

### Distributed Architecture

```mermaid
flowchart LR
    C1[Client] --> LB[Load Balancer]
    C2[Client] --> LB
    C3[Client] --> LB

    LB --> S1[App Server 1]
    LB --> S2[App Server 2]
    LB --> S3[App Server 3]

    S1 --> RC[(Redis Cluster\nRate Limit State)]
    S2 --> RC
    S3 --> RC

    RC --> RS1[(Redis Shard 1\nusers A–M)]
    RC --> RS2[(Redis Shard 2\nusers N–Z)]

    style LB fill:#7c3aed,color:#fff
    style RC fill:#2563eb,color:#fff
    style RS1 fill:#374151,color:#fff
    style RS2 fill:#374151,color:#fff
    style S1 fill:#059669,color:#fff
    style S2 fill:#059669,color:#fff
    style S3 fill:#059669,color:#fff
```

**Tradeoff:** Redis round-trip adds ~1ms latency per request. Use local in-memory counters with periodic Redis sync for ultra-high throughput, accepting slight over-counting.

## Rate Limit Headers

Standard HTTP headers to communicate limits to clients:

```http
HTTP/1.1 200 OK
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 847
X-RateLimit-Reset: 1706745660
X-RateLimit-Policy: 1000;w=3600

HTTP/1.1 429 Too Many Requests
Retry-After: 47
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1706745660
```

| Header | Meaning |
|--------|---------|
| `X-RateLimit-Limit` | Maximum requests allowed in the window |
| `X-RateLimit-Remaining` | Requests left in current window |
| `X-RateLimit-Reset` | Unix timestamp when window resets |
| `Retry-After` | Seconds (or date) to wait before retrying |
| `X-RateLimit-Policy` | Machine-readable policy (IETF draft) |

**Why headers matter:**

```
Well-behaved clients read Retry-After and back off.
Without headers: clients retry immediately → thundering herd on reset
With headers:    clients wait correctly → graceful recovery
```

## Rate Limiting Strategies

### Per-IP Address

```
Limit: 100 req/min per IP

Pros:
✅ No authentication required
✅ Works for anonymous users
✅ Protects login endpoints from brute force

Cons:
❌ NAT: entire office shares one IP → 100 users = 1 req/user
❌ VPN/Tor: attacker rotates IPs
❌ CDN: all traffic from a handful of IPs
```

### Per-User ID

```
Limit: 1000 req/min per authenticated user

Pros:
✅ Fair — each user gets equal quota
✅ Unaffected by IP sharing
✅ Works with VPNs and CDNs

Cons:
❌ Requires authentication first
❌ Attacker creates many accounts
❌ No protection for unauthenticated endpoints
```

### Per-API Key

```
Keys with tiers:
  Free tier:     100 req/day
  Pro tier:     10,000 req/day
  Enterprise: 1,000,000 req/day

Pros:
✅ Monetization-aligned
✅ Revocable per key
✅ Shared keys for teams (company-level limit)

Cons:
❌ Key management overhead
❌ Leaked keys can be abused
```

### Hybrid Strategy (Recommended)

```
Layer 1: Per-IP    — 1000 req/min (DDoS protection)
Layer 2: Per-user  — varies by plan (fair usage)
Layer 3: Per-route — special limits for expensive endpoints

Example:
POST /api/send-sms   → 10 req/min per user
GET  /api/search     → 100 req/min per user
GET  /api/user/:id   → 1000 req/min per user
```

## Rate Limiting Trade-offs

| Dimension | Strict Limiting | Lenient Limiting |
|-----------|----------------|-----------------|
| Protection | Strong against abuse | Weak |
| User experience | Frustrating for power users | Smooth |
| Cost control | Predictable spend | Unpredictable |
| Complexity | Higher (more rules) | Lower |
| False positives | More legitimate traffic blocked | Fewer |

## Practice Exercise

**Design rate limiting for a payment API**

```
Scenario:
- POST /payments processes credit card charges
- GET /payments/history returns transaction history
- 100,000 registered merchants
- Some merchants process 10,000 orders/day (large retailers)
- Most merchants process < 100 orders/day
- Each failed payment attempt costs $0.10

Questions:
1. Which algorithm would you choose?
2. What limits for each endpoint?
3. How would you handle the large retailer use case?
4. What Redis data structure would you use?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
1. Algorithm: Token Bucket
   ─────────────────────────
   POST /payments needs burst tolerance (flash sales)
   Token Bucket allows short bursts while enforcing
   long-term rate — ideal for payment traffic spikes.

2. Limits:
   ────────
   POST /payments:         1,000 req/min per API key (base)
   GET  /payments/history: 10,000 req/min per API key
   POST /payments:         10 req/min per card number
                           (prevent card testing attacks)

3. Large retailers:
   ─────────────────
   Enterprise tier API key: 50,000 req/min
   Or: dynamic limits based on historical average × 2
   Merchants can request quota increases via support ticket.

4. Redis structures:
   ──────────────────
   HASH  rl:apikey:{key}   tokens, last_refill
   STRING rl:card:{hash}   count (INCR + EXPIRE)

   Use Lua script for atomic token bucket operations.
   Shard Redis by API key prefix for scale.
```

</details>

## Interview Tips

- **Start with the why**: mention abuse, cost, fairness before diving into algorithms
- **Token Bucket is usually the right answer** for most system design interviews — burst-friendly, intuitive
- **Mention Redis atomicity**: naive INCR + EXPIRE has a race condition; use Lua scripts
- **Discuss distributed coordination**: the hard part is keeping counters consistent across many servers
- **Cover the 429 response**: always mention `Retry-After` header so clients back off gracefully
- **Layer your defenses**: IP-level blocking at the load balancer, user-level at the API gateway, endpoint-level in the app

## Summary

- **Fixed Window** is simple but has a 2x burst vulnerability at window boundaries
- **Token Bucket** is the industry standard — allows bursts up to bucket capacity, smooth long-term rate
- **Redis with Lua scripts** provides atomic, distributed rate limit state
- **Layer your strategy**: IP + user + endpoint limits protect different threat vectors
- **Always return `Retry-After`** — well-behaved clients will back off instead of hammering
- **API gateways** (Kong, Nginx, AWS API GW) give you rate limiting without touching application code

## Next Steps

Continue to [Circuit Breaker](../21-circuit-breaker/README.md) to learn how to protect services from cascading failures.

---

**Key Takeaway**: Rate limiting is your first line of defence — protect resources, control costs, and ensure fair access. Use Token Bucket + Redis for most production systems.
