# System Design Quick Reference Guide

## Core Principles

```
1. Requirements First
   ├─ Functional requirements (what features)
   ├─ Non-functional requirements (how it performs)
   └─ Make them SMART (Specific, Measurable, Achievable, Relevant, Time-bound)

2. Back-of-Envelope Estimation
   ├─ Calculate QPS (queries per second)
   ├─ Estimate storage needs
   ├─ Bandwidth requirements
   └─ Know the numbers (latencies, throughput)

3. Design Trade-offs
   ├─ Consistency vs Availability (CAP theorem)
   ├─ Latency vs Throughput
   ├─ Simplicity vs Features
   └─ Cost vs Performance

4. Start Simple, Evolve
   ├─ Monolith first
   ├─ Databases: SQL before NoSQL
   ├─ Cache when bottleneck identified
   └─ Microservices when necessary
```

## Key Numbers to Remember

```
Latencies (approximate, 2025):
─────────────────────────────
L1 cache:                    1 ns
Main memory:               100 ns
SSD read:                16,000 ns
Network (same DC):       1,000 ns (1 μs)
Network (across US):    40,000 ns (40 μs)
Network (US ↔ EU):    100,000 ns (100 μs)
Database query:      10,000 ns (10 μs) best case
Disk seek:        2,000,000 ns (2 ms)

Key Point: Memory is 10,000x faster than disk!

Time Conversions:
─────────────────
1 second = 1,000 ms = 1,000,000 μs = 1,000,000,000 ns
1 second = 86,400 seconds/day ≈ 100,000 seconds/day
1 month = 30 days = 2.6 million seconds
1 year = 365 days = 31.5 million seconds

Availability:
─────────────
99%     = 3.65 days down/year
99.9%   = 8.76 hours down/year
99.99%  = 52.56 minutes down/year
99.999% = 5.26 minutes down/year
```

## System Design Checklist

### Phase 1: Requirements (5 mins)

- [ ] Clarify functional requirements
- [ ] Clarify non-functional requirements
- [ ] Ask about scale (users, data, traffic)
- [ ] Ask about consistency needs
- [ ] Ask about latency targets
- [ ] Ask about availability SLA

### Phase 2: Estimation (5 mins)

- [ ] Calculate concurrent users
- [ ] Calculate QPS (read and write)
- [ ] Estimate storage needs
- [ ] Estimate bandwidth
- [ ] Calculate cache size

### Phase 3: High-Level Design (10 mins)

- [ ] Draw basic architecture
- [ ] Show data flow
- [ ] Identify main components
- [ ] Discuss load balancing
- [ ] Discuss caching strategy
- [ ] Discuss database choice

### Phase 4: Deep Dive (15-20 mins)

- [ ] Data model / schema
- [ ] API endpoints
- [ ] Database design
- [ ] Scaling strategy
- [ ] Redundancy / HA
- [ ] Monitoring / alerting

### Phase 5: Bottlenecks (5 mins)

- [ ] Single points of failure
- [ ] Performance bottlenecks
- [ ] Capacity limits
- [ ] Cost optimization

## Architecture Decision Tree

```
What are you building?

Web Application?
├─ YES → Client-Server Architecture
│       ├─ Scale factor?
│       ├─ < 100K users → Vertical + Caching
│       ├─ 100K-1M → Horizontal + Cache
│       └─ > 1M → Sharding + Microservices
│
├─ Real-time? (chat, notifications)
│       ├─ YES → WebSockets / Pub-Sub
│       └─ NO → REST / HTTP
│
├─ File uploads?
│       ├─ YES → CDN + S3/Object Storage
│       └─ NO → Database only
│
Data-heavy?
├─ YES → NoSQL (Cassandra, DynamoDB)
├─ ACID needed? → SQL (PostgreSQL, MySQL)
└─ Both? → Polyglot persistence

High throughput?
├─ Write-heavy (logs, events) → NoSQL
├─ Read-heavy (social feed) → Cache layer
└─ Balanced → SQL + Cache
```

## Technology Choices Quick Reference

```
Database:
─────────
SQL (PostgreSQL, MySQL):
├─ When: ACID transactions needed
├─ Pros: Consistency, Joins, Strong schema
├─ Cons: Harder to scale writes
├─ Examples: Payments, Inventory

NoSQL (MongoDB, DynamoDB):
├─ When: Scale-out write performance
├─ Pros: Scales horizontally, flexible schema
├─ Cons: Weak transactions, complex joins
├─ Examples: User profiles, Feeds

Search (Elasticsearch):
├─ When: Full-text search needed
├─ Pros: Fast searching, aggregations
├─ Cons: Not for transactional data
├─ Examples: Product search, logs

Cache (Redis, Memcached):
├─ When: Data accessed frequently
├─ Pros: Sub-millisecond latency
├─ Cons: Limited size, needs invalidation
├─ Examples: Sessions, Leaderboards

Message Queue (RabbitMQ, Kafka):
├─ When: Async processing needed
├─ Pros: Decouples systems, reliable delivery
├─ Cons: Operational complexity
├─ Examples: Email, Notifications, Events
```

## Common Architecture Patterns

```
Pattern 1: Simple Web App (Small)
──────────────────────────────────
Clients → Load Balancer → App Server → Database
                          (1-3)       └─ Cache

Use: < 100K users

Pattern 2: Scaling Web App (Medium)
─────────────────────────────────
Clients → CDN
          ↓
       Load Balancer → App Servers (5-20)
          ↓                  ↓
       Cache Layer (Redis)   Database
          ↓                  ├─ Primary
          └─────────────────→├─ Replicas
                             └─ Backups

Use: 100K - 1M users

Pattern 3: Distributed System (Large)
──────────────────────────────────────
Users → CDN
         ↓
      API Gateway → Service 1 → Database Shard 1
                    Service 2 → Database Shard 2
                    Service 3 → Database Shard 3
                    ↓
                Message Queue
                    ↓
                Workers (async tasks)

Use: > 1M users

Pattern 4: Global Distribution (Massive)
──────────────────────────────────────────
Users (Global)
    ↓
[Region 1]        [Region 2]        [Region 3]
├─ CDN            ├─ CDN            ├─ CDN
├─ LB             ├─ LB             ├─ LB
├─ Services       ├─ Services       ├─ Services
├─ Cache          ├─ Cache          ├─ Cache
└─ Database       └─ Database       └─ Database
    ↓                 ↓                 ↓
    ├─────────────────┼─────────────────┤
          (Replication across regions)

Use: Global scale (billions of users)
```

## Performance Optimization Checklist

```
At Every Scale:
───────────────
[ ] Use load balancer (distribute traffic)
[ ] Add caching layer (Redis)
[ ] Use CDN for static files
[ ] Database connection pooling
[ ] Implement proper indexing
[ ] Monitor everything (metrics, logs, traces)
[ ] Graceful degradation on failures

When Scaling Database:
──────────────────────
[ ] Read replicas (for reads)
[ ] Replication lag monitoring
[ ] Write sharding plan (when needed)
[ ] Backup strategy
[ ] Disaster recovery plan
[ ] Failover procedures

When Scaling Reads:
───────────────────
[ ] Caching (Redis, Memcached)
[ ] Database read replicas
[ ] Search index (Elasticsearch)
[ ] CDN for content
[ ] Browser caching with proper headers

When Scaling Writes:
────────────────────
[ ] Database sharding (by user, time, region)
[ ] Write buffering / batching
[ ] Async processing (message queues)
[ ] No-SQL for high-volume writes
[ ] Deduplication for idempotency
```

## Common Pitfalls & How to Avoid

```
Pitfall 1: Over-Engineering
──────────────────────────
Problem: Start with microservices, Kubernetes, etc.
Solution: Start simple! Monolith first, refactor when needed.

Pitfall 2: No Monitoring
──────────────────────
Problem: System is slow but don't know why
Solution: Instrument from day 1. Monitor metrics, logs, traces.

Pitfall 3: Single Point of Failure
──────────────────────────────
Problem: One server/database fails = entire system down
Solution: Redundancy, replication, failover

Pitfall 4: Database Becomes Bottleneck
──────────────────────────────────────
Problem: Scales to 1M users, database still single-threaded
Solution: Plan sharding, caching, NoSQL from beginning

Pitfall 5: Ignoring Data Consistency
─────────────────────────────────────
Problem: Money is lost due to race conditions
Solution: Understand CAP theorem, use transactions, test

Pitfall 6: Cache Invalidation
──────────────────────────────
Problem: Users see stale data, can't invalidate properly
Solution: Plan invalidation strategy upfront (TTL + events)

Pitfall 7: No Rate Limiting
────────────────────────────
Problem: DDoS or single user hammers system
Solution: Implement rate limiting early

Pitfall 8: Synchronous Everything
──────────────────────────────────
Problem: Email takes 2 seconds to send, user blocks
Solution: Use async (message queues, background jobs)
```

## Interview Tips

```
First 2 Minutes: Be Boring (Ask Questions!)
────────────────────────────────────────────
❌ Don't: Jump into designing immediately
✅ Do: Ask clarifying questions
   - How many users?
   - What are core features?
   - What's the scale?
   - Consistency or availability?
   - What's the budget?

Middle 30 Minutes: Think Out Loud
──────────────────────────────────
✅ Draw architecture diagrams
✅ Explain reasoning for choices
✅ Discuss trade-offs
✅ Consider scalability
❌ Don't: Give vague handwavy answers

Last 5 Minutes: Discuss Bottlenecks
───────────────────────────────────
✅ Identify single points of failure
✅ Discuss performance bottlenecks
✅ Talk about monitoring/alerting
✅ Ask for feedback

Key Phrases to Use:
──────────────────
"Let me estimate the scale first..."
"This is a trade-off between X and Y..."
"Let's discuss the bottleneck here..."
"We'd monitor X to ensure it's working..."
"If we hit this limit, we'd..."
"The advantage of this approach is..."
"The disadvantage is..."
```

## Common System Design Scenarios

### 1. URL Shortener (bit.ly)
```
Scale: 100M new URLs/month, 100:1 read-write ratio
Approach: Hash function + Database + Cache + CDN
Key Challenge: Generating unique short codes
```

### 2. Twitter/Social Media
```
Scale: 500M users, 6K tweets/sec
Approach: User graph DB + Timeline cache + Search index
Key Challenge: Real-time feed generation at scale
```

### 3. Uber/Ride Sharing
```
Scale: Millions of rides/day, real-time matching
Approach: Geospatial indexing + Real-time tracking + Orders
Key Challenge: Low-latency matching algorithm
```

### 4. Netflix/Video Streaming
```
Scale: Billions of videos, millions of concurrent streams
Approach: CDN + Adaptive bitrate + Recommendations
Key Challenge: Network bandwidth and video encoding
```

### 5. Hotel Booking (Airbnb)
```
Scale: Millions of listings, high consistency needed
Approach: Distributed database + Search index + Booking service
Key Challenge: Dealing with overbooking and consistency
```

### 6. Google Search
```
Scale: Billions of documents, sub-second response
Approach: Inverted index + Distributed crawling + Ranking
Key Challenge: Relevance and freshness at scale
```

## Final Tips

```
Remember:
─────────
✅ There are no perfect solutions, only trade-offs
✅ Start simple, add complexity only when needed
✅ Measure before optimizing
✅ Understand your constraints (budget, timeline, team)
✅ Document assumptions and decisions

Practice:
─────────
✅ Design 2-3 systems a week (for interviews)
✅ Sketch architecture on paper first
✅ Discuss with others (rubber duck debugging)
✅ Read real architecture blogs (High Scalability)
✅ Study how real companies built their systems

Mindset:
────────
✅ Think about scale before implementing
✅ Consider failure modes
✅ Ask "what if this fails?" constantly
✅ Understand your database inside/out
✅ Know the CAP theorem implications for your system
```

---

## Quick Reference Links

- [Introduction to System Design](./01-introduction/README.md) - Start here
- [Requirements Gathering](./02-requirements/README.md) - Clarify needs
- [Capacity Estimation](./03-capacity-estimation/README.md) - Calculate scale
- [API Design](./04-api-design/README.md) - Design interfaces
- [Networking Basics](./05-networking/README.md) - Understand networks
- [Client-Server Architecture](./06-client-server/README.md) - Fundamental pattern
- [CAP Theorem](./07-cap-theorem/README.md) - Understand trade-offs
- [Horizontal vs Vertical Scaling](./09-scaling/README.md) - Scale systems
- [Load Balancing](./10-load-balancing/README.md) - Distribute load
- [Caching Strategies](./11-caching/README.md) - Improve performance

---

**Remember**: System design is about making informed trade-offs. There's no "perfect" answer, only better decisions given constraints.
