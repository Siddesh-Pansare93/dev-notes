const path = require('path');

// Port configuration
const PORT = process.env.PORT || 4000;

// Content root is the parent directory (D:\development\learn)
const CONTENT_ROOT = path.resolve(__dirname, '..', '..');

// Directories to exclude from the file tree
const EXCLUDED = new Set(['app', 'node_modules', '.git', '.vscode', '.idea']);

// Topic icons for the landing page
const TOPIC_ICONS = {
  react: '⚛️', typescript: '🔷', python: '🐍', javascript: '🟨',
  flutter: '💙', flutter_dart: '💙', dart: '💙',
  devops: '🚀', devOPS: '🚀', postgresql: '🐘', sql: '🐘',
  system_design: '🏗️', 'system design': '🏗️',
  api_security: '🔐', security: '🔐', api: '🔌',
  computer_networks: '🌐', networks: '🌐',
  operating_systems: '💻', 'operating systems': '💻',
  docker: '🐳', kubernetes: '☸️', git: '🌿',
  rust: '🦀', go: '🐹', java: '☕',
};

module.exports = {
  PORT,
  CONTENT_ROOT,
  EXCLUDED,
  TOPIC_ICONS,
};
