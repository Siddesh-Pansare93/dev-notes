"""
Script to find and list ASCII diagrams that appear after Mermaid diagrams.
This will help us manually remove them.
"""

import re

files_to_process = [
    "postgresql/01-fundamentals/03-architecture.md",
    "postgresql/05-joins-and-relationships/01-joins.md",
    "postgresql/15-replication-ha/03-high-availability.md",
    "python/07_langchain/01_introduction.md",
    "python/09_production_patterns/01_project_architecture.md",
    "python/09_production_patterns/05_monitoring.md",
    "python/10_agentic_ai/04_production_deployment.md",
    "system_design/05-networking/README.md",
    "system_design/06-client-server/README.md",
    "system_design/07-cap-theorem/README.md",
    "system_design/08-consistency/README.md",
    "system_design/09-scaling/README.md",
    "system_design/10-load-balancing/README.md",
    "system_design/11-caching/README.md",
    "system_design/12-cdn/README.md",
    "system_design/13-databases/README.md",
    "system_design/15-sharding/README.md",
    "system_design/16-replication/README.md",
    "system_design/17-microservices/README.md",
    "system_design/18-message-queues/README.md",
    "system_design/19-api-gateway/README.md",
    "system_design/20-rate-limiting/README.md",
    "system_design/21-circuit-breaker/README.md",
    "system_design/22-real-time/README.md",
    "system_design/23-url-shortener/README.md",
    "system_design/24-design-twitter/README.md",
    "system_design/25-event-driven/README.md",
    "system_design/26-monitoring/README.md",
    "system_design/27-design-netflix/README.md",
    "system_design/28-design-uber/README.md",
    "system_design/29-consensus-algorithms/README.md",
    "system_design/33-auth/README.md",
    "typescript/03-typescript-with-react/06-react-fiber-architecture-internals.md",
]

for filepath in files_to_process:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
            lines = content.split("\n")

        # Find where Mermaid blocks are
        in_mermaid = False
        mermaid_end_line = -1
        ascii_blocks = []

        for i, line in enumerate(lines):
            if "```mermaid" in line:
                in_mermaid = True
            elif in_mermaid and line.strip() == "```":
                in_mermaid = False
                mermaid_end_line = i
            elif mermaid_end_line > 0 and i - mermaid_end_line < 10:
                # Check if this line starts an ASCII diagram block
                if line.strip() == "```" and not in_mermaid:
                    # Look ahead for ASCII characters
                    for j in range(i + 1, min(i + 30, len(lines))):
                        if re.search(r"[┌└├│→▼▲►◄↓]", lines[j]):
                            ascii_blocks.append((i, j, filepath))
                            mermaid_end_line = -1
                            break
                        if lines[j].strip() == "```":
                            break

        if ascii_blocks:
            print(f"\n{filepath}:")
            print(f"  Found {len(ascii_blocks)} ASCII diagram(s) after Mermaid")
            for start, end, _ in ascii_blocks:
                print(f"    Lines {start + 1}-{end + 1}")

    except Exception as e:
        print(f"Error processing {filepath}: {e}")

print("\nDone!")
