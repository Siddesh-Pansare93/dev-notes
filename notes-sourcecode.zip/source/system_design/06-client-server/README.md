# Client-Server Architecture

## Fundamental Model

Client-Server is the most basic architecture for networked systems:

```mermaid
flowchart LR
    subgraph CLIENT["CLIENT"]
        C1["• Browser"]
        C2["• Mobile"]
        C3["• Desktop"]
    end
    
    subgraph SERVER["SERVER"]
        S1["• Process"]
        S2["• Database"]
        S3["• Storage"]
    end
    
    CLIENT -->|"Request"| SERVER
    SERVER -->|"Response"| CLIENT
```

**Flow:**
1. Client initiates request
2. Server processes request
3. Server sends response
4. Client receives and displays response

## Characteristics

```
Stateless:
──────────
✅ Server doesn't store client context
✅ Each request is independent
✅ Easier to scale (can distribute to many servers)
❌ Client must send all info each request

Request-Response:
─────────────────
✅ Clear model: client asks, server answers
✅ Easy to understand and debug
✅ Works with HTTP/REST

Server-Centric:
───────────────
✅ Server is the source of truth
✅ Enforces business logic
✅ Can protect sensitive data

Separation of Concerns:
──────────────────────
✅ Client handles UI/UX
✅ Server handles data/logic
✅ Can evolve independently (mostly)
```

## Basic Client-Server Flow

### Web Browser Example

```
User Action (Click "Get User")
           │
           ▼
Browser JavaScript
           │
           ├─ Create HTTP Request
           │  GET /api/users/123
           │  Headers: Authorization: Bearer token...
           │
           ▼
Network (TCP → HTTP)
           │
           ├─ DNS lookup: api.example.com → 93.184.216.1
           ├─ TCP handshake (3-way)
           ├─ TLS handshake (for HTTPS)
           ├─ Send request
           │
           ▼
Server
           │
           ├─ Parse request
           ├─ Authenticate (verify token)
           ├─ Authorize (check permissions)
           ├─ Query database
           ├─ Process data
           │
           ▼
Response
           │
           ├─ JSON: { "id": 123, "name": "John" }
           ├─ Status: 200 OK
           │
           ▼
Network (HTTP → Client)
           │
           ▼
Browser
           │
           ├─ Parse JSON
           ├─ Update DOM
           ├─ Render to screen
           │
           ▼
User sees result
```

## Evolution: Adding Servers

### Single Server (Initial Scale)

```
┌────────────────────────┐
│  10 Users              │
│  1 Server              │
│  1 Database            │
└────────────────────────┘

Clients:
  └─> Server (handles all requests)
      └─> Database
```

**Problems:**
- Single point of failure
- Limited concurrent connections
- Can't scale up much
- Eventually becomes too slow

### Multiple Application Servers

```
┌────────────────────────────────┐
│  1,000 Users                    │
│  Load Balancer                 │
│  Multiple App Servers          │
│  1 Database                    │
└────────────────────────────────┘

Clients:
    └─> Load Balancer
        ├─> App Server 1
        ├─> App Server 2
        └─> App Server 3
           │
           └─> Database (single, bottleneck!)
```

**Improvements:**
- Can handle more concurrent users
- Can do rolling updates
- Load distributed across servers

**New Problem:**
- Database is now bottleneck
- Database has limits on connections, throughput

### Scaling Database

```
┌────────────────────────────────┐
│  10,000 Users                   │
│  Load Balancer                 │
│  Multiple App Servers          │
│  Database Replication          │
│  Caching Layer                 │
└────────────────────────────────┘

Clients:
    └─> Load Balancer
        ├─> App Server 1
        ├─> App Server 2
        └─> App Server 3
           │
           ├─> Cache (Redis)
           │
           └─> Database (Primary/Replicas)
               ├─> Primary (Writes)
               ├─> Replica 1 (Reads)
               └─> Replica 2 (Reads)
```

## Session Management

### Problem: Stateless Servers

```
Request 1: User logs in
           Client sends username/password
           Server validates
           Server: "OK, you're logged in"
           ❌ But next request, server forgot!

Request 2: Client asks for profile
           Server: "Who are you? Not logged in!"
           ❌ User must log in again!

Solution: Sessions
```

### Session Storage

#### Option 1: Client-Side Sessions (Cookies + Signed Data)

```
Login Request:
  Client → Server: username, password

  Server:
    1. Validate credentials
    2. Create session data:
       {
         "userId": 123,
         "username": "john",
         "expiresAt": 1234567890
       }
    3. Sign with secret key (prevents tampering)
    4. Send to client as cookie

Subsequent Request:
  Client → Server: GET /profile (with cookie)

  Server:
    1. Read cookie
    2. Verify signature
    3. Extract userId
    4. Process request

Pros:
✅ Stateless (no server-side session storage)
✅ Can scale easily
✅ Works across multiple servers

Cons:
❌ Larger cookie size
❌ Can't revoke session immediately
❌ Must store all user info in token

Example: JWT tokens
```

#### Option 2: Server-Side Sessions

```
Login Request:
  Client → Server: username, password

  Server:
    1. Validate credentials
    2. Create session:
       sessions[sessionId] = {
         "userId": 123,
         "username": "john",
         "createdAt": 1234567890
       }
    3. Send sessionId to client as cookie

Subsequent Request:
  Client → Server: GET /profile (with sessionId)

  Server:
    1. Look up sessionId in memory/cache
    2. Get userId
    3. Process request

Pros:
✅ Sessions can be revoked immediately
✅ Can store large amounts of data
✅ More secure (token doesn't contain data)

Cons:
❌ Stateful (need to store sessions)
❌ Hard to scale (session sharing needed)
❌ Memory usage grows with users

Solutions for scaling:
├─ Session storage in Redis (shared across servers)
├─ Sticky sessions (same user always goes to same server)
└─ Database session storage (slower)
```

### Sticky Sessions Example

```
User 1 → Load Balancer → Server 1 (stores session)
User 1 → Load Balancer → Server 1 (same server, can read session)
User 2 → Load Balancer → Server 2 (stores session)

Problem:
────────
If Server 1 crashes, User 1's session is lost
Load Balancer forces them to Server 3
Server 3 doesn't have their session data

Better: Use Redis to share sessions
─────────────────────────────────────
User 1 → Server 1 → Redis (store session)
User 1 → Server 3 → Redis (read session, works!)
```

## Polling vs Pushing

### Polling (Client Pulls Data)

```
Client                          Server
  │                              │
  ├─ What's new? ───────────────>│
  │                              │
  │<─────── No new data ─────────┤
  │                              │
  ├─ What's new? ───────────────>│
  │                              │
  │<─────── No new data ─────────┤
  │                              │
  ├─ What's new? ───────────────>│
  │                              │
  │<─ New message available ─────┤

Pros:
✅ Simple to implement
✅ Client controls frequency
✅ Works with HTTP

Cons:
❌ Wasted requests (many return nothing)
❌ Latency (new data delayed by poll interval)
❌ Server load increases with more clients

Use Case: Checking email occasionally
```

### Pushing (Server Sends Data)

```
Client                          Server
  │                              │
  ├─ Connect ────────────────────>│
  │<───── Connection open ────────┤
  │                              │
  │   (Server actively sends data when available)
  │                              │
  │<─ New message ────────────────┤
  │                              │
  │<─ New notification ───────────┤

Pros:
✅ Low latency
✅ No wasted requests
✅ Real-time feel

Cons:
❌ More complex to implement
❌ Need persistent connection
❌ Higher server resource usage

Technologies:
├─ WebSocket (full-duplex)
├─ Server-Sent Events (one-way push)
└─ Long polling (fake push using HTTP)

Use Case: Real-time chat, notifications
```

## Synchronous vs Asynchronous Communication

### Synchronous (Request-Response)

```
Client                          Server
  │                              │
  ├─ Request ────────────────────>│
  │  (waits here)                 │
  │                              │
  │                  (Server processes)
  │                              │
  │<────────── Response ──────────┤
  │  (resumes)                    │

Timeline:
─────────
t=0: Client sends request
t=5: Server processes (client blocks)
t=6: Server sends response
t=6: Client continues (total wait: 6 seconds)

Pros:
✅ Simple to reason about
✅ Immediate feedback
✅ Errors returned immediately

Cons:
❌ Client blocks waiting
❌ Server must be responsive
❌ Coupling between client/server
❌ Slow if server is slow

Use Case: Web forms, search, payments
```

### Asynchronous (Fire and Forget)

```
Client                          Server
  │                              │
  ├─ Request ────────────────────>│
  │  (continues immediately)      │
  │                              │
  │                  (Server processes in background)
  │                              │
  │<─────── ACK (received) ───────┤
  │                              │
  │                              │
  (No waiting for actual result)

Timeline:
─────────
t=0: Client sends request
t=0: Client continues (no wait)
t=0.1: Server ACKs
t=5: Server processes in background
t=5: Client never knows about response

Implementation:
────────────────
├─ Queue task on server
├─ Respond immediately to client
└─ Process task asynchronously

Pros:
✅ Client doesn't block
✅ High throughput
✅ Loose coupling

Cons:
❌ No immediate feedback
❌ Error handling complex
❌ Harder to test

Use Case: Email sending, data processing, background jobs
```

## Typical Web Application Architecture

```mermaid
graph TD
    Client[Client Layer<br/>Browser / Mobile] -->|HTTPS| CDN[CDN<br/>Static Assets]
    CDN -->|Dynamic Requests| LB{Load Balancer}
    
    LB --> App1[App Server 1]
    LB --> App2[App Server 2]
    LB --> App3[App Server 3]
    
    App1 --> Cache[(Redis Cache)]
    App2 --> Cache
    App3 --> Cache
    
    App1 --> DB[(Database Primary)]
    App2 --> DB
    App3 --> DB
    
    DB -.->|Replication| Replica1[(DB Replica 1)]
    DB -.->|Replication| Replica2[(DB Replica 2)]
    
    style Client fill:#3b82f6,stroke:#2563eb,color:#fff
    style CDN fill:#8b5cf6,stroke:#1d4ed8,color:#fff
    style LB fill:#F5A623,stroke:#B8520A,color:#fff
    style App1 fill:#1A1D28,stroke:#F5A623
    style App2 fill:#1A1D28,stroke:#F5A623
    style App3 fill:#1A1D28,stroke:#F5A623
    style Cache fill:#ef4444,stroke:#b91c1c,color:#fff
    style DB fill:#10b981,stroke:#047857,color:#fff
    style Replica1 fill:#1A1D28,stroke:#10b981
    style Replica2 fill:#1A1D28,stroke:#10b981
```

## Best Practices

```
For Server:
───────────
✅ Keep servers stateless when possible
✅ Use load balancer for distribution
✅ Implement proper session management
✅ Cache frequently accessed data
✅ Replicate database for availability
✅ Monitor server health
✅ Handle graceful shutdown

For Client:
───────────
✅ Handle network errors gracefully
✅ Implement exponential backoff for retries
✅ Use connection pooling
✅ Cache responses when safe
✅ Implement optimistic UI updates
✅ Don't block on long operations
```

## Practice Exercise

**Design Session Management for a Web App**

Scenario:
```
- 100,000 concurrent users
- Users stay logged in for ~30 minutes
- Need to support 5 app servers
- Users should stay logged in if one server crashes

Decision:
1. Client-side (JWT) or Server-side sessions?
2. Where to store sessions?
3. How to handle session expiration?
4. How to revoke a session immediately?
```

<details>
<summary>Solution (Click to Expand)</summary>

```
Recommendation: Hybrid Approach

1. JWT tokens (client-side):
   ─────────────────────────
   - Fast verification (no database lookup)
   - Can be used across servers
   - Contains: userId, permissions, expiresAt

2. Session store (server-side):
   ──────────────────────────
   - Redis for fast access
   - Contains: additional user data, flags
   - TTL: 30 minutes

3. Revocation:
   ───────────
   - Add to Redis blacklist when user logs out
   - Check blacklist before accepting token
   - TTL on blacklist: token expiration time

Implementation:
───────────────
Login:
├─ Authenticate user
├─ Create JWT token
├─ Store minimal session in Redis
└─ Return token to client

Each Request:
├─ Client sends JWT
├─ Server verifies JWT signature
├─ Check if token in blacklist (Redis)
├─ Extract userId from token
├─ Load additional data from Redis (if needed)
└─ Process request

Logout:
├─ Add token to blacklist (Redis)
├─ TTL: token expiration time
└─ Return success

Server Crash:
├─ Another server receives request
├─ Verifies JWT (works, signature valid)
├─ Checks Redis blacklist (shared across servers)
└─ Request succeeds
```

</details>

## Summary

- **Client-Server is fundamental**: Separate presentation from data
- **Stateless servers scale better**: But may need caching for sessions
- **Use load balancers**: Distribute traffic across servers
- **Session management is crucial**: Choose approach based on needs
- **Consider sync vs async**: Different latency/throughput trade-offs
- **Typical architecture is layered**: CDN → LB → App Servers → Cache → Database

## Next Steps

Continue to [Scaling](../09-scaling/README.md) to learn how to handle growing traffic.

---

**Key Takeaway**: Client-Server is simple but powerful. Master it before moving to more complex architectures.
