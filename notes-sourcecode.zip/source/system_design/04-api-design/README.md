# API Design

## What is a Good API?

A good API is:

- **Clear**: Easy to understand and use
- **Consistent**: Follows predictable patterns
- **Documented**: Clear documentation with examples
- **Versioned**: Can evolve without breaking clients
- **Secure**: Prevents abuse and protects data
- **Performant**: Low latency, high throughput

## REST vs GraphQL vs gRPC

### REST (Representational State Transfer)

**Pros:**
- Simple and widely understood
- Great for CRUD operations
- Stateless and cacheable
- Works well with HTTP

**Cons:**
- Over-fetching (get more data than needed)
- Under-fetching (need multiple requests)
- Complex filtering requires query parameters

**Example:**
```
GET /api/v1/users/123
GET /api/v1/users/123/posts
GET /api/v1/users/123/posts?limit=10&sort=-created_at
```

### GraphQL

**Pros:**
- Request exactly what you need
- Strongly typed schema
- Single query for complex operations
- Great for mobile clients

**Cons:**
- Steeper learning curve
- Caching is more complex
- Query complexity attacks possible
- Overkill for simple CRUD

**Example:**
```graphql
query {
  user(id: 123) {
    name
    email
    posts(limit: 10) {
      id
      title
      createdAt
    }
  }
}
```

### gRPC

**Pros:**
- Very fast (HTTP/2, binary protocol)
- Strongly typed (Protocol Buffers)
- Perfect for service-to-service communication
- Built-in streaming

**Cons:**
- Not suitable for browsers
- Steeper learning curve
- Requires protocol buffer definitions
- Less human-readable

**Example:**
```protobuf
service UserService {
  rpc GetUser (GetUserRequest) returns (User) {}
  rpc ListPosts (ListPostsRequest) returns (stream Post) {}
}
```

## Choosing Your API Style

```
Use REST when:
─────────────
✅ Building public APIs
✅ Clients are web browsers
✅ CRUD-heavy operations
✅ Caching is important
✅ Team is familiar with REST

Use GraphQL when:
─────────────────
✅ Multiple client types with different needs
✅ Mobile clients with limited bandwidth
✅ Complex nested data relationships
✅ Need flexible querying

Use gRPC when:
──────────────
✅ Service-to-service communication
✅ Performance is critical
✅ Need streaming
✅ Internal systems only
```

## RESTful API Design Principles

### 1. Resource-Oriented Design

Think in terms of resources, not actions.

```
❌ Bad (action-oriented):
GET /api/getUser/123
GET /api/createPost
POST /api/deleteUser

✅ Good (resource-oriented):
GET /api/users/123
POST /api/posts
DELETE /api/users/123
```

### 2. HTTP Methods

Use the right HTTP method for the operation:

```
GET     - Retrieve a resource (safe, idempotent)
POST    - Create a new resource
PUT     - Replace entire resource (idempotent)
PATCH   - Partial update to resource
DELETE  - Remove a resource (idempotent)
HEAD    - Like GET but no response body
OPTIONS - Describe communication options
```

**Example: Blog Post API**
```
GET    /api/v1/posts         - List all posts
POST   /api/v1/posts         - Create new post
GET    /api/v1/posts/123     - Get post by ID
PUT    /api/v1/posts/123     - Replace entire post
PATCH  /api/v1/posts/123     - Update post (partial)
DELETE /api/v1/posts/123     - Delete post
```

### 3. Status Codes

Use appropriate HTTP status codes:

```
2xx - Success
────────────
200 OK              - Request successful
201 Created         - Resource created (POST)
204 No Content      - Success, no response body (DELETE)

3xx - Redirection
──────────────────
301 Moved Permanently
304 Not Modified    - Use cached version
307 Temporary Redirect

4xx - Client Error
───────────────────
400 Bad Request     - Invalid parameters
401 Unauthorized    - Authentication required
403 Forbidden       - User lacks permission
404 Not Found       - Resource doesn't exist
409 Conflict        - Request conflicts (duplicate)
429 Too Many Requests - Rate limited

5xx - Server Error
──────────────────
500 Internal Server Error
503 Service Unavailable
```

### 4. Request/Response Format

Use JSON consistently:

```json
// POST /api/v1/posts
// Request
{
  "title": "My First Post",
  "content": "Hello World",
  "tags": ["nodejs", "api"],
  "isDraft": false
}

// Response (201 Created)
{
  "id": "post_123",
  "title": "My First Post",
  "content": "Hello World",
  "tags": ["nodejs", "api"],
  "isDraft": false,
  "createdAt": "2025-02-10T10:30:00Z",
  "updatedAt": "2025-02-10T10:30:00Z"
}
```

### 5. Pagination

Always paginate large results:

```
❌ Bad: Return all 1M records

✅ Good: Return paginated results
GET /api/v1/posts?page=1&limit=20

Response:
{
  "data": [
    { "id": 1, "title": "Post 1" },
    { "id": 2, "title": "Post 2" },
    ...
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 1000,
    "hasNext": true
  }
}
```

### 6. Filtering and Sorting

Support common query operations:

```
Filtering:
──────────
GET /api/v1/posts?status=published&author=john
GET /api/v1/users?minAge=18&maxAge=65

Sorting:
────────
GET /api/v1/posts?sort=created_at
GET /api/v1/posts?sort=-created_at  (descending)

Searching:
──────────
GET /api/v1/posts?search=nodejs
GET /api/v1/users?q=john%20doe
```

## API Versioning

Always version your APIs:

```
Strategy 1: URL Path (Recommended)
──────────────────────────────────
GET /api/v1/users
GET /api/v2/users

Strategy 2: Query Parameter
────────────────────────────
GET /api/users?version=1
GET /api/users?version=2

Strategy 3: Header
──────────────────
GET /api/users
Header: API-Version: 1

Recommendation: Use URL path for clarity and cacheability
```

### Version Deprecation

```
Plan your versions:

v1: Launch
v2: Breaking changes, announce deprecation
    - Endpoint available for 12 months
    - Send deprecation warning header

v3: Available
v1: No longer supported
    - Return 410 Gone

Timeline:
- Version launch
- 12 months until deprecation
- 6 months until removal
```

## Error Handling

Consistent error responses:

```json
// Error Response
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      },
      {
        "field": "age",
        "message": "Age must be at least 18"
      }
    ]
  },
  "timestamp": "2025-02-10T10:30:00Z",
  "requestId": "req_abc123"
}
```

## Authentication & Authorization

### API Keys

```
Simple key-based authentication:

Request:
────────
GET /api/v1/users
Header: X-API-Key: sk_live_a1b2c3d4e5f6

Pros:
✅ Simple to implement
✅ Good for development
✅ Works well for public APIs

Cons:
❌ Less secure
❌ Hard to rotate
❌ Can't be revoked per request
```

### OAuth 2.0

```
Standard for user delegation:

Flow:
─────
1. User clicks "Sign in with Google"
2. Redirects to Google login
3. User grants permission
4. Redirect back with code
5. Exchange code for token
6. Use token in API requests

Header:
───────
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...

Pros:
✅ Industry standard
✅ User never shares password
✅ Easy to revoke access

Cons:
❌ More complex to implement
❌ Requires careful handling
```

### JWT (JSON Web Tokens)

```
Stateless token authentication:

Token Structure:
────────────────
Header.Payload.Signature
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.
eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.
TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ

Payload (decoded):
──────────────────
{
  "sub": "user_123",
  "name": "John Doe",
  "email": "john@example.com",
  "iat": 1516239022,
  "exp": 1516242622
}

Usage:
──────
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...

Pros:
✅ Stateless
✅ Can contain user info
✅ Works across services
✅ Easy to scale

Cons:
❌ Tokens can't be revoked immediately
❌ Larger payload size
```

## Rate Limiting

Prevent abuse and ensure fair resource usage:

```
Strategy 1: Token Bucket
─────────────────────────
- User has bucket of tokens
- Requests consume tokens
- Bucket refills at fixed rate
- Common: 1000 requests/minute

Strategy 2: Sliding Window
───────────────────────────
- Count requests in last X seconds
- Reject if exceeds limit

Header Response:
────────────────
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1612938600

Error When Limited (429):
──────────────────────────
{
  "error": "Too Many Requests",
  "retryAfter": 60
}
```

## API Documentation

Always document your API:

### Swagger/OpenAPI Example

```yaml
openapi: 3.0.0
info:
  title: Blog API
  version: 1.0.0

paths:
  /posts:
    get:
      summary: List all posts
      parameters:
        - name: limit
          in: query
          schema:
            type: integer
            default: 20
        - name: offset
          in: query
          schema:
            type: integer
            default: 0
      responses:
        '200':
          description: List of posts
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/Post'
    post:
      summary: Create a new post
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreatePostRequest'
      responses:
        '201':
          description: Post created
        '400':
          description: Invalid request

components:
  schemas:
    Post:
      type: object
      properties:
        id:
          type: string
        title:
          type: string
        content:
          type: string
        createdAt:
          type: string
          format: date-time
```

## API Design Checklist

```
Before Launch:
───────────────
[ ] Consistent naming conventions
[ ] Proper HTTP methods and status codes
[ ] Pagination for large collections
[ ] Filtering and sorting support
[ ] Error handling with clear messages
[ ] Rate limiting enabled
[ ] API versioning strategy
[ ] Authentication/authorization implemented
[ ] HTTPS enforced
[ ] CORS properly configured

Documentation:
───────────────
[ ] Swagger/OpenAPI spec
[ ] Usage examples
[ ] Authentication guide
[ ] Error codes reference
[ ] Rate limit details
[ ] Changelog for versions

Testing:
─────────
[ ] Happy path tests
[ ] Error case tests
[ ] Edge cases
[ ] Load testing
[ ] Security testing
```

## Real-World Example: Twitter API

```
Endpoints:
──────────
GET    /api/v2/tweets              - List tweets
POST   /api/v2/tweets              - Create tweet
GET    /api/v2/tweets/:id          - Get single tweet
DELETE /api/v2/tweets/:id          - Delete tweet

GET    /api/v2/users/:id           - Get user
GET    /api/v2/users/:id/tweets    - Get user's tweets

GET    /api/v2/tweets/:id/liking_users  - Who liked it
POST   /api/v2/tweets/:id/likes    - Like a tweet
DELETE /api/v2/tweets/:id/likes    - Unlike a tweet

Query Parameters:
─────────────────
?max_results=10        - Limit results
?pagination_token=abc  - For pagination
?tweet.fields=created_at,author_id,public_metrics
?expansions=author_id

Response Format:
────────────────
{
  "data": [
    {
      "id": "1234567890",
      "text": "Hello World",
      "author_id": "1000",
      "created_at": "2025-02-10T10:30:00.000Z"
    }
  ],
  "includes": {
    "users": [
      {
        "id": "1000",
        "name": "John Doe",
        "username": "johndoe"
      }
    ]
  },
  "meta": {
    "result_count": 1,
    "newest_id": "1234567890",
    "oldest_id": "1234567890"
  }
}
```

## Common API Mistakes

```
❌ Using GET for modifications
   GET /api/delete?id=123
✅ Use DELETE method
   DELETE /api/users/123

❌ Inconsistent naming
   /api/users/123/getPosts
✅ Use consistent patterns
   /api/users/123/posts

❌ No versioning
✅ Version from day one
   /api/v1/...

❌ Returning 200 for errors
✅ Use appropriate status codes
   400 Bad Request, 500 Internal Server Error

❌ Returning paginated data without limits
✅ Always paginate
   Limit: 20, Offset: 0

❌ No documentation
✅ Generate OpenAPI/Swagger specs

❌ No rate limiting
✅ Implement rate limiting early
```

## Practice Exercise

**Design an API for a Photo Sharing App**

Requirements:
```
1. Upload a photo
2. Get a photo by ID
3. List user's photos
4. Like a photo
5. Delete a photo
6. Search photos by tag
```

Design:
```
- What endpoints do you need?
- What HTTP methods?
- What query parameters?
- What request/response format?
- How will you handle errors?
```

<details>
<summary>Example Solution (Click to Expand)</summary>

```
Endpoints:
──────────
POST   /api/v1/photos                    - Upload photo
GET    /api/v1/photos/:id                - Get photo
GET    /api/v1/users/:userId/photos      - List user's photos
POST   /api/v1/photos/:id/likes          - Like photo
DELETE /api/v1/photos/:id/likes          - Unlike photo
DELETE /api/v1/photos/:id                - Delete photo
GET    /api/v1/photos                    - Search by tag

Query Parameters:
─────────────────
GET /api/v1/users/:userId/photos?limit=20&offset=0
GET /api/v1/photos?tag=nature&tag=landscape&sort=-created_at

Request Body (Upload):
──────────────────────
POST /api/v1/photos
{
  "title": "My Photo",
  "description": "Beautiful sunset",
  "tags": ["nature", "sunset"],
  "file": "[base64 encoded image]"
}

Response (200 OK):
───────────────────
{
  "id": "photo_123",
  "userId": "user_456",
  "title": "My Photo",
  "description": "Beautiful sunset",
  "tags": ["nature", "sunset"],
  "url": "https://cdn.example.com/photos/photo_123.jpg",
  "likes": 42,
  "createdAt": "2025-02-10T10:30:00Z"
}
```

</details>

## Summary

- **Choose the right API style**: REST for most cases, GraphQL for complex queries, gRPC for services
- **Be consistent**: Naming, structure, error handling
- **Version from day one**: Make deprecation path clear
- **Secure properly**: Use OAuth/JWT, enforce HTTPS
- **Rate limit**: Prevent abuse
- **Document everything**: Use Swagger/OpenAPI
- **Test thoroughly**: Happy paths and edge cases

## Next Steps

Continue to [Networking Basics](../05-networking/README.md) to understand how data flows across networks.

---

**Key Takeaway**: A well-designed API is the face of your system. Invest time in getting it right.
