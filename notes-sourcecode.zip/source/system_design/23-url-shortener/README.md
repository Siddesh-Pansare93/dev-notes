# Case Study: URL Shortener

## What We Are Building

```
Input:  https://www.example.com/very/long/path?with=many&query=params&that=nobody#wants-to-type
Output: https://sho.rt/aB3xY9

User visits sho.rt/aB3xY9 → redirected to the original URL instantly
```

Classic examples: bit.ly, tinyurl.com, t.co (Twitter), goo.gl (retired)

## Step 1: Requirements

### Functional Requirements

```
Core features:
──────────────
1. POST /shorten  — given a long URL, return a short code
2. GET  /{code}   — redirect to the original URL
3. Custom aliases — user can request /my-promo instead of /aB3xY9
4. Expiry         — links can have an optional expiration date
5. Analytics      — track click count, referrer, geo (optional tier)
```

### Non-Functional Requirements

```
Scale targets:
──────────────
New URLs created:    100 million total links
Write QPS:           200 writes/second (new short links)
Read QPS:            20,000 reads/second (redirects)
Read:Write ratio:    100:1

Latency:
─────────
Redirect latency:    < 10ms p99 (user is waiting)
Shortening latency:  < 100ms   (acceptable)

Availability:
─────────────
Redirects:    99.99% (links shared publicly — downtime = broken links)
Shortening:   99.9%  (user-facing but less critical)

Durability:
───────────
Links must never be lost or corrupted once created
```

### Out of Scope

```
❌ User accounts / authentication (assume API key only)
❌ Link editing after creation
❌ GDPR / link deletion (real system needs this)
❌ Spam/malware filtering (real system needs this)
```

## Step 2: Capacity Estimation

```
Storage:
────────
100 million URLs
Each record:
  short_code: 7 chars   =   7 bytes
  long_url:   ~200 chars = 200 bytes
  created_at: timestamp =   8 bytes
  expiry:     timestamp =   8 bytes
  user_id:    bigint    =   8 bytes
  click_count: bigint   =   8 bytes
Total per row:          ≈ 239 bytes

100M × 239 bytes = 23.9 GB → fits on one server, replicated across 3

Traffic:
────────
Write: 200 req/s × 86,400 s/day = 17.3M writes/day
Read:  20,000 req/s (peak, redirect traffic)

Bandwidth:
──────────
Read: 20,000 req/s × 500 bytes (redirect response) = 10 MB/s
Write: 200 req/s × 1 KB = 200 KB/s

Cache:
──────
Top 20% URLs drive 80% of traffic (Pareto)
20% of 100M = 20M URLs cached
20M × 239 bytes = 4.8 GB → fits in Redis on one server
```

## Step 3: API Design

### POST /api/v1/shorten

```
Request:
────────
POST /api/v1/shorten
Authorization: Bearer {api_key}
Content-Type: application/json

{
  "long_url":    "https://example.com/very/long/path",
  "custom_alias": "my-promo",          // optional
  "expires_at":  "2026-12-31T23:59:59Z" // optional
}

Response 201 Created:
─────────────────────
{
  "short_url":  "https://sho.rt/my-promo",
  "short_code": "my-promo",
  "long_url":   "https://example.com/very/long/path",
  "expires_at": "2026-12-31T23:59:59Z",
  "created_at": "2026-03-28T10:00:00Z"
}

Error responses:
────────────────
400 Bad Request     — invalid URL or malformed request
409 Conflict        — custom alias already taken
422 Unprocessable   — URL fails validation (malware list, etc.)
429 Too Many Req.   — rate limit exceeded
```

### GET /{code}

```
Request:
────────
GET /aB3xY9
Host: sho.rt

Response (happy path):
──────────────────────
HTTP/1.1 301 Moved Permanently    (or 302 — see trade-offs)
Location: https://example.com/very/long/path
Cache-Control: max-age=3600

Response (not found):
──────────────────────
HTTP/1.1 404 Not Found

Response (expired):
────────────────────
HTTP/1.1 410 Gone
```

### 301 vs 302 Redirect

```
301 Moved Permanently:
  ├─ Browser caches the redirect
  ├─ Subsequent visits go directly to destination (no server hit)
  ├─ ✅ Lower server load
  ├─ ❌ Cannot track repeat visits (browser won't call us again)
  └─ Use when: analytics not needed, performance priority

302 Found (Temporary Redirect):
  ├─ Browser does NOT cache
  ├─ Every visit calls our server
  ├─ ✅ Full analytics tracking (every click recorded)
  ├─ ❌ Higher server load
  └─ Use when: analytics important (bit.ly uses 302)

Best practice: use 302 for analytics, 301 for static links
```

## Step 4: Short Code Generation

### Option A: MD5 Hash (Truncated)

```
Algorithm:
──────────
1. MD5(long_url) → 128-bit hash
2. Take first 43 bits → encode as Base62 → 7-character code

Example:
  long_url: "https://example.com/path"
  MD5:      "1bc29b36f623ba82aaf6724fd3b16718"
  First 7 Base62 chars: "aB3xY9k"

Base62 alphabet: 0-9, a-z, A-Z (62 characters)
7 chars: 62^7 = 3.5 trillion combinations

Collision problem:
  MD5("url_a") and MD5("url_b") might share first 43 bits
  Solution: on collision, append 1 and re-hash

Pros:
✅ Same URL always gets same code (deduplication)
✅ Stateless — no coordination needed

Cons:
❌ Collisions require retry logic
❌ Predictable outputs (security concern)
```

### Option B: Base62 Counter (Recommended)

```
Algorithm:
──────────
1. Maintain a global auto-increment counter (start at 1,000,000)
2. Convert counter to Base62

Example:
  counter = 11157  → Base62 → "2TX"
  counter = 56800235584  → Base62 → "aB3xY9"

Counter to Base62:
─────────────────
def to_base62(n):
    chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    result = []
    while n > 0:
        result.append(chars[n % 62])
        n //= 62
    return ''.join(reversed(result))

Counter 1,000,000 → "4c92"  (4 chars)
Counter 56,800,235,584 → "aB3xY9" (7 chars)

At 200 writes/sec: 7-char space exhausted in 556 years.

Pros:
✅ Short codes are short initially, grow naturally
✅ No collisions
✅ Simple algorithm

Cons:
❌ Counter must be globally coordinated
❌ Sequential codes are predictable (enumerable)
   Solution: use counter + random offset, or shuffle bits
```

### Counter Coordination with Redis

```
Single counter across distributed servers:

redis> INCR url:counter
(integer) 56800235585

redis> SET url:56800235585 "https://example.com/path"  EX 86400

Problem: Redis SPOF
Solution:
  - Redis Sentinel / Redis Cluster for HA
  - Or: Pre-allocate ranges to servers:
      Server 1 gets IDs 1–1000
      Server 2 gets IDs 1001–2000
      When exhausted, request next range from counter
```

## Step 5: Database Schema

```sql
-- Core URL mapping table
CREATE TABLE urls (
    id           BIGSERIAL PRIMARY KEY,
    short_code   VARCHAR(16) NOT NULL UNIQUE,
    long_url     TEXT NOT NULL,
    user_id      BIGINT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at   TIMESTAMPTZ,
    is_custom    BOOLEAN DEFAULT FALSE,
    click_count  BIGINT DEFAULT 0
);

CREATE INDEX idx_urls_short_code ON urls(short_code);
CREATE INDEX idx_urls_expires_at ON urls(expires_at)
    WHERE expires_at IS NOT NULL;

-- Analytics (optional, high write volume)
CREATE TABLE url_clicks (
    id           BIGSERIAL PRIMARY KEY,
    short_code   VARCHAR(16) NOT NULL,
    clicked_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ip_address   INET,
    user_agent   TEXT,
    referrer     TEXT,
    country_code CHAR(2)
);

-- Partition by month for analytics table
CREATE INDEX idx_clicks_code_time
    ON url_clicks(short_code, clicked_at DESC);
```

**Database choice**: PostgreSQL for main table (strong consistency, UNIQUE constraint). Cassandra or ClickHouse for analytics clicks at scale.

## Step 6: Caching Strategy

```
Hot URL caching with Redis:
────────────────────────────

Cache structure:
  KEY:   "url:{short_code}"
  VALUE: long_url (plain string)
  TTL:   3600 seconds (1 hour)

On redirect:
  1. Check Redis: GET url:aB3xY9
  2a. Cache HIT  → return 302 to long_url (< 1ms)
  2b. Cache MISS → query PostgreSQL
                 → cache result
                 → return 302

Cache invalidation:
  Only needed if links expire or are deleted:
  DEL url:aB3xY9 (on expiry job or delete API)

Cache hit ratio target:
  Top 20% URLs → 80% of traffic
  Expected hit ratio: 85–90%
  Cold requests (10–15%) still < 5ms with indexed DB lookup
```

## Step 7: Full Architecture

```mermaid
flowchart TD
    subgraph Client ["Client Layer"]
        Browser[Browser / App]
    end

    subgraph Edge ["Edge Layer"]
        CDN[CDN\nCloudflare]
        LB[Load Balancer]
    end

    subgraph App ["Application Tier"]
        API1[API Server 1]
        API2[API Server 2]
        API3[API Server 3]
    end

    subgraph Cache ["Cache Tier"]
        RC[(Redis Cluster\nHot URLs\n~5 GB)]
    end

    subgraph DB ["Database Tier"]
        PG[(PostgreSQL Primary\nURL mappings)]
        PGR[(PostgreSQL Replica\nRead scaling)]
    end

    subgraph Analytics ["Analytics Tier"]
        KF[Kafka\nClick events]
        CH[(ClickHouse\nAnalytics DB)]
    end

    Browser -->|GET /aB3xY9| CDN
    CDN -->|Cache miss| LB
    LB --> API1
    LB --> API2
    LB --> API3

    API1 --> RC
    API2 --> RC
    API3 --> RC

    RC -->|Cache miss| PG
    PG --- PGR

    API1 -->|Write| PG
    API1 -->|Click event| KF
    KF --> CH

    style CDN fill:#7c3aed,color:#fff
    style LB fill:#7c3aed,color:#fff
    style RC fill:#ef4444,color:#fff
    style PG fill:#2563eb,color:#fff
    style PGR fill:#2563eb,color:#fff
    style KF fill:#f59e0b,color:#fff
    style CH fill:#374151,color:#fff
    style API1 fill:#059669,color:#fff
    style API2 fill:#059669,color:#fff
    style API3 fill:#059669,color:#fff
```

## Step 8: URL Shortening Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant API as API Server
    participant RC as Redis
    participant DB as PostgreSQL

    C->>API: POST /api/v1/shorten\n{long_url: "..."}
    API->>API: Validate URL\nCheck not malware
    API->>DB: Check custom alias availability\n(if custom requested)
    DB-->>API: Available
    API->>RC: INCR url:counter → 56800235585
    RC-->>API: counter = 56800235585
    API->>API: Base62(56800235585) = "aB3xY9"
    API->>DB: INSERT urls\n(short_code, long_url, ...)
    DB-->>API: OK, id=12345
    API->>RC: SET url:aB3xY9 "https://example.com/..." EX 3600
    RC-->>API: OK
    API-->>C: 201 Created\n{short_url: "https://sho.rt/aB3xY9"}
```

## Step 9: Redirect Flow

```mermaid
sequenceDiagram
    participant B as Browser
    participant CF as CDN/Cloudflare
    participant API as API Server
    participant RC as Redis
    participant DB as PostgreSQL

    B->>CF: GET /aB3xY9
    CF->>CF: Cache check
    alt CDN Cache Hit (301 only)
        CF-->>B: 301 → long_url (cached)
    else CDN Cache Miss
        CF->>API: GET /aB3xY9
        API->>RC: GET url:aB3xY9
        alt Redis Hit
            RC-->>API: "https://example.com/path"
            API-->>CF: 302 Location: https://example.com/path
            API--)DB: async: increment click_count
        else Redis Miss
            RC-->>API: null
            API->>DB: SELECT long_url WHERE short_code='aB3xY9'
            DB-->>API: "https://example.com/path"
            API->>RC: SET url:aB3xY9 "..." EX 3600
            API-->>CF: 302 Location: https://example.com/path
        end
        CF-->>B: 302 → https://example.com/path
    end
    B->>B: Navigate to long URL
```

## Handling Edge Cases

```
1. Duplicate long URLs:
   ──────────────────────
   Same long URL submitted twice.
   Option A: Return same short code (deduplicate)
     → Requires DB lookup before insert
     → Good for sharing, bad for per-user analytics
   Option B: Always create new short code
     → Multiple codes for same destination
     → Simple, allows per-campaign tracking

   Recommendation: deduplicate per user_id, not globally.

2. Custom alias conflicts:
   ──────────────────────────
   SELECT 1 FROM urls WHERE short_code = 'my-promo'
   If exists → 409 Conflict
   If not    → INSERT with is_custom=TRUE

3. Expired links:
   ─────────────────
   On redirect: check expires_at in cache/DB
   Return 410 Gone if expired
   Background job: DELETE expired rows nightly (keep analytics)
   Do NOT serve expired → redirect user to error page

4. Very long URLs:
   ─────────────────
   MAX length: 2048 chars (browser URL bar limit)
   Reject with 400 if longer
   Store in TEXT column (PostgreSQL TEXT is unlimited)
```

## Analytics Considerations

```
Click tracking without slowing redirects:
───────────────────────────────────────────

Synchronous (slow path):
  redirect → log to DB → respond
  Problem: DB write adds 5–20ms latency to every redirect

Asynchronous (fast path):
  redirect → respond immediately
           → async: publish to Kafka/SQS
  Background consumer: batch insert to ClickHouse

Metrics to track per click:
  ├─ Timestamp
  ├─ IP address (for geo-lookup)
  ├─ User-Agent (browser/OS/device)
  ├─ Referer header (where did user come from)
  └─ Country (resolved from IP via MaxMind GeoLite2)

Analytics queries:
  "Total clicks on /aB3xY9 last 30 days"
  "Top 10 countries for this campaign link"
  "Hourly click distribution"
```

## Trade-offs Summary

| Decision | Option A | Option B | Winner |
|----------|---------|---------|--------|
| Code generation | MD5 hash | Base62 counter | Counter (no collisions) |
| Redirect type | 301 (cached) | 302 (tracked) | 302 for analytics |
| Cache | In-memory | Redis | Redis (shared across servers) |
| Analytics DB | PostgreSQL | ClickHouse | ClickHouse at scale |
| Counter coordination | DB sequence | Redis INCR | Redis (faster) |
| Custom aliases | Allowed | Not allowed | Allow (user value) |

## Interview Tips

- **301 vs 302** is almost always asked — know both trade-offs cold
- **Start with requirements and capacity** before jumping to design — interviewers want to see this habit
- **The counter-vs-hash question** is a common follow-up; counter is better, but discuss why
- **Cache is the key insight**: 100:1 read:write ratio means caching short codes in Redis gives huge wins
- **Mention custom aliases** to show product thinking — it adds a UNIQUE constraint discussion
- **Analytics decoupling**: async Kafka pipeline shows you know not to slow down the critical redirect path
- **Scale the read path first**: 20K reads/sec is the challenge, not 200 writes/sec

## Summary

- **URL shortener is a key-value store** at its core: short_code → long_url
- **Base62 counter** beats MD5 hashing — no collisions, naturally ordered
- **Redis caching** of hot URLs brings redirect latency under 1ms
- **302 redirect** allows analytics; 301 is faster but loses click tracking
- **Async analytics** via Kafka/ClickHouse keeps the redirect path fast
- **20M hot URLs in Redis**: the top 20% drives 80% of traffic — cache fits in 5 GB

## Next Steps

Continue to [Design Twitter Case Study](../24-design-twitter/README.md) to tackle a much more complex distributed system design.

---

**Key Takeaway**: URL shortener teaches the fundamentals of high-read-ratio systems — cache aggressively, keep the hot path lean, and push analytics off the critical path.
